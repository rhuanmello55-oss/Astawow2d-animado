#!/usr/bin/env bash
# new_project.sh <estilo> <pasta>   estilos: flat | iso-loja | padaria | mercado | campo | palito | toon
set -e
D="$(cd "$(dirname "$0")/.." && pwd)"
case "$1" in
  flat) SRC="$D/exemplo";; iso-loja) SRC="$D/demos/mercadinho";; padaria) SRC="$D/demos/padaria";; mercado) SRC="$D/demos/mercado";;
  campo) SRC="$D/demos/menino";; palito) SRC="$D/demos/palito";; toon) SRC="$D/demos/toon";;
  *) echo "uso: new_project.sh <flat|iso-loja|padaria|mercado|campo|palito|toon> <pasta>"; exit 1;;
esac
[ -n "$2" ] || { echo "faltou a pasta"; exit 1; }
mkdir -p "$2" && cp -r "$SRC"/. "$2"/ && rm -f "$2"/*.mp4 "$2"/*.wav "$2"/relatorio_audio.md "$2"/contact.png "$2"/cues.json.bak
[ -f "$D/templates/audio.json" ] && [ ! -f "$2/audio.json" ] && cp "$D/templates/audio.json" "$2/audio.json"
echo "projeto '$1' criado em $2 — edite $2/cena.js (roteiro/cenas), depois: node scripts/lint.mjs $2 && node scripts/render.mjs $2 --snap ... && render."
