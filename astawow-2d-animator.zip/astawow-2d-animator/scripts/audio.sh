#!/usr/bin/env bash
# audio.sh <pasta_do_projeto> — gera <pasta>/mix.wav (voz+música+ambiente+SFX, -14 LUFS) a partir de <pasta>/audio.json.
# Se o cena.js declara window.HITS, exporta antes os efeitos para <pasta>/hits.json (audio.json: "sfx_from":"hits.json").
set -e
D="$(cd "$(dirname "$0")/.." && pwd)"; P="${1:?uso: audio.sh <pasta>}"
[ -f "$P/audio.json" ] || { echo "falta $P/audio.json (copie templates/audio.json)"; exit 1; }
grep -q "sfx_from" "$P/audio.json" && node "$D/scripts/render.mjs" "$P" --hits "$P/hits.json" || true
python3 "$D/audio/mix.py" "$P/audio.json" --out "$P/mix.wav" --stems
