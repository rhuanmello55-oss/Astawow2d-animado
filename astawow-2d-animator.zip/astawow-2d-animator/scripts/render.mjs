#!/usr/bin/env node
// render.mjs — renderiza um projeto 2D (index.html com window.CONFIG e window.seek(t)) em MP4.
// Uso:  node scripts/render.mjs <pasta> --out video.mp4 [--audio voz.mp3] [--fps 30] [--from 0 --to 5] [--scale 1]
//       node scripts/render.mjs <pasta> --snap 0.5,2,4 [--cols 3] [--out folha.png]   (folha de contato para revisar)
// Requer: node, playwright (chromium), ffmpeg no PATH.
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
import { spawn, spawnSync } from 'node:child_process';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import fs from 'node:fs';

const a = process.argv.slice(2);
const dir = resolve(a[0] || '.');
const opt = (k, d) => { const i = a.indexOf('--' + k); return i >= 0 ? a[i + 1] : d; };
const flag = (k) => a.includes('--' + k);
const out = resolve(opt('out', (flag('snap') || flag('strip')) ? 'contact.png' : 'video.mp4'));
const audio = opt('audio', null);
const scale = parseFloat(opt('scale', '1'));

const browser = await chromium.launch({ args: ['--allow-file-access-from-files', '--font-render-hinting=none'] });
const probe = await browser.newPage();
await probe.goto(pathToFileURL(dir + '/index.html').href);
await probe.waitForFunction('window.READY===true', null, { timeout: 30000 });
const cfg = await probe.evaluate("typeof CONFIG!=='undefined'?CONFIG:window.CONFIG");
await probe.close();
const fps = parseFloat(opt('fps', cfg.fps || 30));
const W = Math.round(cfg.w * scale), H = Math.round(cfg.h * scale);
const ctx = await browser.newContext({ viewport: { width: cfg.w, height: cfg.h }, deviceScaleFactor: scale });
const page = await ctx.newPage();
const errors = [];
page.on('pageerror', (e) => errors.push(String(e)));
page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
await page.goto(pathToFileURL(dir + '/index.html').href);
await page.waitForFunction('window.READY===true', null, { timeout: 30000 });
const canvas = page.locator('#c');
const blurN = parseInt(opt('blur', '0'), 10), shutter = parseFloat(opt('shutter', '0.5'));   // --blur N: N sub-quadros por quadro (motion blur de cinema)
const shot = async (t) => {
  if (blurN > 1) {
    await page.evaluate(([tt, k, sh, dt]) => { const c = document.getElementById('c'); const acc = document.createElement('canvas'); acc.width = c.width; acc.height = c.height; const a = acc.getContext('2d');
      for (let i = 0; i < k; i++) { window.seek(tt + (i / k - .5) * sh * dt); a.globalAlpha = 1 / (i + 1); a.drawImage(c, 0, 0); }
      window.seek(tt); const g = c.getContext('2d'); g.save(); g.setTransform(1, 0, 0, 1, 0, 0); g.globalAlpha = 1; g.clearRect(0, 0, c.width, c.height); g.drawImage(acc, 0, 0); g.restore(); }, [t, blurN, shutter, 1 / fps]);
  } else await page.evaluate((tt) => window.seek(tt), t);
  return canvas.screenshot({ type: 'png' });
};
if (flag('hits')) {   // --hits cues.json : exporta window.HITS=[[t,'sfx',{opts}]] (o que o desenho "acende") para o mixer
  const hits = await page.evaluate(() => window.HITS || []);
  const list = hits.map(h => Array.isArray(h) ? Object.assign({ t: h[0], sfx: h[1] }, h[2] || {}) : h);
  fs.writeFileSync(resolve(opt('hits', 'cues.json')), JSON.stringify(list, null, 1)); console.log('hits:', list.length, '->', opt('hits', 'cues.json')); await browser.close(); process.exit(0);
}
if (flag('strip')) {  // --strip a,b,n : n quadros entre a e b (ex.: conferir uma transição)
  const [sa, sb, sn] = opt('strip', '0,1,8').split(',').map(Number); a.push('--snap', Array.from({ length: sn }, (_, i) => (sa + (sb - sa) * i / (sn - 1)).toFixed(3)).join(','));
}

if (flag('snap') || flag('strip')) {
  const times = opt('snap', '0').split(',').map(Number);
  const cols = parseInt(opt('cols', Math.min(4, times.length)), 10);
  const tmp = out + '.parts'; fs.mkdirSync(tmp, { recursive: true });
  for (let i = 0; i < times.length; i++) fs.writeFileSync(`${tmp}/${String(i).padStart(3, '0')}.png`, await shot(times[i]));
  const rows = Math.ceil(times.length / cols);
  const r = spawnSync('ffmpeg', ['-y', '-loglevel', 'error', '-i', `${tmp}/%03d.png`, '-vf', `scale=${flag('phone') ? 240 : Math.round(480 * Math.min(1, cfg.w / cfg.h * 1.2) )}:-1,tile=${cols}x${rows}`, '-frames:v', '1', out]);
  fs.rmSync(tmp, { recursive: true, force: true });
  console.log(r.status === 0 ? 'folha: ' + out : 'ffmpeg falhou');
  if (errors.length) console.log('ERROS DE JS:\n' + errors.join('\n'));
  await browser.close(); process.exit(r.status || 0);
}

const from = parseFloat(opt('from', 0)), to = parseFloat(opt('to', cfg.dur));
const n = Math.round((to - from) * fps);
const args = ['-y', '-loglevel', 'error', '-f', 'image2pipe', '-framerate', String(fps), '-i', '-'];
if (audio) args.push('-ss', String(from), '-t', String(to - from), '-i', resolve(audio));
args.push('-map', '0:v');
if (audio) args.push('-map', '1:a', '-c:a', 'aac', '-b:a', '192k', '-shortest');
args.push('-c:v', 'libx264', '-crf', opt('crf', '16'), '-preset', opt('preset', 'medium'), '-pix_fmt', 'yuv420p', '-r', String(fps), '-movflags', '+faststart', out);
const ff = spawn('ffmpeg', args, { stdio: ['pipe', 'inherit', 'inherit'] });
const t0 = Date.now();
for (let i = 0; i < n; i++) {
  const buf = await shot(from + i / fps);
  if (!ff.stdin.write(buf)) await new Promise((r) => ff.stdin.once('drain', r));
  if (i % 60 === 0) process.stdout.write(`\r${i}/${n}  ${(i / ((Date.now() - t0) / 1000) || 0).toFixed(1)} fps`);
}
ff.stdin.end();
await new Promise((r) => ff.on('close', r));
console.log(`\npronto: ${out} (${W}x${H}, ${fps} fps, ${(to - from).toFixed(1)} s)`);
if (errors.length) console.log('AVISO — erros de JS durante o render:\n' + [...new Set(errors)].join('\n'));
await browser.close();
