#!/usr/bin/env bash
ok=1
for c in node ffmpeg python3; do command -v $c >/dev/null && echo "ok  $c" || { echo "FALTA $c"; ok=0; }; done
python3 -c "import numpy" 2>/dev/null && echo "ok  numpy" || { echo "FALTA numpy (pip install numpy)"; ok=0; }
D="$(cd "$(dirname "$0")" && pwd)"
node -e "const {createRequire}=require('module');try{createRequire(process.cwd()+'/x.js')('playwright');console.log('ok  playwright')}catch(e){try{createRequire('$D/x.js')('playwright');console.log('ok  playwright')}catch(e2){console.log('FALTA playwright (npm i playwright && npx playwright install chromium)');process.exit(1)}}" || ok=0
fc-list 2>/dev/null | grep -qi "archivo black\|anton" && echo "ok  fonte de título" || echo "aviso: sem Archivo Black/Anton — usando fallback Impact/DejaVu"
[ $ok = 1 ] && echo "TUDO PRONTO" || echo "Corrija o que faltou."
