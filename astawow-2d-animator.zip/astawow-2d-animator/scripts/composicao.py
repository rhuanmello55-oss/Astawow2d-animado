#!/usr/bin/env python3
"""composicao.py — verificador AUTOMÁTICO de enquadramento (roda sozinho antes de entregar).
Uso: python3 scripts/composicao.py <pasta_do_projeto> [--n 12]
Renderiza N quadros (via render.mjs --snap em folha 1 coluna) e procura problemas que o olho cansado perde:
  • CORTE NA BORDA  : conteúdo "ativo" (texto/etiqueta/objeto colorido) encostando em x=0/x=W ou no topo em muitos quadros
  • ESPAÇO VAZIO    : faixa horizontal contínua, sem detalhe, > 28% da altura (fora da zona de legenda)
  • QUADRO CHAPADO  : cena quase sem variação (gradiente/vazio) — pouco conteúdo
  • PARADO          : quadros consecutivos idênticos por > 1,2 s
Sai com código 1 se achar defeito GRAVE. Heurísticas — não substituem o olhar do agente detalhista."""
import json, os, subprocess, sys, tempfile
import numpy as np
from PIL import Image

pasta = sys.argv[1]; n = int(sys.argv[sys.argv.index("--n") + 1]) if "--n" in sys.argv else 12
root = os.path.dirname(os.path.abspath(__file__))
html = open(os.path.join(pasta, "index.html"), encoding="utf-8").read()
import re
m = re.search(r"CONFIG\s*=\s*\{[^}]*w:\s*(\d+)[^}]*h:\s*(\d+)[^}]*dur:\s*([\d.]+)", html) or re.search(r"CONFIG\s*=\s*\{[^}]*\}", open(os.path.join(pasta, "cena.js"), encoding="utf-8").read())
src = html + open(os.path.join(pasta, "cena.js"), encoding="utf-8").read() if os.path.exists(os.path.join(pasta, "cena.js")) else html
cfg = re.search(r"CONFIG\s*=\s*\{([^}]*)\}", src).group(1)
W = int(re.search(r"w:\s*(\d+)", cfg).group(1)); H = int(re.search(r"h:\s*(\d+)", cfg).group(1)); D = float(re.search(r"dur:\s*([\d.]+)", cfg).group(1))
ts = np.linspace(.3, D - .3, n); tmp = tempfile.mkdtemp(); out = os.path.join(tmp, "f.png")
subprocess.run(["node", os.path.join(root, "render.mjs"), pasta, "--snap", ",".join(f"{t:.2f}" for t in ts), "--cols", "1", "--scale", "1", "--out", out], check=True, capture_output=True)
sheet = np.asarray(Image.open(out).convert("RGB")).astype(float); fh = sheet.shape[0] // n; fw = sheet.shape[1]
frames = [sheet[i * fh:(i + 1) * fh] for i in range(n)]
vertical = H > W; cap0, cap1 = (.66, .80) if vertical else (.78, .95)    # zona de legenda (ignorada no teste de vazio)
bad = []; warn = []
def activity(f):  # mapa de "detalhe": gradiente local
    g = f.mean(2); gx = np.abs(np.diff(g, axis=1))[:-1, :]; gy = np.abs(np.diff(g, axis=0))[:, :-1]; return (gx + gy)
edge_hits = {"esq": 0, "dir": 0, "topo": 0}; empty_hits = 0; flat_hits = 0; off_hits = 0; offs = []
for i, f in enumerate(frames):
    a = activity(f); h, w = a.shape; m_ = max(2, int(w * .012))
    # encosto na borda: detalhe forte nas colunas/linhas extremas, em faixa contígua (ignora fundo contínuo)
    def corte(strip_mask):   # objeto localizado cortado na borda = sequência ativa curta (3–30% do lado); parede/rua contínua é ignorada
        m1 = strip_mask.any(axis=1) if strip_mask.ndim == 2 and strip_mask.shape[0] > strip_mask.shape[1] else strip_mask.any(axis=0)
        run = best = gap = 0
        for v in m1:
            if v: run += 1; gap = 0
            else:
                gap += 1
                if gap > max(3, len(m1) // 100): run = 0
            best = max(best, run)
        return .03 < best / len(m1) < .30
    for nome, strip in (("esq", a[int(h * .08):int(h * .9), :m_] > 40), ("dir", a[int(h * .08):int(h * .9), -m_:] > 40), ("topo", a[:m_, int(w * .05):int(w * .95)] > 40)):
        if corte(strip): edge_hits[nome] += 1
    cols = a[:int(h * cap0)].sum(0) if vertical else a.sum(0)   # massa de detalhe por coluna (sem a zona de legenda)
    if cols.sum() > 0:
        cx = (cols * np.arange(w)).sum() / cols.sum() / w; offs.append(cx - .5)
        if abs(cx - .5) > .085: off_hits += 1
    rows = a.mean(1); calm = rows < max(1.2, np.percentile(rows, 30) * .8)
    zona = np.ones(h, bool); zona[int(h * cap0):int(h * cap1)] = False; calm &= zona
    run = best = 0
    for v in calm:
        run = run + 1 if v else 0; best = max(best, run)
    if best > .28 * h: empty_hits += 1
    if a.mean() < 2.0: flat_hits += 1
if (edge_hits["esq"] > n * .5 or edge_hits["dir"] > n * .4) and not (edge_hits["esq"] >= n * .8 and edge_hits["dir"] >= n * .8):
    warn.append(f"objeto localizado cortado pela borda (pode ser proposital: entrada/saída)/cortado na borda lateral em {max(edge_hits['esq'], edge_hits['dir'])}/{n} quadros (esq {edge_hits['esq']}, dir {edge_hits['dir']}) — confira letreiros, etiquetas e personagens")
if off_hits > n * .4: warn.append(f"cena deslocada: o detalhe está concentrado {'à direita' if np.mean(offs) > 0 else 'à esquerda'} do centro em {off_hits}/{n} quadros (deslocamento médio {abs(np.mean(offs))*100:.0f}% da largura) — recentralize o cenário/câmera")
if edge_hits["topo"] > n * .5: warn.append(f"conteúdo no limite superior em {edge_hits['topo']}/{n} quadros (UI do Shorts cobre ~150 px)")
if empty_hits > n * .5: warn.append(f"faixa vazia (>28% da altura) em {empty_hits}/{n} quadros — enquadre mais perto / aumente o foco (references/composicao.md)")
if flat_hits > n * .3: bad.append(f"{flat_hits}/{n} quadros quase sem detalhe (cena vazia?)")
d = [np.abs(frames[i + 1] - frames[i]).mean() for i in range(n - 1)]; still = sum(1 for v in d if v < .15)
if still >= 2 and (D / n) * still > 1.2: bad.append(f"{still} intervalos de {D/(n-1):.1f}s sem mudança visível (cena parada) — adicione ação/câmera")
print(f"composição: {n} quadros analisados ({W}x{H}, {D:.0f}s)")
for w_ in warn: print("  ⚠ ", w_)
for b_ in bad: print("  ✗ ", b_)
if not warn and not bad: print("  ✓ nenhum problema de enquadramento detectado")
sys.exit(1 if bad else 0)
