#!/usr/bin/env node
// lint.mjs <pasta_do_projeto> — pega erros comuns ANTES de renderizar.
import fs from 'fs'; import path from 'path';
const dir = process.argv[2]; if (!dir) { console.log('uso: node scripts/lint.mjs <pasta>'); process.exit(1); }
let bad = 0; const warn = (m) => { console.log('⚠ ' + m); bad++; };
const files = fs.readdirSync(dir).filter((f) => /^(cena|shop|mercado|stick|toon)\.js$/.test(f) || f === 'cena.js');
const src = files.map((f) => ({ f, s: fs.readFileSync(path.join(dir, f), 'utf8') }));
const all = src.map((x) => x.s).join('\n');
if (!fs.existsSync(path.join(dir, 'index.html'))) warn('index.html não existe (copie templates/index.html).');
if (!fs.existsSync(path.join(dir, 'lib2d.js'))) warn('lib2d.js não está na pasta do projeto.');
if (!/CONFIG\s*=\s*\{[^}]*dur/.test(all)) warn('CONFIG {w,h,fps,dur} não encontrado no cena.js.');
for (const [re, why] of [[/Math\.random\s*\(/, 'Math.random (use L.hash(i))'], [/Date\.now|new Date|performance\.now/, 'relógio real (use só o t do seek)'], [/setTimeout|setInterval|requestAnimationFrame/, 'timers/rAF (frame tem que ser função pura de t)']]) if (re.test(all)) warn('proibido: ' + why);
if (!/function draw\s*\(/.test(all)) warn('função draw(g,t,W,H) não encontrada.');
// escala: em cena isométrica a pessoa deve ter s ≈ 1.7*u/400 (≈.36–.45 p/ u 84–100); acima de .6 provavelmente é maior que a casa
if (/L\.iso\s*\(/.test(all)) for (const m of all.matchAll(/L\.person\s*\(\s*g\s*,\s*\{[^}]*?\bs:\s*([\d.]+)/g)) if (parseFloat(m[1]) > .6) warn(`personagem com s:${m[1]} numa cena isométrica — provavelmente maior que a casa/carro (use ~.4). Veja references/escala.md`);
for (const m of all.matchAll(/(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)\s*,\s*\.?\d*\s*,?\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)\s*,\s*'#/g)) void m;
console.log(bad ? `\n${bad} aviso(s). Corrija antes de renderizar.` : '✓ lint ok'); process.exit(bad ? 2 : 0);
