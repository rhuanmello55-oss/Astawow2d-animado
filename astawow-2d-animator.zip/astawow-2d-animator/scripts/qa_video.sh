#!/usr/bin/env bash
# qa_video.sh video.mp4 [contact.png] — confere o MP4 final: resolução/duração/áudio, quadros pretos, trechos congelados + folha de contato.
V="$1"; OUT="${2:-${V%.*}_qa.png}"; [ -f "$V" ] || { echo "uso: qa_video.sh video.mp4"; exit 1; }
ffprobe -v error -show_entries stream=codec_type,codec_name,width,height,r_frame_rate:format=duration,size -of default=nw=1 "$V"
HAS=$(ffprobe -v error -select_streams a -show_entries stream=codec_type -of csv=p=0 "$V"); [ -n "$HAS" ] && echo "áudio: sim" || echo "⚠ SEM ÁUDIO (ok só se for intencional)"
B=$(ffmpeg -v info -i "$V" -vf blackdetect=d=0.4:pix_th=0.05 -an -f null - 2>&1 | grep -c black_start); echo "trechos pretos >0,4 s: $B (iris-out final é esperado)"
F=$(ffmpeg -v info -i "$V" -vf freezedetect=n=0.003:d=1.5 -an -f null - 2>&1 | grep -c freeze_start); [ "$F" -gt 0 ] && echo "⚠ $F trecho(s) PARADO(s) >1,5 s — falta movimento (ver references/detalhes.md)" || echo "sem trechos parados"
DUR=$(ffprobe -v error -show_entries format=duration -of csv=p=0 "$V"); ffmpeg -v error -y -i "$V" -vf "fps=8/${DUR%.*},scale=360:-1,tile=8x1" -frames:v 1 "$OUT" && echo "folha de contato: $OUT"
