#!/usr/bin/env python3
"""sfx.py (compatível com a versão antiga) — agora usa o motor novo em audio/.
Uso: python3 scripts/sfx.py cues.json out.wav --dur 10 [--voice voz.mp3] [--music alegre] [--amb rua]
cues.json: [{"t":1.2,"sfx":"pop"}, ...]. Para o controle completo use:  python3 audio/mix.py audio.json --out mix.wav"""
import argparse, json, os, sys, tempfile
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'audio'))
import mix, dsp
ap = argparse.ArgumentParser(); ap.add_argument('cues'); ap.add_argument('out'); ap.add_argument('--dur', type=float, default=10)
ap.add_argument('--voice'); ap.add_argument('--music', default='none'); ap.add_argument('--amb', default='none'); ap.add_argument('--gain', type=float, default=1.0)
a = ap.parse_args()
cfg = {'dur': a.dur, 'sfx': json.load(open(a.cues, encoding='utf-8')), 'music': {'style': a.music}, 'ambience': a.amb}
if a.voice: cfg['voice_file'] = os.path.abspath(a.voice)
y, stems, rep = mix.build(cfg, '.'); dsp.write_wav(a.out, y, 16)
print('ok:', a.out, f"{rep['lufs']:.1f} LUFS", f"{rep['tp']:.1f} dBTP")
