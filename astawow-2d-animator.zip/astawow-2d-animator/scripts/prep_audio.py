#!/usr/bin/env python3
"""prep_audio.py — prepara o áudio da narração para a animação.
Gera words.js com:  window.ENV   = envelope de volume (0..1) por frame  → anima a boca
                    window.WORDS = [{w,t0,t1}] palavras com tempo        → legendas

Uso:  python3 scripts/prep_audio.py voz.mp3 --text roteiro.txt --fps 30 --out meu_projeto/
  --text   texto exato da narração (recomendado: a legenda sai igual ao que é falado)
Sem --text e com faster-whisper instalado, transcreve sozinho (pip install faster-whisper).
Só precisa de: ffmpeg + numpy.  Os tempos das palavras são distribuídos pelos trechos COM VOZ do áudio
(por nº de letras); para sincronia perfeita use faster-whisper (word_timestamps) — ele é usado se existir.
"""
import argparse, json, subprocess, sys, os
import numpy as np

ap = argparse.ArgumentParser()
ap.add_argument('audio'); ap.add_argument('--text'); ap.add_argument('--fps', type=float, default=30)
ap.add_argument('--out', default='.'); ap.add_argument('--lang', default='pt')
a = ap.parse_args()

raw = subprocess.run(['ffmpeg', '-v', 'error', '-i', a.audio, '-ac', '1', '-ar', '16000', '-f', 's16le', '-'], capture_output=True, check=True).stdout
x = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
sr = 16000; dur = len(x) / sr
hop = int(sr / a.fps); n = int(np.ceil(len(x) / hop))
rms = np.array([np.sqrt(np.mean(x[i * hop:(i + 1) * hop] ** 2) + 1e-12) for i in range(n)])
db = 20 * np.log10(rms + 1e-9); hi = np.percentile(db, 98); lo = hi - 38
env = np.clip((db - lo) / (hi - lo), 0, 1)
env = np.convolve(env, np.ones(3) / 3, mode='same')
env = np.round(env, 3)

words = None
try:
    from faster_whisper import WhisperModel
    m = WhisperModel('small', compute_type='int8')
    segs, _ = m.transcribe(a.audio, language=a.lang, word_timestamps=True)
    words = [{'w': w.word.strip(), 't0': round(w.start, 3), 't1': round(w.end, 3)} for s in segs for w in s.words if w.word.strip()]
    if a.text:  # troca pelo texto exato, mantendo a contagem proporcional
        words = None
except Exception:
    pass
if words is None:
    if not a.text:
        sys.exit('Sem faster-whisper: passe --text roteiro.txt com o texto exato da narração.')
    toks = open(a.text, encoding='utf-8').read().split()
    voiced = env > 0.12
    # fecha buracos curtos (< 0,25 s) para formar trechos de fala
    gap = int(0.25 * a.fps); idx = np.where(voiced)[0]
    if len(idx) == 0: sys.exit('Áudio sem voz detectada.')
    runs = []; s = idx[0]; p = idx[0]
    for i in idx[1:]:
        if i - p > gap: runs.append((s, p)); s = i
        p = i
    runs.append((s, p))
    total_time = sum((e - s + 1) for s, e in runs) / a.fps
    weights = np.array([len(t) + 2 for t in toks], dtype=float); weights = weights / weights.sum() * total_time
    words = []; ri = 0; pos = runs[0][0] / a.fps; left = (runs[0][1] + 1) / a.fps
    for t, w in zip(toks, weights):
        t0 = pos; need = w
        while need > 1e-6:
            avail = left - pos
            if avail <= 1e-6:
                ri += 1
                if ri >= len(runs): break
                pos = runs[ri][0] / a.fps; left = (runs[ri][1] + 1) / a.fps; continue
            use = min(avail, need); pos += use; need -= use
        words.append({'w': t, 't0': round(t0, 3), 't1': round(pos, 3)})

os.makedirs(a.out, exist_ok=True)
with open(os.path.join(a.out, 'words.js'), 'w', encoding='utf-8') as f:
    f.write('// gerado por prep_audio.py — duração %.2f s, %g fps\n' % (dur, a.fps))
    f.write('window.WORDS = ' + json.dumps(words, ensure_ascii=False) + ';\n')
    f.write('window.ENV = ' + json.dumps([float(v) for v in env]) + ';\n')
    f.write('window.AUDIO_DUR = %.3f;\n' % dur)
print('ok: %s/words.js — %d palavras, %.1f s' % (a.out, len(words), dur))
