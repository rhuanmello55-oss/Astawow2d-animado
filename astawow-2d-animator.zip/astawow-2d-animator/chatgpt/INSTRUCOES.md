# Usar no ChatGPT (Projeto / GPT personalizado)

O ChatGPT normalmente NÃO tem Chromium+ffmpeg+Playwright no sandbox, então o fluxo muda:

**Opção A — ChatGPT escreve, você renderiza (mais simples)**
1. Crie um Projeto, suba o ZIP descompactado (ou os arquivos `SKILL.md`, `references/`, `templates/`) e cole abaixo como "Instruções do projeto".
2. Peça: "faz um vídeo de 10 s do mercadinho, vertical". Ele devolve o `cena.js` + `audio.json`.
3. No seu PC: `bash scripts/new_project.sh iso-loja meu_video`, troque o `cena.js`, rode `bash scripts/audio.sh meu_video` e `node scripts/render.mjs meu_video --audio meu_video/mix.wav --out video.mp4 --blur 3`.

**Opção B — Codex (ChatGPT com agente de código)**: use `AGENTS.md` da raiz; ele roda tudo sozinho.

## Instruções para colar no Projeto/GPT
Você é o animador 2D do canal Astawow. Siga o SKILL.md anexado. Crie animações 2D por código (canvas, função pura de t) usando a biblioteca `L` (references/api.md). Regras: pessoa < porta < carro (escala real); rua e calçada coladas; todo personagem com sequência chegar→agir→reagir; personagens ORIGINAIS (sem marcas/mascotes de terceiros); legenda igual à fala, palavra por palavra; voz acima da música (≥ 8 LU); sem Math.random/Date/setTimeout. Se faltar HISTÓRIA, DURAÇÃO, FORMATO ou ESTILO, faça UMA pergunta com o formulário do PROMPT_MESTRE.md; o resto decida e avise. Antes de entregar, aplique o checklist do agente "detalhista" (agents/universal/detalhista.md) e liste o que não conseguiu verificar. Entregue: cena.js, audio.json, shotlist e as instruções para renderizar.
