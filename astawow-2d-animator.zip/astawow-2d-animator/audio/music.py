"""music.py — trilha original gerada por código (sem baixar nada). compose(style, dur, bpm=None, key='C', seed=1) -> estéreo.
Estilos: alegre, aventura, lofi, suspense, toon, mercado. Estrutura: intro leve -> corpo cheio -> final com fade.
Tudo determinístico (mesma seed = mesma música). Instrumentos próprios: pluck, baixo, pad, sino, kick/caixa/chimbal."""
import numpy as np
from dsp import *

KEYS = {k: i for i, k in enumerate("C C# D D# E F F# G G# A A# B".split())}
MAJ = [0, 2, 4, 5, 7, 9, 11]; MIN = [0, 2, 3, 5, 7, 8, 10]

# estilo: bpm, modo, progressão (graus 0-6), swing, instrumentos, densidade de bateria
STYLES = {
    "alegre":   dict(bpm=112, mode=MAJ, prog=[0, 4, 5, 3], lead="bell", drums="pop", bass="pluck", pad=.5, arp=True, swing=0, color=7),
    "aventura": dict(bpm=126, mode=MAJ, prog=[0, 3, 4, 0], lead="bell", drums="march", bass="pluck", pad=.7, arp=False, swing=0, color=0),
    "lofi":     dict(bpm=84,  mode=MAJ, prog=[1, 4, 0, 5], lead="soft", drums="lofi", bass="soft", pad=.9, arp=False, swing=.18, color=7),
    "suspense": dict(bpm=78,  mode=MIN, prog=[0, 0, 5, 4], lead="tick", drums="none", bass="soft", pad=1.0, arp=False, swing=0, color=0),
    "toon":     dict(bpm=144, mode=MAJ, prog=[0, 3, 0, 4], lead="pizz", drums="toon", bass="pluck", pad=.2, arp=True, swing=.1, color=0),
    "mercado":  dict(bpm=100, mode=MAJ, prog=[0, 5, 1, 4], lead="bell", drums="bossa", bass="pluck", pad=.5, arp=True, swing=.08, color=7),
}
NAMES = sorted(STYLES)

def _deg(mode, d, base):  # grau -> midi (permite >7)
    return base + 12 * (d // 7) + mode[d % 7]

def pluck(f, dur, r, vel=.7, bright=.5):
    t = tt(dur); y = np.zeros_like(t); K = max(1, int(min(20, 6000 / f)))
    for k in range(1, K + 1): y += k ** -(1.4 - .5 * bright) * np.exp(-t / (.5 / (1 + .35 * (k - 1)))) * np.sin(TAU * k * f * t + r.uniform(0, TAU))
    return fades(y * vel * (1 - np.exp(-t / .002)), .001, .04)
def bell(f, dur, r, vel=.6):
    return fades(modal(dur, [(f, 1, .5), (f * 2.76, .25, .18), (f * 5.4, .1, .06)], r) * vel, .0008, .05)
def softkey(f, dur, r, vel=.5):  # tipo piano elétrico
    t = tt(dur); y = np.sin(TAU * f * t) * np.exp(-t / .6) + .35 * np.sin(TAU * 2 * f * t) * np.exp(-t / .25) + .15 * np.sin(TAU * 3 * f * t) * np.exp(-t / .12)
    return fades(y * vel * (1 - np.exp(-t / .004)), .002, .06)
def tickn(f, dur, r, vel=.5):
    t = tt(min(dur, .12)); return np.sin(TAU * f * t) * np.exp(-t / .03) * vel
def bass(f, dur, r, vel=.7, soft=False):
    t = tt(dur); y = np.sin(TAU * f * t) + (.25 if not soft else .08) * np.sin(TAU * 2 * f * t) + (.1 if not soft else 0) * np.sin(TAU * 3 * f * t)
    e = np.exp(-t / (.25 if not soft else .6)) * .7 + .3; return fades(y * e * vel * (1 - np.exp(-t / .006)), .002, .05)
def pad(freqs, dur, r, vel=.4, warm=1200):
    n = ns(dur); t = np.arange(n) / SR; out = np.zeros((2, n))
    for f in freqs:
        for dc, p in ((-6, -.6), (0, 0), (6, .6)):
            ph = phase(f * 2 ** ((dc + 3 * np.sin(TAU * r.uniform(.15, .4) * t + r.uniform(0, TAU))) / 1200)); y = 2 * ((ph / TAU) % 1) - 1
            out += pan(lp(y, warm, 2) * .25, p)
    e = np.minimum(1, t / .35) * np.minimum(1, (dur - t) / .45).clip(0); return out * e * vel / np.sqrt(len(freqs))
def kick(r, v=.8): t = tt(.28); return np.sin(phase(150 * np.exp(-t / .03) + 48)) * np.exp(-t / .12) * v * 1.1
def snare(r, v=.6): t = tt(.2); return (np.sin(phase(190 * np.exp(-t / .02) + 160)) * np.exp(-t / .05) * .5 + bp(r.standard_normal(len(t)), 1500, 9000, 1) * np.exp(-t / .06)) * v
def hat(r, v=.3, open_=False): t = tt(.25 if open_ else .05); return hp(r.standard_normal(len(t)), 7000) * np.exp(-t / (.08 if open_ else .012)) * v
def rim(r, v=.4): t = tt(.04); return modal(.04, [(1700, 1, .008), (2500, .5, .005)], r) * v

def compose_synth(style="alegre", dur=10.0, bpm=None, key="C", seed=1, intensity=1.0):
    S = STYLES[style]; r = rng(seed * 131 + len(style)); bpm = bpm or S["bpm"]; q = 60.0 / bpm; bar = 4 * q
    N = ns(dur); out = np.zeros((2, N)); root = 48 + KEYS.get(key.upper().replace("B", "B"), 0); mode = S["mode"]
    nb = int(np.ceil(dur / bar)) + 1
    # motivo melódico (4 notas) que repete com variações
    motif = [int(x) for x in r.choice([0, 1, 2, 2, 3, 4, 5], 4)]; motif[0] = 4 if style != "suspense" else 0
    sw = lambda b: b + (S["swing"] * (1 if (int(round((b * 2))) % 2 == 1 and abs(b * 2 - round(b * 2)) < 1e-6) else 0)) * .5
    sends = np.zeros(N)
    def add(x, t, p=0.0, g=1.0, send=.15):
        place(out, pan(x, p) if np.ndim(x) == 1 else x, t, g)
        mono = x if np.ndim(x) == 1 else x.mean(0); place_m(sends, mono * send, t)
    def place_m(buf, x, t):
        i = ns(t); a, b = max(0, i), min(len(buf), i + len(x))
        if b > a: buf[a:b] += x[a - i:b - i]
    for b in range(nb):
        t0 = b * bar
        if t0 >= dur: break
        sect = "intro" if b < 2 else ("fim" if t0 > dur - 2 * bar else "corpo")
        lvl = {"intro": .55, "corpo": 1.0, "fim": .7}[sect] * intensity
        deg = S["prog"][b % len(S["prog"])]; rootm = _deg(mode, deg, root); tri = [_deg(mode, deg + k, root + 12) for k in (0, 2, 4)]
        if S["color"]: tri.append(_deg(mode, deg + 6, root + 12) if style != "suspense" else tri[0] + 12)
        # pad (acorde) + baixo
        if S["pad"] > 0: add(pad([m2f(m) for m in tri], bar + .3, r, .32 * S["pad"] * lvl), t0, 0, 1, .3)
        bsoft = S["bass"] == "soft"
        pat = [0, 2] if sect == "intro" else ([0, 1.5, 2, 3] if not bsoft else [0, 2.5])
        for beat in pat: add(bass(m2f(rootm - 12 + (12 if (beat == 1.5 and not bsoft) else 0)), q * (1 if bsoft else .9), r, .6 * lvl, bsoft), t0 + sw(beat) * q, -.05, 1, .05)
        # arpejo / acompanhamento
        if S["arp"] and sect != "intro":
            for k in range(8):
                m = tri[k % len(tri)] + (12 if k % 4 == 3 else 0); add(pluck(m2f(m), q * .9, r, .32 * lvl, .6), t0 + sw(k * .5) * q, .25 if k % 2 else -.25, 1, .22)
        # melodia (a partir do compasso 2, em frases de 2 compassos)
        if b >= 2 and sect != "intro" and style != "suspense":
            mm = motif if b % 2 == 0 else [motif[0], motif[1], motif[3], motif[2]] if style != "toon" else motif[::-1]
            for k, d in enumerate(mm):
                if r.uniform() < .15: continue
                m = _deg(mode, d + deg, root + 12 + (12 if S["lead"] in ("bell", "pizz") else 0)); tm = t0 + sw(k) * q
                fn = {"bell": bell, "soft": softkey, "pizz": lambda f, d_, r_, v: pluck(f, d_, r_, v, .9)}[S["lead"]]
                add(fn(m2f(m), q * 1.8, r, .42 * lvl), tm, .2, 1, .3)
        if style == "suspense":  # tic constante + nota grave que sobe
            for k in range(8): add(tickn(2200 if k % 2 == 0 else 1800, .1, r, .18 * (.5 + .5 * b / nb)), t0 + k * q * .5, .3, 1, .1)
            add(softkey(m2f(rootm + 12 + (b % 3)), bar, r, .18), t0, -.2, 1, .4)
        # bateria
        D = S["drums"]
        if D != "none" and sect != "intro":
            for k in range(8):
                tb = t0 + sw(k * .5) * q; on = k % 2 == 0
                if D in ("pop", "march"):
                    if k in (0, 4) or (D == "march" and k in (2, 6)): add(kick(r, .8 * lvl), tb, 0, 1, .02)
                    if k in (2, 6): add(snare(r, .55 * lvl), tb, .05, 1, .12)
                    add(hat(r, .22 * lvl, k == 7), tb, .3, 1, .05)
                elif D == "lofi":
                    if k in (0, 5): add(kick(r, .7 * lvl), tb, 0, 1, .02)
                    if k in (2, 6): add(snare(r, .4 * lvl) * .7, tb, 0, 1, .1)
                    add(hat(r, .16 * lvl), tb, .3, 1, .05)
                elif D == "toon":
                    if on: add(kick(r, .6 * lvl) if k in (0, 4) else rim(r, .5 * lvl), tb, 0, 1, .03)
                    if k % 4 == 3: add(snare(r, .35 * lvl), tb, 0, 1, .1)
                elif D == "bossa":
                    if k in (0, 3, 4, 7): add(kick(r, .45 * lvl) * .8, tb, 0, 1, .02)
                    if k in (1, 3, 4, 6, 7): add(rim(r, .45 * lvl), tb, .3, 1, .06)
                    add(hat(r, .12 * lvl), tb, -.3, 1, .05)
    # fim: nota final + fade
    out += .5 * convolve_st(sends, make_ir(1.1, 5 + seed, hf=1.4))
    out = hp(out, 35, 2)
    f_out = min(1.6, dur * .2); k = ns(f_out); out[:, N - k:] *= np.linspace(1, 0, k)[None, :] ** 1.5
    fi = ns(.15); out[:, :fi] *= np.linspace(0, 1, fi)[None, :]
    return out


def compose(style="alegre", dur=10.0, bpm=None, key="C", seed=1, intensity=1.0, engine="auto"):
    """engine: 'auto' (instrumentos reais se o SoundFont existir; senão sintetizador próprio) | 'sf2' | 'synth'"""
    if engine in ("auto", "sf2"):
        try:
            import music_sf2
            if music_sf2.available(): return music_sf2.compose(style, dur, bpm, key, seed, intensity)
        except Exception as e:
            if engine == "sf2": raise
            print("aviso: música com SoundFont falhou, usando sintetizador:", e)
    return compose_synth(style, dur, bpm, key, seed, intensity)
