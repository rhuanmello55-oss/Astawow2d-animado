"""dsp.py — kit de áudio do Astawow (numpy + scipy). Código próprio: filtros, ruídos, envelopes, pan, reverb sintético,
medidor de loudness BS.1770 (LUFS), true peak, limiter com look-ahead, WAV 16/24 bits."""
import wave
import numpy as np
from scipy import signal

SR = 48000
TAU = 2 * np.pi

def ns(t): return int(round(t * SR))
def tt(d): return np.arange(ns(d)) / SR
def dbg(db): return 10.0 ** (db / 20.0)
def rng(seed): return np.random.default_rng(int(seed) & 0x7FFFFFFF)
def m2f(m): return 440.0 * 2 ** ((m - 69) / 12.0)

# ---------- filtros
def _sos(kind, f, order): return signal.butter(order, f, btype=kind, fs=SR, output="sos")
def lp(x, f, order=2): return signal.sosfilt(_sos("lowpass", min(f, SR * .45), order), x, axis=-1)
def hp(x, f, order=2): return signal.sosfilt(_sos("highpass", f, order), x, axis=-1)
def bp(x, lo, hi, order=2): return signal.sosfilt(_sos("bandpass", [lo, min(hi, SR * .45)], order), x, axis=-1)

def _biquad(kind, f0, q=.707, gain_db=0.0):
    A = 10 ** (gain_db / 40); w = TAU * f0 / SR; cw, sw = np.cos(w), np.sin(w); al = sw / (2 * q)
    if kind == "peak": b = [1 + al * A, -2 * cw, 1 - al * A]; a = [1 + al / A, -2 * cw, 1 - al / A]
    elif kind == "bpf": b = [al, 0, -al]; a = [1 + al, -2 * cw, 1 - al]
    else: raise ValueError(kind)
    a = np.array(a, float); return np.array(b, float) / a[0], a / a[0]
def peq(x, f0, gain_db, q=1.0): b, a = _biquad("peak", f0, q, gain_db); return signal.lfilter(b, a, x, axis=-1)
def reson(x, f0, q): b, a = _biquad("bpf", f0, q); return signal.lfilter(b, a, x, axis=-1)
def resbank(x, modes):
    y = np.zeros_like(x)
    for f, q, g in modes:
        if f < SR * .45: y += g * reson(x, f, q)
    return y

# ---------- ruídos e envelopes
def colored(n, r, slope=0.0, lo=20.0):
    """ruído com espectro ~ f^-slope (0 branco, 1 rosa, 2 marrom), desvio 1"""
    X = np.fft.rfft(r.standard_normal(n)); f = np.maximum(np.fft.rfftfreq(n, 1 / SR), lo)
    x = np.fft.irfft(X * f ** (-slope / 2), n); return x / (np.std(x) + 1e-12)

def smooth_noise(n, r, rate_hz, ctrl=200):
    """curva aleatória lenta ~[-1,1] (rajadas de vento, desafino, vibrato natural)"""
    m = max(4, int(n / SR * ctrl) + 4); c = r.standard_normal(m)
    c = signal.sosfiltfilt(signal.butter(2, min(rate_hz / (ctrl / 2), .99), output="sos"), c); c /= np.max(np.abs(c)) + 1e-12
    return np.interp(np.arange(n) / SR * ctrl, np.arange(m), c)

def ramp(n): u = np.linspace(0, 1, max(n, 1)); return .5 - .5 * np.cos(np.pi * u)
def fades(x, fin=.003, fout=.01):
    x = np.array(x, float, copy=True); a, b = ns(fin), ns(fout); n = x.shape[-1]
    if a > 0: k = min(a, n); x[..., :k] *= ramp(a)[:k]
    if b > 0: k = min(b, n); x[..., n - k:] *= ramp(b)[::-1][-k:]
    return x
def phase(f): return TAU * np.cumsum(f) / SR
def curve(n, pts, t0=0.0): return np.interp(t0 + np.arange(n) / SR, [p[0] for p in pts], [p[1] for p in pts])

def modal(dur, modes, r=None, glide=0.0, glide_tau=.02):
    """soma de senos com decaimento exponencial: modes=[(freq, amp, tau)] — sinos, madeira, metal"""
    t = tt(dur); y = np.zeros_like(t); g = 1 + glide * np.exp(-t / glide_tau) if glide else None
    for f, a, tau in modes:
        if f >= SR * .45: continue
        p0 = r.uniform(0, TAU) if r is not None else 0.0
        y += a * np.exp(-t / tau) * (np.sin(TAU * f * t + p0) if g is None else np.sin(phase(f * g) + p0))
    return y

def shape(x, gain, nper=1024, hop=256):
    """ganho espectral variável no tempo via STFT: gain(times[F], freqs[B]) -> (B,F)"""
    n = len(x); f, t, Z = signal.stft(x, fs=SR, window="hann", nperseg=nper, noverlap=nper - hop, boundary="zeros", padded=True)
    _, y = signal.istft(Z * gain(t, f), fs=SR, window="hann", nperseg=nper, noverlap=nper - hop, boundary=True)
    y = y[:n]; return y if len(y) == n else np.pad(y, (0, n - len(y)))

# ---------- estéreo
def pan(x, p=0.0):
    th = (float(np.clip(p, -1, 1)) + 1) * np.pi / 4; return np.stack([x * np.cos(th), x * np.sin(th)]) * np.sqrt(2)
def st(x):
    x = np.asarray(x, float)
    if x.ndim == 1: return np.stack([x, x])
    return np.concatenate([x, x]) if x.shape[0] == 1 else x
def place(buf, x, t, gain=1.0):
    x = st(x); i = ns(t); a, b = max(0, i), min(buf.shape[1], i + x.shape[1])
    if b > a: buf[:, a:b] += gain * x[:, a - i:b - i]
def widen(x, ms=11.0, amount=.5):
    d = ns(ms / 1000); y = np.pad(x, (0, d)); dl = np.pad(x, (d, 0))
    return np.stack([y + amount * .5 * dl, y - amount * .5 * dl])[:, :len(x)] / (1 + .25 * amount)

# ---------- reverb
def make_ir(rt60, seed, pre=.01, hf=1.0):
    """IR estéreo sintética: ruído decorrelacionado, agudos decaem mais rápido (hf)"""
    r = rng(seed); n = ns(rt60 * 1.1); t = np.arange(n) / SR; ir = np.zeros((2, n))
    for ch in range(2):
        z = r.standard_normal(n) * np.exp(-6.91 * t / rt60)
        z = lp(z, 9000 / max(hf, .5), 1); ir[ch] = z * np.minimum(1, t / .015)
    ir /= np.sqrt(np.sum(ir ** 2) / 2); return np.concatenate([np.zeros((2, ns(pre))), ir], axis=1)
def convolve_st(x, ir):
    n = x.shape[-1]; x = x if x.ndim == 1 else x.mean(0)
    return np.stack([signal.fftconvolve(x, ir[c])[:n] for c in range(2)])

# ---------- loudness (ITU-R BS.1770-4)
_KB1 = np.array([1.53512485958697, -2.69169618940638, 1.19839281085285]); _KA1 = np.array([1.0, -1.69065929318241, .73248077421585])
_KB2 = np.array([1.0, -2.0, 1.0]); _KA2 = np.array([1.0, -1.99004745483398, .99007225036621])
def _kf(x): return signal.lfilter(_KB2, _KA2, signal.lfilter(_KB1, _KA1, x, axis=-1), axis=-1)
def _blocks(x, win, hop):
    x = st(x); z2 = _kf(x) ** 2; c = np.concatenate([np.zeros((2, 1)), np.cumsum(z2, axis=-1)], axis=-1); w, h = ns(win), ns(hop)
    if x.shape[1] < w: z = (c[:, -1] / max(x.shape[1], 1)).sum(); return np.array([-.691 + 10 * np.log10(z + 1e-30)]), np.array([z])
    s = np.arange(0, x.shape[1] - w + 1, h); z = ((c[:, s + w] - c[:, s]) / w).sum(0); return -.691 + 10 * np.log10(z + 1e-30), z
def integrated(x):
    L, z = _blocks(x, .4, .1); keep = L > -70
    if not keep.any(): return -np.inf
    rel = -.691 + 10 * np.log10(z[keep].mean()) - 10; k2 = keep & (L > rel)
    return -.691 + 10 * np.log10(z[k2].mean()) if k2.any() else -np.inf
def momentary(x, hop=.01): return _blocks(x, .4, hop)[0]
def momentary_max(x): return float(momentary(x).max())
def true_peak(x): return 20 * np.log10(np.abs(signal.resample_poly(st(x), 4, 1, axis=-1)).max() + 1e-30)

def limiter(x, ceil_db=-1.2, look=.003, rel=.08):
    """limiter com detecção 4x oversampled + look-ahead; teto em dBTP"""
    from scipy import ndimage
    c = dbg(ceil_db); n = x.shape[1]
    up = np.abs(signal.resample_poly(x, 4, 1, axis=-1)).max(0)
    pk = np.pad(up, (0, max(0, 4 * n - len(up))))[:4 * n].reshape(n, 4).max(1)
    gr = np.minimum(1.0, c / np.maximum(pk, 1e-12)); La = max(1, ns(look))
    g1 = ndimage.minimum_filter1d(gr, 2 * La + 1, mode="nearest")
    inv = 1 - g1
    red = ndimage.maximum_filter1d(inv, ns(rel))          # segura a redução (release)
    g2 = np.minimum(g1, 1 - ndimage.uniform_filter1d(red, 2 * La + 1, mode="nearest"))
    return x * g2[None, :], g2

# ---------- WAV
def read_wav(path):
    with wave.open(path, "rb") as w:
        n, ch, sw, sr = w.getnframes(), w.getnchannels(), w.getsampwidth(), w.getframerate(); raw = w.readframes(n)
    if sw == 2: x = np.frombuffer(raw, "<i2").astype(float) / 32768
    elif sw == 3:
        b = np.frombuffer(raw, np.uint8).reshape(-1, 3).astype(np.int32); v = b[:, 0] | (b[:, 1] << 8) | (b[:, 2] << 16)
        x = np.where(v >= 1 << 23, v - (1 << 24), v).astype(float) / (1 << 23)
    elif sw == 4: x = np.frombuffer(raw, "<i4").astype(float) / (1 << 31)
    else: raise ValueError(sw)
    return x.reshape(-1, ch).T, sr
def write_wav(path, x, bits=16):
    x = st(x); ch, n = x.shape
    if bits == 24:
        q = np.clip(np.round(x.T * 8388607), -8388608, 8388607).astype("<i4")
        data = np.ascontiguousarray(q).view(np.uint8).reshape(n, ch, 4)[:, :, :3].tobytes(); sw = 3
    else: data = np.clip(np.round(x.T * 32767), -32768, 32767).astype("<i2").tobytes(); sw = 2
    with wave.open(path, "wb") as w: w.setnchannels(ch); w.setsampwidth(sw); w.setframerate(SR); w.writeframes(data)
