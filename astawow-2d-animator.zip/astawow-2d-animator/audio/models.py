"""models.py — baixa (uma vez) os modelos opcionais que deixam o áudio MUITO melhor, guardando em ~/.cache/astawow (ou $ASTAWOW_CACHE).
  voz  : Kokoro-82M (ONNX int8, ~120 MB total, licença Apache-2.0) — vozes neurais em português do Brasil
  sf2  : GeneralUser GS (SoundFont, 32 MB, licença permissiva GS) — instrumentos reais p/ a música
Tudo vem de GitHub (raw/releases). Sem internet ou sem modelo → a skill cai no sintetizador próprio (funciona, mas soa mais "de brinquedo").
python3 audio/models.py            baixa tudo      |  python3 audio/models.py --check   só mostra o que existe"""
import os, socket, sys, urllib.request
socket.setdefaulttimeout(30)
CACHE = os.environ.get("ASTAWOW_CACHE", os.path.join(os.path.expanduser("~"), ".cache", "astawow"))
K = "https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/"
FILES = {
    "kokoro.onnx": (K + "kokoro-v1.0.int8.onnx", 80_000_000),
    "voices.bin": (K + "voices-v1.0.bin", 20_000_000),
    "gm.sf2": ("https://raw.githubusercontent.com/mrbumpy409/GeneralUser-GS/main/GeneralUser-GS.sf2", 20_000_000),
}
GROUPS = {"voz": ["kokoro.onnx", "voices.bin"], "sf2": ["gm.sf2"]}

def path(name): return os.path.join(CACHE, name)
def have(group): return all(os.path.exists(path(f)) and os.path.getsize(path(f)) > FILES[f][1] for f in GROUPS[group])

def ensure(group, quiet=False):
    """garante os arquivos do grupo ('voz' ou 'sf2'); True se disponíveis"""
    if have(group): return True
    os.makedirs(CACHE, exist_ok=True)
    for f in GROUPS[group]:
        p = path(f)
        if os.path.exists(p) and os.path.getsize(p) > FILES[f][1]: continue
        if not quiet: print(f"baixando {f} (uma vez só)…", flush=True)
        try:
            tmp = p + ".part"; urllib.request.urlretrieve(FILES[f][0], tmp)
            if os.path.getsize(tmp) < FILES[f][1]: raise IOError("arquivo pequeno demais")
            os.replace(tmp, p)
        except Exception as e:
            if not quiet: print(f"  não consegui baixar {f}: {e}", file=sys.stderr)
            return False
    return have(group)

if __name__ == "__main__":
    if "--check" in sys.argv: print({g: have(g) for g in GROUPS}); sys.exit(0)
    print({g: ensure(g) for g in GROUPS})
