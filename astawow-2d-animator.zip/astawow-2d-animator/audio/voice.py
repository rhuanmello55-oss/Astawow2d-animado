"""voice.py — vozes de personagem sintetizadas (fonte glótica + formantes), sincronizadas com o texto.
NÃO é narração realista: é "fala de desenho" (tipo balbucio expressivo) para personagens falarem sem baixar nada.
Narração de verdade = arquivo de voz do usuário (voz.mp3/wav). speak(text, who) -> (mono, duração)."""
import re
import numpy as np
from dsp import *

VOWELS = "aeiouáéíóúâêôãõàü"
FORM = {"a": (800, 1200, 2500), "á": (820, 1250, 2500), "â": (700, 1150, 2500), "ã": (700, 1100, 2400), "à": (800, 1200, 2500),
        "e": (500, 1800, 2500), "é": (620, 1750, 2500), "ê": (430, 1900, 2550), "i": (300, 2250, 3000), "í": (300, 2300, 3000),
        "o": (500, 900, 2400), "ó": (600, 950, 2400), "ô": (440, 850, 2400), "õ": (450, 850, 2300), "u": (320, 800, 2300), "ú": (320, 800, 2300), "ü": (320, 800, 2300)}
# who: f0 médio (Hz), escala de formantes, vibrato, entonação, "robo" (buzz), velocidade (s/sílaba)
CHARS = {
    "narrador": dict(f0=118, fs=1.0, vib=.012, intn=.10, spd=.17),
    "gato":     dict(f0=96,  fs=.92, vib=.015, intn=.14, spd=.19),
    "rato":     dict(f0=300, fs=1.28, vib=.02, intn=.18, spd=.13),
    "crianca":  dict(f0=330, fs=1.32, vib=.018, intn=.20, spd=.14),
    "menino":   dict(f0=260, fs=1.2, vib=.015, intn=.16, spd=.15),
    "vovo":     dict(f0=205, fs=1.05, vib=.035, intn=.12, spd=.21),
    "chefe":    dict(f0=78,  fs=.85, vib=.008, intn=.08, spd=.20),
    "robo":     dict(f0=140, fs=1.0, vib=0, intn=0, spd=.15, robo=True),
    "mulher":   dict(f0=215, fs=1.12, vib=.016, intn=.14, spd=.16),
    "caixa":    dict(f0=190, fs=1.08, vib=.012, intn=.12, spd=.15),
}
NAMES = sorted(CHARS)

def _syl(word):
    w = word.lower(); out = []
    for m in re.finditer(rf"([^{VOWELS}]*)([{VOWELS}]+)", w): out.append([m.group(1), m.group(2)])
    tail = re.sub(rf"^.*[{VOWELS}]", "", w)
    if out and tail: out[-1].append(tail)
    return out or [[w, "a"]]

def _cons(kind, r, n, amp=1.0):
    t = np.arange(n) / SR
    if kind in "sxzfçjv": return hp(r.standard_normal(n), 3500 if kind in "sxzç" else 1800) * np.sin(np.pi * np.minimum(t / (n / SR), 1)) * .5 * amp
    if kind in "ptkcqb": return hp(r.standard_normal(n), 900) * np.exp(-t / .012) * .9 * amp
    return np.zeros(n)

def _vowel(r, f0c, v, n, fs, vib, robo):
    t = np.arange(n) / SR; f = f0c * (1 + vib * np.sin(TAU * 5.5 * t + r.uniform(0, TAU)) + .006 * smooth_noise(n, r, 4))
    ph = phase(f); src = 2 * ((ph / TAU) % 1) - 1
    if robo: src = np.sign(np.sin(ph)) * .6 + .4 * np.sin(ph * 2)
    F = FORM.get(v[0], FORM["a"]); y = np.zeros(n)
    for fi, q, g in zip(F, (7, 9, 11), (1.0, .55, .25)): y += g * reson(src, min(fi * fs, 5500), q)
    y += .08 * hp(r.standard_normal(n), 2500)
    a = np.minimum(1, t / .015) * np.minimum(1, (n / SR - t) / .03)
    return y * a

def babble_word(r, text, f0=200, dur=None, fs=1.0, vib=.015, intn=.14, spd=.17, robo=False, accent=1.0):
    """fala `text` (pt-BR/qualquer) como balbucio de personagem; dur força a duração total."""
    words = [w for w in re.split(r"\s+", text.strip()) if w]; plan = []
    for w in words:
        sy = _syl(re.sub(r"[^\wáéíóúâêôãõàüç]", "", w.lower()))
        for k, s in enumerate(sy): plan.append((s, k == len(sy) - 1, w))
        plan.append((None, False, w))
    sylN = sum(1 for p in plan if p[0]); gaps = sum(1 for p in plan if p[0] is None)
    base = spd; total = sylN * base + gaps * .05
    sc = (dur / total) if dur else 1.0; out = []
    ends_q = text.strip().endswith("?"); ends_e = text.strip().endswith("!")
    wi = 0
    for (s, last, w) in plan:
        if s is None: out.append(np.zeros(ns(.05 * sc))); wi += 1; continue
        cons = s[0][-1:] if s[0] else ""; vow = s[1]; d = base * sc; n = ns(d)
        stress = 1.0 + (.07 if (last and s is not None) else 0) + r.uniform(-.04, .04)
        prog = wi / max(len(words), 1); f0c = f0 * stress * (1 + intn * (.5 - prog)) * accent
        if ends_q and wi == len(words) - 1: f0c *= 1.25 if last else 1.1
        if ends_e: f0c *= 1.06
        nc = ns(.035) if cons else 0; seg = np.zeros(n)
        if nc: seg[:nc] += _cons(cons, r, nc)[:n]
        v = _vowel(r, f0c, vow, max(n - nc, ns(.04)), fs, vib, robo); seg[nc:nc + len(v)] += v[:n - nc]
        if len(s) > 2 and s[2]: seg[-ns(.02):] *= .3
        out.append(seg)
    y = np.concatenate(out) if out else np.zeros(ns(.1)); pk = np.abs(y).max() + 1e-9
    return fades(y / pk * .8, .004, .02)

def speak(text, who="narrador", dur=None, seed=1, pitch=1.0, speed=1.0):
    """voz de personagem. who: ver NAMES. dur (s) opcional: estica a fala p/ caber exatamente na cena/legenda."""
    c = dict(CHARS.get(who, CHARS["narrador"])); r = rng(hash((text, who, seed)) & 0xFFFFFF)
    y = babble_word(r, text, f0=c["f0"] * pitch, dur=dur, fs=c["fs"], vib=c["vib"], intn=c["intn"], spd=c["spd"] / speed, robo=c.get("robo", False))
    return y, len(y) / SR

def render_lines(lines, total, seed=1, use_tts=True):
    """lines=[{t, text, who, dur?, pan?}] -> (stereo, spans[(t0,t1)], words[{w,t0,t1}], engine)
    engine = 'tts' (voz neural real, se o modelo existir) ou 'balbucio' (fala de desenho)."""
    out = np.zeros((2, ns(total))); spans = []; words = []; eng = "balbucio"
    try:
        import tts as T
    except Exception: T = None
    for i, L in enumerate(lines):
        y = None
        if use_tts and T is not None and T.available():
            try: y = T.speak_tts(L["text"], L.get("who", "narrador"), L.get("speed", 1.0), L.get("pitch", 1.0)); eng = "tts"
            except Exception as e: print("aviso: TTS falhou, usando balbucio:", e); y = None
        if y is None: y, _ = speak(L["text"], L.get("who", "narrador"), L.get("dur"), seed + i, L.get("pitch", 1.0), L.get("speed", 1.0))
        place(out, pan(y, L.get("pan", 0.0)), L["t"], L.get("gain", 1.0)); d = len(y) / SR; spans.append((L["t"], L["t"] + d))
        if L.get("caption", True):
            try: words += T.word_times(L["text"], L["t"] + .03, d - .06)
            except Exception: pass
    return out, spans, words, eng
