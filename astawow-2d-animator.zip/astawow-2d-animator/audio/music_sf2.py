"""music_sf2.py — trilha com INSTRUMENTOS REAIS (SoundFont GeneralUser GS via tinysoundfont). Mesma composição do music.py
(progressão, motivo, intro→corpo→fim), mas violão, marimba, baixo acústico, cordas, vibrafone e bateria de verdade.
Sem o SoundFont/lib, music.compose() cai sozinho no sintetizador próprio."""
import numpy as np
from dsp import *
import models
from music import STYLES, KEYS, _deg

GM = dict(violao=24, marimba=12, baixo=32, cordas=48, pizz=45, vibra=11, epiano=4, flauta=73, trompa=60, tuba=58, xilo=13, glock=9, pad=89, celo=42, tima=47, harpa=46, trompete=56, piano=0)
# estilo: instrumentos (acomp, melodia, baixo, colchão), kit de bateria (GM preset), volume
SETUP = {
    "alegre":   dict(acomp="violao", lead="marimba", bass="baixo", bed="cordas", kit=0),
    "aventura": dict(acomp="cordas", lead="trompa", bass="tuba", bed="cordas", kit=0),
    "lofi":     dict(acomp="epiano", lead="vibra", bass="baixo", bed="pad", kit=40),
    "suspense": dict(acomp="pizz", lead="glock", bass="celo", bed="pad", kit=None),
    "toon":     dict(acomp="pizz", lead="xilo", bass="tuba", bed=None, kit=0),
    "mercado":  dict(acomp="violao", lead="flauta", bass="baixo", bed="cordas", kit=0),
}
_S = {}
def available():
    try: import tinysoundfont; return models.have("sf2")
    except Exception: return False

def _synth(kit_preset):
    import tinysoundfont
    s = tinysoundfont.Synth(samplerate=SR, gain=-2); sf = s.sfload(models.path("gm.sf2")); return s, sf

def compose(style="alegre", dur=10.0, bpm=None, key="C", seed=1, intensity=1.0):
    S = STYLES[style]; U = SETUP[style]; r = rng(seed * 131 + len(style)); bpm = bpm or S["bpm"]; q = 60.0 / bpm; bar = 4 * q
    root = 48 + KEYS.get(key.upper(), 0); mode = S["mode"]; nb = int(np.ceil(dur / bar)) + 1
    motif = [int(x) for x in r.choice([0, 1, 2, 2, 3, 4, 5], 4)]; motif[0] = 4 if style != "suspense" else 0
    swing = S["swing"]; ev = []   # (t, dur, midi, vel, canal)
    CH = dict(acomp=0, lead=1, bass=2, bed=3, drums=9)
    def sw(b): return b + (swing * .5 if abs(b * 2 - round(b * 2)) < 1e-6 and int(round(b * 2)) % 2 == 1 else 0)
    def add(t, d, m, v, ch): ev.append((t + r.normal(0, .006), d, int(m), int(np.clip(v * (1 + r.normal(0, .06)), 20, 127)), ch))
    for b in range(nb):
        t0 = b * bar
        if t0 >= dur: break
        sect = "intro" if b < 2 else ("fim" if t0 > dur - 2 * bar else "corpo"); lv = {"intro": .6, "corpo": 1.0, "fim": .75}[sect] * intensity
        deg = S["prog"][b % len(S["prog"])]; rootm = _deg(mode, deg, root); tri = [_deg(mode, deg + k, root + 12) for k in (0, 2, 4)]
        # colchão (acorde longo)
        if U["bed"]:
            for m in tri: add(t0, bar * .98, m - (12 if style in ("suspense", "lofi") else 0), 46 * lv, CH["bed"])
        # baixo
        pat = [0, 2] if sect == "intro" else ([0, 1.5, 2, 3] if style not in ("lofi", "suspense") else [0, 2.5])
        for beat in pat: add(t0 + sw(beat) * q, q * .9, rootm - 12 + (7 if beat in (1.5, 3) and style != "suspense" else 0), 84 * lv, CH["bass"])
        # acompanhamento: arpejo (violão/pizz/epiano)
        if sect != "intro" or style in ("lofi", "suspense"):
            if style in ("lofi",):
                for k, m in enumerate(tri + [tri[0] + 12]): add(t0 + (0 if k < 4 else 0), q * 1.9 if k < 4 else 0, m, 62 * lv, CH["acomp"])   # acorde de piano elétrico
                add(t0 + 2 * q, q * 1.9, tri[1], 54 * lv, CH["acomp"])
            elif style == "suspense":
                for k in range(8): add(t0 + k * q * .5, .1, tri[k % 3] + 12, (40 + 12 * (b % 3)) * lv, CH["acomp"])
            else:
                for k in range(8): add(t0 + sw(k * .5) * q, q * .8, tri[k % 3] + (12 if k % 4 == 3 else 0), (66 if k % 2 == 0 else 54) * lv, CH["acomp"])
        # melodia
        if b >= 2 and sect != "intro" and style != "suspense":
            mm = motif if b % 2 == 0 else [motif[0], motif[1], motif[3], motif[2]]
            for k, d in enumerate(mm):
                if r.uniform() < .15: continue
                add(t0 + sw(k) * q, q * (1.6 if k % 2 == 0 else .9), _deg(mode, d + deg, root + 12 + (12 if style in ("alegre", "toon") else 0)), 78 * lv, CH["lead"])
        if style == "suspense" and b >= 1: add(t0, bar * .95, rootm - 12, 70 * lv, CH["bass"])
        # bateria
        kit = U["kit"]
        if kit is not None and sect != "intro":
            D = S["drums"]
            for k in range(8):
                tb = t0 + sw(k * .5) * q
                if D in ("pop", "march"):
                    if k in (0, 4) or (D == "march" and k in (2, 6)): add(tb, .1, 36, 100 * lv, 9)
                    if k in (2, 6): add(tb, .1, 38, 84 * lv, 9)
                    add(tb, .05, 42 if k != 7 else 46, 52 * lv, 9)
                elif D == "lofi":
                    if k in (0, 5): add(tb, .1, 36, 80 * lv, 9)
                    if k in (2, 6): add(tb, .1, 38, 58 * lv, 9)
                    add(tb, .05, 42, 38 * lv, 9)
                elif D == "toon":
                    if k % 2 == 0: add(tb, .1, 36 if k in (0, 4) else 37, 86 * lv, 9)
                    if k % 4 == 3: add(tb, .1, 38, 60 * lv, 9)
                elif D == "bossa":
                    if k in (0, 3, 4, 7): add(tb, .1, 36, 70 * lv, 9)
                    if k in (1, 3, 4, 6, 7): add(tb, .05, 37, 66 * lv, 9)
                    add(tb, .05, 70, 44 * lv, 9)
    # ---- render
    syn, sf = _synth(U["kit"])
    prog = {0: GM[U["acomp"]], 1: GM[U["lead"]], 2: GM[U["bass"]], 3: GM[U["bed"] or "cordas"]}
    for ch, p in prog.items(): syn.program_select(ch, sf, 0, p)
    syn.program_select(9, sf, 128, U["kit"] or 0, True) if U["kit"] is not None else None
    N = ns(dur) + ns(2.0); out = np.zeros((2, N))
    sched = []
    for (t, d, m, v, ch) in ev:
        if t < 0 or t >= dur: continue
        sched.append((ns(t), 1, ch, m, v)); sched.append((ns(t + max(d, .05)), 0, ch, m, 0))
    sched.sort(key=lambda x: (x[0], x[1]))   # noteoff antes de noteon no mesmo instante
    pos = 0
    def gen(n):
        b = np.frombuffer(bytes(syn.generate(n)), dtype=np.float32).reshape(-1, 2).T; return b.astype(float)
    for (p, on, ch, m, v) in sched:
        p = min(p, N)
        if p > pos: seg = gen(p - pos); out[:, pos:pos + seg.shape[1]] += seg[:, :N - pos]; pos += seg.shape[1]
        (syn.noteon(ch, m, v) if on else syn.noteoff(ch, m))
    if N > pos: seg = gen(N - pos); out[:, pos:pos + seg.shape[1]] += seg[:, :N - pos]
    out = out[:, :ns(dur)]
    out += .22 * convolve_st(out.mean(0), make_ir(1.0, 11 + seed, hf=1.3))          # sala suave
    out = hp(out, 35, 2); f = min(1.6, dur * .2); k = ns(f); out[:, -k:] *= np.linspace(1, 0, k)[None, :] ** 1.5
    return out
