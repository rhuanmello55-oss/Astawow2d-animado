"""sfx_lib.py — biblioteca de efeitos sonoros sintetizados (sem baixar nada). Cada efeito: fn(r) -> mono (np.array, SR=48k).
make(name, seed) devolve o som; NAMES lista tudo. Pensado p/ desenho animado 2D: pop, boing, bonk, bam, whoosh, passos, porta,
caixa registradora, moedas, splash, rangido, apito de deslizar, queda, soco, risada-boba, ding, tada, sparkle, bip, clique, etc."""
import numpy as np
from dsp import *

def _env(n, att=.004, rel=None):
    e = np.ones(n); a = max(1, ns(att)); e[:a] = np.linspace(0, 1, a)
    k = min(n, ns(rel) if rel else n); e[n - k:] *= np.linspace(1, 0, k) ** 2; return e

def pop(r):  t = tt(.16); f = 1000 * np.exp(-t / .045) + 200; return np.sin(phase(f)) * np.exp(-t / .05) * .9
def boing(r):
    t = tt(.7); f = 380 * (1 - .55 * t / .7) * (1 + .09 * np.sin(TAU * 16 * t) * np.exp(-t / .3)); y = np.sin(phase(f)) + .35 * np.sin(2 * phase(f))
    return y * np.exp(-t / .28) * .6
def bonk(r):
    t = tt(.35); y = np.sin(phase(230 * np.exp(-t / .08) + 80)) * np.exp(-t / .09)
    y += modal(.35, [(420, .3, .05), (690, .2, .03)], r); y += hp(r.standard_normal(len(t)), 1500) * np.exp(-t / .004) * .3; return y * .9
def bam(r):
    t = tt(.7); y = np.sin(phase(150 * np.exp(-t / .06) + 42)) * np.exp(-t / .22) * 1.2
    y += lp(r.standard_normal(len(t)), 700) * np.exp(-t / .1) * .9; y += hp(r.standard_normal(len(t)), 2000) * np.exp(-t / .006) * .5; return y
def whoosh(r, d=.5, f0=300, f1=2500):
    n = ns(d); nz = colored(n, r, .6); t = np.arange(n) / SR; u = t / d; fc = f0 + (f1 - f0) * np.sin(np.pi * u * .5) ** 2
    y = shape(nz, lambda T, F: np.exp(-.5 * (np.log2(np.maximum(F[:, None], 20) / np.interp(T, t, fc)[None, :]) / .8) ** 2), 1024, 256)
    return y * np.sin(np.pi * u) ** 1.6 * 1.4
def whoosh_up(r): return whoosh(r, .55, 250, 3500)
def whoosh_down(r): return whoosh(r, .55, 3000, 250)
def ding(r):  return modal(1.0, [(1318, 1, .5), (1976, .45, .3), (2637, .2, .15)], r) * .5
def tada(r):
    y = np.zeros(ns(1.3))
    for o, m in [(0, 72), (.13, 76), (.26, 79), (.42, 84)]:
        n = modal(.9, [(m2f(m), 1, .35), (m2f(m) * 2, .3, .2), (m2f(m) * 3, .12, .1)], r); i = ns(o); y[i:i + len(n)] += n[:len(y) - i] * .4
    return y
def sparkle(r):
    y = np.zeros(ns(.7))
    for k, m in enumerate([96, 100, 103, 108, 112]):
        n = modal(.3, [(m2f(m), 1, .09)], r); i = ns(k * .06); y[i:i + len(n)] += n[:len(y) - i] * .3
    return y
def bip(r): t = tt(.1); return (np.sign(np.sin(TAU * 1700 * t)) * .35 + np.sin(TAU * 1700 * t) * .5) * _env(len(t), .001, .02)
def click(r): t = tt(.05); return (bp(r.standard_normal(len(t)), 1200, 5000, 1) * np.exp(-t / .005) + .6 * np.sin(TAU * 950 * t) * np.exp(-t / .008)) * .8
def step(r):
    t = tt(.2); y = np.sin(phase(110 * np.exp(-t / .03) + 70)) * np.exp(-t / .04) + lp(r.standard_normal(len(t)), 1800) * np.exp(-t / .02) * .7
    return y * .9
def step_soft(r): return step(r) * .5
def door(r):
    t = tt(.5); y = modal(.5, [(150, 1, .12), (310, .6, .08), (640, .3, .05)], r) + lp(r.standard_normal(len(t)), 600) * np.exp(-t / .03); return y * .7
def creak(r, d=.6):
    n = ns(d); rate = 90 + 70 * np.linspace(0, 1, n); x = np.zeros(n); tm = 0.0
    while tm < d - .02:
        k = ns(tm); x[k] += r.uniform(.5, 1); tm += 1 / (rate[k] * (1 + r.normal(0, .1)))
    y = resbank(x, [(230, 9, 1), (520, 12, .8), (940, 14, .5), (1650, 16, .3)]); return fades(y * 3, .02, .08) * np.sin(np.pi * np.linspace(0, 1, n)) ** .5
def caixa(r):  # caixa registradora: clique + sino
    t = tt(.9); y = np.zeros(len(t)); y += hp(r.standard_normal(len(t)), 2000) * np.exp(-t / .006) * .6
    b = modal(.8, [(2400, 1, .35), (3600, .5, .2), (5300, .25, .1)], r); y[ns(.12):ns(.12) + len(b)] += b[:len(y) - ns(.12)] * .5; return y
def moedas(r):
    y = np.zeros(ns(.9))
    for k in range(6):
        c = modal(.25, [(r.uniform(3000, 5200), 1, .05), (r.uniform(6000, 8000), .5, .03)], r); i = ns(k * r.uniform(.05, .1)); y[i:i + len(c)] += c[:len(y) - i] * r.uniform(.3, .6)
    return y
def splash(r):
    n = ns(1.2); t = np.arange(n) / SR; nz = colored(n, r, .4)
    y = shape(nz, lambda T, F: np.exp(-.5 * (np.log2(np.maximum(F[:, None], 20) / (900 + 1500 * np.exp(-T[None, :] / .3))) / 1.3) ** 2), 1024, 256) * (1 - np.exp(-t / .01)) * np.exp(-t / .3)
    y += np.sin(phase(80 * np.exp(-t / .1) + 45)) * np.exp(-t / .15) * 1.2; return y
def apito_cai(r): t = tt(.9); f = 2200 * np.exp(-t / .45) + 250; return np.sin(phase(f) + .5 * np.sin(TAU * 7 * t)) * np.exp(-t / .6) * .5   # queda (slide whistle)
def apito_sobe(r): t = tt(.6); f = 300 + 1800 * (t / .6) ** 1.5; return np.sin(phase(f)) * _env(len(t), .01, .1) * .5
def soco(r): return bam(r) * .7 + hp(r.standard_normal(ns(.7)), 800) * np.exp(-tt(.7) / .02) * .5
def derrapa(r):
    n = ns(.7); t = np.arange(n) / SR; f = 1500 + 900 * np.sin(TAU * 3 * t); y = bp(r.standard_normal(n), 1200, 3800, 2) * np.sin(np.pi * t / .7) ** .8; return y * 1.2
def risada(r):  # "ha ha ha" boba (formante)
    from voice import babble_word
    return babble_word(r, "ha ha ha", f0=230, dur=.8)
def buzina(r): t = tt(.55); y = sum(np.sign(np.sin(TAU * f * t)) for f in (392, 494)) * .25; return y * _env(len(t), .01, .08)
def sino(r): return modal(1.8, [(880, 1, 1.2), (2400, .4, .6), (3900, .2, .3)], r) * .5
def passaro(r):
    y = np.zeros(ns(.9)); tm = 0
    for j in range(r.integers(3, 6)):
        L = r.uniform(.05, .1); tl = tt(L); f = r.uniform(3000, 5000) * (1 + .3 * tl / L * r.choice([-1, 1])); c = np.sin(phase(f)) * np.sin(np.pi * tl / L) ** 2; i = ns(tm); y[i:i + len(c)] += c[:len(y) - i] * .3; tm += L + r.uniform(.04, .1)
    return y
def zap(r): t = tt(.25); f = 3000 * np.exp(-t / .08) + 300; return np.sign(np.sin(phase(f))) * np.exp(-t / .1) * .35
def power(r): t = tt(.5); f = 200 * 2 ** (t / .5 * 2.5); return np.sin(phase(f)) * .4 * _env(len(t), .01, .1) + sparkle(r)[:len(t)] * .3
def erro(r): t = tt(.35); return (np.sign(np.sin(TAU * 140 * t)) * .3 + np.sin(TAU * 140 * t) * .3) * _env(len(t), .005, .08)
def digitar(r):  # tecla macia: 'tec' grave + estalo curto
    t = tt(.07); return (np.sin(TAU * 520 * t) * np.exp(-t / .012) + bp(r.standard_normal(len(t)), 900, 3500, 1) * np.exp(-t / .006) * .7) * .6
def tick(r): t = tt(.04); return np.sin(TAU * 1800 * t) * np.exp(-t / .006) * .5
def swipe(r): return whoosh(r, .25, 600, 4000) * .7
def queda(r):
    """objeto que cai: assobio descendo + pancada no fim"""
    y = np.zeros(ns(1.0)); w = apito_cai(r)[:ns(.55)] * .6; y[:len(w)] += w; b = bonk(r); y[ns(.5):ns(.5) + len(b)] += b[:len(y) - ns(.5)]; return y

_SKIP = {"np", "dsp"}
REG = {k: v for k, v in globals().items() if callable(v) and not k.startswith("_") and k in (
    "pop boing bonk bam whoosh whoosh_up whoosh_down ding tada sparkle bip click step step_soft door creak caixa moedas splash "
    "apito_cai apito_sobe soco derrapa risada buzina sino passaro zap power erro digitar tick swipe queda").split()}
NAMES = sorted(REG)

def make(name, seed=1):
    """gera o efeito `name` (mono, 48 kHz, pico ~<=1). Mesmo nome+seed = mesmo som (determinístico)."""
    if name not in REG: raise KeyError(f"sfx desconhecido: {name}. Disponíveis: {', '.join(NAMES)}")
    h = sum(ord(c) * (i + 7) for i, c in enumerate(name)) + int(seed) * 7919
    x = np.asarray(REG[name](rng(h)), float); pk = np.abs(x).max()
    return fades(x / pk * .9 if pk > 1 else x, .001, .02)
