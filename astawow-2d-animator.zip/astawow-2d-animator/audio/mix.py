"""mix.py — mixagem final: voz (sempre por cima) + música (ducking) + SFX + ambiente -> mix.wav (-14 LUFS, pico <= -1.2 dBTP).
Entrada: audio.json (ver templates/audio.json). Saída: mix.wav, stems/, relatorio.md (loudness, margem voz-vs-fundo, lista de cues)."""
import json, os, subprocess, sys, tempfile
import numpy as np
from dsp import *
import sfx_lib, voice as V, music as M

TARGET_LUFS = -14.0; CEIL = -1.2; VOICE_REF = -16.0

def load_voice_file(path, dur):
    tmp = tempfile.mktemp(suffix=".wav")
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", path, "-ac", "1", "-ar", str(SR), "-t", str(dur), tmp], check=True)
    x, _ = read_wav(tmp); os.remove(tmp); return st(x[0])

def speech_spans(v, merge=.35, thr_db=-38.0):
    m = v.mean(0); hop = ns(.02); n = len(m) // hop
    e = np.sqrt((m[:n * hop].reshape(n, hop) ** 2).mean(1) + 1e-12); on = 20 * np.log10(e) > (20 * np.log10(e.max() + 1e-12) + thr_db + 20)
    sp = []
    for i in np.flatnonzero(on):
        s, t = i * .02, (i + 1) * .02
        if sp and s - sp[-1][1] < merge: sp[-1][1] = t
        else: sp.append([s, t])
    return [(a, b) for a, b in sp if b - a > .08]

def duck_curve(spans, N, dur, depth=-7.0, pre=.08, post=.15, att=.06, rel=.4):
    ctrl = 500; nc = int(dur * ctrl) + 2; va = np.zeros(nc)
    for s, e in spans: va[max(0, int((s - pre) * ctrl)):int((e + post) * ctrl)] = 1.0
    ka, kr = 1 - np.exp(-1 / (att * ctrl)), 1 - np.exp(-1 / (rel * ctrl)); env = np.zeros(nc); e = 0.0
    for i in range(nc): tg = va[i]; e += (tg - e) * (ka if tg > e else kr); env[i] = e
    return np.interp(np.arange(N) / SR, np.arange(nc) / ctrl, depth * env)

def ambience(kind, dur, seed=7):
    n = ns(dur); r = rng(seed); out = np.zeros((2, n))
    if kind in (None, "none", ""): return out
    wind = lambda lvl, br: np.stack([lp(colored(n, r, 1.0), br, 2) * (.6 + .4 * smooth_noise(n, r, .2)) * lvl for _ in range(2)])
    def birds(density):
        y = np.zeros(n); tm = r.uniform(.2, 1.2)
        while tm < dur - .5:
            c = sfx_lib.make("passaro", int(r.integers(1000))) * r.uniform(.3, 1); i = ns(tm); y[i:i + len(c)] += c[:n - i]; tm += r.exponential(1 / density) + .5
        return y
    if kind == "rua":    # trânsito distante + vento + pássaros
        out += wind(.5, 900); out += np.stack([lp(colored(n, r, 2.0), 260, 2) * .5 for _ in range(2)]); out += pan(birds(.5) * .25, .5)
    elif kind == "campo":
        out += wind(.7, 700); out += pan(birds(.9) * .35, -.4); out += pan(birds(.6) * .25, .6)
    elif kind in ("loja", "mercado"):   # zumbido de geladeira + bips distantes
        t = np.arange(n) / SR; hum = (np.sin(TAU * 60 * t) + .4 * np.sin(TAU * 120 * t)) * .15
        out += st(hum) + np.stack([lp(colored(n, r, 1.0), 1500, 1) * .25 for _ in range(2)])
        for k in range(int(dur * .5)): place(out, pan(sfx_lib.make("bip") * .15, r.uniform(-.8, .8)), r.uniform(0, dur - .2))
    elif kind in ("escritorio", "sala"):
        t = np.arange(n) / SR; out += st(np.sin(TAU * 100 * t) * .08) + np.stack([lp(colored(n, r, 1.5), 800, 1) * .2 for _ in range(2)])
        for k in range(int(dur * 2)): place(out, pan(sfx_lib.make("digitar", k) * .2, r.uniform(-.5, .5)), r.uniform(0, dur - .1))
    elif kind == "noite":
        t = np.arange(n) / SR; out += wind(.35, 500)
        for v in range(3):
            f = r.uniform(4200, 4900); pulse = (np.sin(TAU * r.uniform(28, 34) * t) > .2) * (np.sin(TAU * r.uniform(1.6, 2.4) * t) > .55)
            out += st(np.sin(TAU * f * t) * lp(pulse.astype(float), 200, 1) * .05)
    return out

def build(cfg, base_dir="."):
    dur = float(cfg["dur"]); N = ns(dur); log = []
    if cfg.get("auto_download", True):   # baixa os modelos 1x se faltarem (sem internet → fallback sintético, sem erro)
        import models
        if cfg.get("voices") and cfg.get("tts", False): models.ensure("voz")
        if (cfg.get("music") or {}).get("style", "none") != "none" and (cfg.get("music") or {}).get("engine", "auto") != "synth": models.ensure("sf2")
    # ---- voz
    v = np.zeros((2, N)); spans = []; words = []; eng = None
    if cfg.get("voice_file") and os.path.exists(os.path.join(base_dir, cfg["voice_file"])):
        v = load_voice_file(os.path.join(base_dir, cfg["voice_file"]), dur); vv = np.zeros((2, N)); vv[:, :min(N, v.shape[1])] = v[:, :N]; v = vv
    if cfg.get("voices"):
        sv, sp, words, eng = V.render_lines(cfg["voices"], dur, use_tts=cfg.get("tts", False)); v = v + sv
    has_voice = bool(np.abs(v).max() > 1e-4)
    if has_voice:
        spans = speech_spans(v); cur = integrated(v)
        if np.isfinite(cur): v = v * dbg(VOICE_REF - cur)
    vref = VOICE_REF
    # legendas por texto (sem gerar voz): "captions":[{"t":0.5,"text":"...","dur":3.0}] -> words.js (legenda = o que o usuário narra no voz.mp3)
    for c in cfg.get("captions", []):
        import tts as _T; d = c.get("dur") or max(.8, len(c["text"]) * .062); words += _T.word_times(c["text"], c["t"], d)
    # ---- música
    mus = np.zeros((2, N)); mc = cfg.get("music")
    if mc and mc.get("style", "none") != "none":
        m = M.compose(mc["style"], dur, mc.get("bpm"), mc.get("key", "C"), mc.get("seed", 1), mc.get("intensity", 1.0), mc.get("engine", "auto"))
        m = m * dbg(vref + mc.get("level", -8.0) - integrated(m))                       # fundo ~13 LU abaixo da voz
        mus = m * dbg(duck_curve(spans, N, dur, mc.get("duck", -5.0)))[None, :] if spans else m * dbg(mc.get("solo_boost", 3.0))
    # ---- ambiente
    amb = ambience(cfg.get("ambience"), dur); 
    if np.abs(amb).max() > 0: amb = amb * dbg(vref + cfg.get("ambience_level", -26.0) - integrated(amb))
    # ---- sfx
    sfx = np.zeros((2, N)); send = np.zeros(N); cues = []
    extra = []
    if cfg.get("sfx_from") and os.path.exists(os.path.join(base_dir, cfg["sfx_from"])): extra = json.load(open(os.path.join(base_dir, cfg["sfx_from"]), encoding="utf-8"))
    for c in cfg.get("sfx", []) + extra:
        name = c.get("sfx") or c.get("name"); reps = c.get("repeat"); times = [c["t"] + k * reps["every"] for k in range(reps["n"])] if reps else [c["t"]]
        for k, tm in enumerate(times):
            if tm >= dur: continue
            x = sfx_lib.make(name, c.get("seed", 1) + k); lvl = vref + cfg.get("sfx_level", -4.0) + c.get("gain_db", 0.0) + (20 * np.log10(c["gain"]) if c.get("gain") else 0)
            cur = momentary_max(x); x = x * dbg(lvl - cur) if np.isfinite(cur) else x
            if name in ("step", "step_soft", "tick", "click", "digitar"): x = x * dbg(-3)
            p = c.get("pan", 0.0); place(sfx, pan(x, p), tm)
            i = ns(tm); b = min(N, i + len(x)); send[i:b] += .1 * x[:b - i]
            cues.append((tm, name, round(lvl - vref, 1), p))
    sfx += .4 * convolve_st(send, make_ir(.5, 3, hf=1.5))
    # ---- master
    mix0 = v + mus + amb + sfx; G = TARGET_LUFS - integrated(mix0) if np.isfinite(integrated(mix0)) else 0.0
    for it in range(4):
        y, g = limiter(mix0 * dbg(G), CEIL); L = integrated(y)
        if not np.isfinite(L) or abs(L - TARGET_LUFS) < .05: break
        G += TARGET_LUFS - L
    y = fades(y, .005, .08); stems = {"voz": v * dbg(G), "musica": mus * dbg(G), "sfx": (sfx + amb) * dbg(G)}
    # margem voz vs fundo nas janelas com fala
    margin = None
    if has_voice and spans:
        bed = mus + sfx + amb; Mv, Mb = momentary(v, .05), momentary(bed, .05); tc = np.arange(len(Mv)) * .05 + .2; k = np.zeros(len(tc), bool)
        for s, e in spans: k |= (tc >= s + .05) & (tc <= e - .05)
        k &= np.isfinite(Mb) & (Mb > -70) & (Mv > -60)
        margin = float(np.median(Mv[k] - Mb[k])) if k.sum() > 3 else None
    rep = dict(words=words, voice_engine=eng, lufs=float(integrated(y)), tp=float(true_peak(y)), margin_voz_fundo_LU=margin, tem_voz=has_voice, cues=cues, spans=spans)
    return y, stems, rep

def main():
    import argparse
    ap = argparse.ArgumentParser(); ap.add_argument("config"); ap.add_argument("--out", default="mix.wav"); ap.add_argument("--stems", action="store_true")
    a = ap.parse_args(); cfg = json.load(open(a.config, encoding="utf-8")); base = os.path.dirname(os.path.abspath(a.config))
    y, stems, rep = build(cfg, base); write_wav(a.out, y, 16)
    if a.stems:
        d = os.path.join(os.path.dirname(os.path.abspath(a.out)), "stems"); os.makedirs(d, exist_ok=True)
        for k, s in stems.items(): write_wav(os.path.join(d, k + ".wav"), s, 16)
    if rep["words"] and cfg.get("words_out", True):   # legenda = fala: palavras com tempo + envelope da voz (boca) para o cena.js
        fps = cfg.get("fps", 30); m = stems["voz"].mean(0); h = int(SR / fps); n = len(m) // h
        e = np.sqrt((m[:n * h].reshape(n, h) ** 2).mean(1)); e = np.clip(e / (np.percentile(e, 97) + 1e-9), 0, 1)
        open(os.path.join(base, "words.js"), "w", encoding="utf-8").write("window.WORDS = " + json.dumps(rep["words"], ensure_ascii=False) + ";\nwindow.ENV = " + json.dumps([round(float(x), 3) for x in e]) + ";\n")
    ml = rep["margin_voz_fundo_LU"]
    lines = [f"# Relatório de áudio", f"- Loudness: **{rep['lufs']:.1f} LUFS** (alvo -14) · pico real **{rep['tp']:.1f} dBTP** (teto -1.2)",
             f"- Voz presente: {'sim' if rep['tem_voz'] else 'não'} (motor: {rep['voice_engine'] or 'arquivo do usuário'})" + (f" · margem voz − fundo nas falas: **{ml:.1f} LU** (precisa ser ≥ 8)" if ml is not None else ""), "", "| t(s) | efeito | nível vs voz (LU) | pan |", "|---|---|---|---|"]
    lines += [f"| {t:.2f} | {n} | {l:+.1f} | {p:+.1f} |" for t, n, l, p in sorted(rep["cues"])]
    open(os.path.join(os.path.dirname(os.path.abspath(a.out)), "relatorio_audio.md"), "w", encoding="utf-8").write("\n".join(lines))
    print(f"ok: {a.out}  {rep['lufs']:.1f} LUFS  {rep['tp']:.1f} dBTP" + (f"  margem voz {ml:.1f} LU" if ml is not None else ""))
    if ml is not None and ml < 8: print("AVISO: voz pouco acima do fundo (<8 LU). Baixe music.level ou sfx_level no audio.json.")

if __name__ == "__main__": main()
