"""tts.py — vozes de personagem REAIS em português (Kokoro neural) + efeitos de personagem (altura, velocidade, robô, vovó).
speak_tts(text, who) -> mono 48 kHz | None se o modelo não estiver disponível (aí voice.py usa o balbucio de desenho).
Também calcula o tempo de cada palavra da fala (para a legenda sair igual ao que é dito)."""
import hashlib, os, re, subprocess, tempfile
import numpy as np
from dsp import *
import models

# who: voz-base do Kokoro (pf_dora = feminina, pm_alex / pm_santa = masculinas), altura (razão), velocidade, efeito
CHARS = {
    "narrador": dict(v="pm_alex",  pitch=1.00, speed=1.00),
    "menino":   dict(v="pm_alex",  pitch=1.28, speed=1.06),
    "crianca":  dict(v="pf_dora",  pitch=1.32, speed=1.08),
    "mulher":   dict(v="pf_dora",  pitch=1.00, speed=1.00),
    "caixa":    dict(v="pf_dora",  pitch=1.06, speed=1.06),
    "rato":     dict(v="pf_dora",  pitch=1.50, speed=1.18),
    "gato":     dict(v="pm_santa", pitch=0.86, speed=0.96),
    "chefe":    dict(v="pm_santa", pitch=0.76, speed=0.92),
    "vovo":     dict(v="pf_dora",  pitch=0.86, speed=0.90, fx="trem"),
    "robo":     dict(v="pm_alex",  pitch=0.95, speed=1.00, fx="robo"),
}
_K = {}
def available(): return models.have("voz") and _lib_ok()
def _lib_ok():
    try: import kokoro_onnx, onnxruntime; return True
    except Exception: return False

def _kokoro():
    if "k" not in _K:
        from kokoro_onnx import Kokoro
        _K["k"] = Kokoro(models.path("kokoro.onnx"), models.path("voices.bin"))
    return _K["k"]

def _pitch(x, sr, ratio):
    """muda a altura SEM mudar a duração (ffmpeg rubberband; se não houver, reamostra+atempo)"""
    if abs(ratio - 1) < .01: return x
    a = tempfile.mktemp(suffix=".wav"); b = tempfile.mktemp(suffix=".wav"); write_wav_sr(a, x, sr)
    r = subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", a, "-af", f"rubberband=pitch={ratio}:formant=preserved", b], capture_output=True)
    if r.returncode != 0:
        r = subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", a, "-af", f"asetrate={int(sr*ratio)},aresample={sr},atempo={1/ratio:.4f}", b], capture_output=True)
    y, _ = read_wav(b); os.remove(a); os.remove(b); return y[0]

def write_wav_sr(path, x, sr):
    import wave
    q = np.clip(np.round(np.asarray(x) * 32767), -32768, 32767).astype("<i2").tobytes()
    with wave.open(path, "wb") as w: w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr); w.writeframes(q)

def _fx(y, kind):
    t = np.arange(len(y)) / SR
    if kind == "robo": y = y * (.55 + .45 * np.sin(TAU * 70 * t)); y = np.round(y * 24) / 24; y = hp(lp(y, 6000, 2), 120, 1)
    if kind == "trem": y = y * (1 + .12 * np.sin(TAU * 5.2 * t))
    return y

def speak_tts(text, who="narrador", speed=1.0, pitch=1.0, cache_dir=None):
    if not available(): return None
    c = CHARS.get(who, CHARS["narrador"]); key = hashlib.md5(f"{text}|{who}|{speed}|{pitch}".encode()).hexdigest()[:16]
    cd = cache_dir or os.path.join(models.CACHE, "tts"); os.makedirs(cd, exist_ok=True); fp = os.path.join(cd, key + ".npy")
    if os.path.exists(fp): return np.load(fp)
    s, sr = _kokoro().create(text, voice=c["v"], speed=float(np.clip(c["speed"] * speed, .5, 2.0)), lang="pt-br")
    s = _pitch(np.asarray(s, float), sr, c["pitch"] * pitch)
    from scipy import signal
    y = signal.resample_poly(s, SR, sr) if sr != SR else s
    y = _fx(y, c.get("fx")); y = y / (np.abs(y).max() + 1e-9) * .85
    # tira o silêncio das pontas (mantém 40 ms)
    on = np.flatnonzero(np.abs(y) > .01); 
    if len(on): y = y[max(0, on[0] - ns(.04)): on[-1] + ns(.06)]
    np.save(fp, y.astype(np.float32)); return y

def _syl(w): return max(1, len(re.findall(r"[aeiouáéíóúâêôãõàü]+", w.lower())))

def word_times(text, t0, dur):
    """tempo de cada palavra dentro de uma fala que começa em t0 e dura dur: pesos por sílaba + pausa em pontuação"""
    toks = re.findall(r"\S+", text); wts = []; 
    for w in toks:
        base = _syl(re.sub(r"[^\wáéíóúâêôãõàüç]", "", w)) + .3
        pause = .9 if re.search(r"[.!?:;]$", w) else (.45 if w.endswith(",") else 0)
        wts.append((base, pause))
    tot = sum(a + b for a, b in wts); out = []; cur = t0
    for w, (a, b) in zip(toks, wts):
        d = dur * a / tot; out.append({"w": w, "t0": round(cur, 3), "t1": round(cur + d, 3)}); cur += dur * (a + b) / tot
    return out
