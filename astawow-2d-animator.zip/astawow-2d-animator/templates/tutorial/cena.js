const CONFIG = { w: 1920, h: 1080, fps: 30, dur: 10 };
// Intro do tutorial: bonequinho melhorado (moletom, fone, olhos brilhantes) explica 4 passos
const STEPS = [
  { t: 1.6, n: '1', txt: 'GRAVE NO OBS', col: '#3c78d8', ic: 'rec' },
  { t: 3.6, n: '2', txt: 'COMPACTE 30 MB', col: '#ff8a3d', ic: 'zip' },
  { t: 5.6, n: '3', txt: 'ENVIE PRO CLAUDE', col: '#2ea36b', ic: 'send' },
  { t: 7.4, n: '4', txt: 'PRONTO + SUA LOGO', col: '#8a5fd0', ic: 'logo' },
];
function bg(g, W, H, t) {
  const gr = g.createLinearGradient(0, 0, 0, H); gr.addColorStop(0, '#16224a'); gr.addColorStop(1, '#2b3f86'); g.fillStyle = gr; g.fillRect(0, 0, W, H);
  g.fillStyle = 'rgba(255,255,255,.07)'; for (let i = 0; i < 14; i++) { const x = (L.hash(i, 1) * W + t * 12 * (1 + L.hash(i, 2))) % W, y = L.hash(i, 3) * H * .7; g.beginPath(); g.arc(x, y, 6 + L.hash(i, 4) * 16, 0, 7); g.fill(); }
  g.fillStyle = '#1b2a5c'; 
}
function icon(g, k, col) {
  g.strokeStyle = '#fff'; g.fillStyle = '#fff'; g.lineWidth = 8; g.lineCap = 'round';
  if (k === 'rec') { g.beginPath(); g.arc(0, 0, 22, 0, 7); g.fillStyle = '#ff3b3b'; g.fill(); g.stroke(); }
  if (k === 'zip') { g.strokeRect(-24, -20, 48, 40); g.beginPath(); g.moveTo(-10, -4); g.lineTo(10, -4); g.moveTo(-10, 8); g.lineTo(10, 8); g.stroke(); }
  if (k === 'send') { g.beginPath(); g.moveTo(-24, 0); g.lineTo(24, 0); g.lineTo(8, -16); g.moveTo(24, 0); g.lineTo(8, 16); g.stroke(); }
  if (k === 'logo') { g.beginPath(); g.moveTo(-22, 2); g.lineTo(-6, 18); g.lineTo(24, -16); g.stroke(); }
}
function card(g, s, t, y) {
  const k = L.spring(t - s.t, 260, 17); if (k < .02) return;
  g.save(); g.translate(540, y); g.scale(k, k); g.rotate(-.02 + (1 - k) * .1);
  g.fillStyle = 'rgba(0,0,0,.28)'; L.rr(g, -400 + 8, -62 + 12, 800, 124, 28); g.fill();
  L.rr(g, -400, -62, 800, 124, 28); L.fillStroke(g, s.col, '#fff', 8);
  g.beginPath(); g.arc(-326, 0, 44, 0, 7); L.fillStroke(g, '#ffffff', '#111', 6); g.fillStyle = s.col; g.font = '900 56px "Archivo Black","Impact","DejaVu Sans",sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(s.n, -326, 4);
  g.fillStyle = '#fff'; g.font = '900 46px "Archivo Black","Impact","DejaVu Sans",sans-serif'; g.textAlign = 'left'; g.fillText(s.txt, -260, 4);
  g.save(); g.translate(340, 0); g.scale(.85, .85); icon(g, s.ic, s.col); g.restore(); g.restore();
}
function mascot(g, t, W, H) {
  const FY = 860, x = 1610, s = 1.45;
  const cur = STEPS.filter(p => t >= p.t).length, tk = t < 9.3;
  const pt = t - .2, hop = Math.max(0, Math.sin(Math.min(1, (t - (STEPS[Math.max(0, cur - 1)].t)) / .5) * Math.PI)) * 26 * (cur ? 1 : 0);
  const arm = cur ? 1.25 + Math.sin(t * 6) * .25 : .3;
  stickGuy(g, { x, y: FY - hop, s, t, shirt: '#ffb347', hair: 'black', eyes: t > 9.2 ? 'happy' : 'normal', mouth: tk ? 'smile' : 'grin', talk: tk ? Math.abs(Math.sin(t * 10)) * .8 : 0, tilt: Math.sin(t * 1.6) * .05, armL: .3, armR: arm, brow: .2, look: Math.sin(t * .8) * .3 });
  // fone de ouvido (melhoria): arco + conchas + microfone, preso à cabeça
  const hy = FY - hop - 306 * s, br = Math.sin(t * 2.2) * 2 * s;
  g.save(); g.translate(x, hy + br); g.rotate(Math.sin(t * 1.6) * .05); g.scale(s, s); g.lineCap = 'round'; g.strokeStyle = '#111'; g.lineWidth = 12;
  g.beginPath(); g.arc(0, 0, 92, Math.PI * 1.02, Math.PI * 1.98); g.stroke(); g.strokeStyle = '#ff3b3b'; g.lineWidth = 6; g.beginPath(); g.arc(0, 0, 92, Math.PI * 1.06, Math.PI * 1.94); g.stroke();
  for (const k of [-1, 1]) { L.rr(g, k * 92 - 14, -22, 28, 54, 12); L.fillStroke(g, '#222a40', '#111', 5); }
  g.strokeStyle = '#111'; g.lineWidth = 6; g.beginPath(); g.moveTo(92, 30); g.quadraticCurveTo(80, 70, 40, 66); g.stroke(); g.fillStyle = '#111'; g.beginPath(); g.arc(38, 66, 9, 0, 7); g.fill(); g.restore();
  // luz "REC" piscando
  if (false && Math.floor(t * 3) % 2 === 0) { g.fillStyle = '#ff3b3b'; g.beginPath(); g.arc(W * .84, H * .08, 20, 0, 7); g.fill(); g.fillStyle = '#fff'; g.font = '900 40px "DejaVu Sans"'; g.textAlign = 'right'; g.fillText('REC', W * .84 - 34, H * .08 + 14); }
}
const CH = ['OBS', 'COMPACTAR', 'ENVIAR', 'PRONTO'];
function chapters(g, t) {
  const act = Math.max(0, STEPS.filter(p => t >= p.t - .2).length - 1);
  CH.forEach((c, i) => { const w = 250, x = 40 + i * (w + 16), on = i === act; L.rr(g, x, 28, w, 64, 18); L.fillStroke(g, on ? STEPS[i].col : 'rgba(255,255,255,.12)', on ? '#fff' : 'rgba(255,255,255,.35)', on ? 6 : 3);
    g.fillStyle = on ? '#fff' : 'rgba(255,255,255,.7)'; g.font = '900 27px "Archivo Black","Impact","DejaVu Sans",sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText((i + 1) + ' ' + c, x + w / 2, 62); });
}
function screenSlot(g, t) {
  const x = 40, y = 120, w = 1280, h = 720; g.fillStyle = 'rgba(0,0,0,.35)'; L.rr(g, x + 8, y + 14, w, h, 26); g.fill();
  L.rr(g, x, y, w, h, 26); L.fillStroke(g, '#0e1426', '#fff', 8);
  g.fillStyle = '#1d2748'; L.rr(g, x + 4, y + 4, w - 8, 52, 22); g.fill(); ['#ff5f57', '#febc2e', '#28c840'].forEach((c, i) => { g.fillStyle = c; g.beginPath(); g.arc(x + 40 + i * 36, y + 30, 11, 0, 7); g.fill(); });
  g.save(); g.beginPath(); g.rect(x + 8, y + 60, w - 16, h - 68); g.clip();
  g.font = '700 38px "DejaVu Sans Mono",monospace'; g.textAlign = 'left'; g.textBaseline = 'top';
  const lines = ['$ claude', '> crie um vídeo 2D de 1 minuto', '> usando a skill astawow-2d-animator', '✓ roteiro  ✓ cenas  ✓ áudio', '✓ render pronto: video.mp4'];
  lines.forEach((l, i) => { const n = Math.floor(Math.max(0, t - .8 - i * 1.7) * 22); if (n > 0) { g.fillStyle = l[0] === '✓' ? '#6fe3a0' : '#cfe0ff'; g.fillText(l.slice(0, n), x + 36, y + 100 + i * 70); } });
  g.fillStyle = 'rgba(255,255,255,.18)'; g.font = '900 46px "DejaVu Sans"'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('← SUA TELA ENTRA AQUI (1280×720) →', x + w / 2, y + h - 50); g.restore();
}
// marca d'água: logo oficial AstaWoww (logo.js)
function watermark(g, W) { const im = window.LOGO_IMG; if (!im || !im.naturalWidth) return; const w = 330, h = w * im.naturalHeight / im.naturalWidth; g.save(); g.globalAlpha = .96; g.drawImage(im, W - w - 30, 10, w, h); g.restore(); }
function draw(g, t, W, H) {
  bg(g, W, H, t); chapters(g, t); screenSlot(g, t); mascot(g, t, W, H); watermark(g, W);
  g.fillStyle = '#1b2a5c'; g.fillRect(0, 880, W, 200); g.strokeStyle = '#111'; g.lineWidth = 6; g.beginPath(); g.moveTo(0, 880); g.lineTo(W, 880); g.stroke();
  L.captions(g, W, H, WORDS, t, { y: 985, size: 70, group: 4, hi: '#ffd23f' });
}
