# Shotlist — <título> (<duração> s, <formato>, estilo <estilo>)
| # | início–fim (s) | cenário | personagem(ns) | ação (chegar → agir → reagir) | câmera | transição | som (HITS) | legenda |
|---|---|---|---|---|---|---|---|---|
| 1 | 0.0–2.5 | | | | | corte seco | whoosh 0.0 · step 0.5… | |
| 2 | 2.5–5.0 | | | | | | | |
**Escala** (m): pessoa 1,7 · porta 2,1 · carro 4,2×1,8 · rua 6–7 · poste 4–4,5.  **Personagens**: cores, proporção, acessórios (iguais em todas as cenas).
**Aprovado pelo usuário?** sim / não / (vídeo curto: seguir e avisar)
