// Palavras com tempo (segundos). Gerado por scripts/prep_audio.py a partir do áudio, ou escrito à mão.
window.WORDS = [];
window.ENV = []; // envelope de volume 0..1 por frame (scripts/prep_audio.py) para a boca
