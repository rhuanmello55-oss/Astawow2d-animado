/* toon.js — estilo DESENHO CLÁSSICO DE PERSEGUIÇÃO (gato x rato), slapstick: squash & stretch, borrões de velocidade, poeira, estrelinhas,
   "BONK!", rachadura na parede, iris-out no final. Personagens ORIGINAIS (gato laranja + ratinho cinza), só o estilo é a referência.
   toonCat(g,{x,y,s,t,flip,pose:'idle'|'run'|'sleep'|'sit',eyes:'normal'|'angry'|'scared'|'dizzy'|'happy'|'closed',mouth:'smile'|'grin'|'open'|'o'|'flat',sx,sy,lean,ph,look,arm})
   toonMouse(g,{x,y,s,t,flip,pose:'idle'|'run'|'tiptoe'|'peek',eyes:'normal'|'scared'|'happy'|'smug',mouth:'smile'|'tongue'|'open'|'grin',cheese,sx,sy,ph})
   livingRoom(g,W,H,t,k) -> layout • cheese(g,x,y,s) • stars(g,x,y,t,r) • bonk(g,x,y,age,txt) • speedLines(g,x,y,len,t) • irisOut(g,W,H,cx,cy,p) */
const TINK = '#2b1a14';
function cheese(g, x, y, s = 1, rot = 0) { g.save(); g.translate(x, y); g.rotate(rot); g.scale(s, s); g.beginPath(); g.moveTo(-34, 0); g.lineTo(34, -6); g.lineTo(34, -34); g.lineTo(-34, -22); g.closePath(); L.fillStroke(g, '#ffd23f', TINK, 5); g.beginPath(); g.moveTo(-34, -22); g.lineTo(34, -34); g.lineTo(20, -46); g.lineTo(-24, -36); g.closePath(); L.fillStroke(g, '#ffe680', TINK, 5); g.fillStyle = '#e0a800'; for (const [a, b, r] of [[-14, -14, 6], [10, -18, 5], [22, -10, 4]]) { g.beginPath(); g.arc(a, b, r, 0, 7); g.fill(); } g.restore(); }
function stars(g, x, y, t, r = 70, n = 4) { for (let i = 0; i < n; i++) { const a = t * 5 + i * (6.283 / n); L.sparkle(g, x + Math.cos(a) * r, y + Math.sin(a) * r * .35, 16, a * 1.5, '#ffe14a'); } }
function bonk(g, x, y, age, txt = 'BONK!') { if (age < 0 || age > .9) return; const k = L.spring(age, 400, 16), f = 1 - Math.max(0, (age - .55) / .35); g.save(); g.translate(x, y); g.rotate(-.12); g.scale(k, k); g.globalAlpha = f; g.font = '900 78px "Archivo Black","Impact","DejaVu Sans",sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.lineJoin = 'round'; g.lineWidth = 16; g.strokeStyle = TINK; g.strokeText(txt, 0, 0); g.fillStyle = '#ffe14a'; g.fillText(txt, 0, 0); g.restore(); }
function speedLines(g, x, y, len, t, dir = -1) { g.save(); g.strokeStyle = 'rgba(255,255,255,.85)'; g.lineWidth = 7; g.lineCap = 'round'; for (let i = 0; i < 4; i++) { const yy = y - 90 + i * 55 + Math.sin(t * 40 + i) * 4, l = len * (.6 + L.hash(i, 5) * .5); g.beginPath(); g.moveTo(x, yy); g.lineTo(x + dir * l, yy); g.stroke(); } g.restore(); }
function irisOut(g, W, H, cx, cy, p) { const r = Math.max(0, 1 - p) * Math.hypot(W, H); g.save(); g.fillStyle = '#000'; g.beginPath(); g.rect(0, 0, W, H); g.arc(cx, cy, r, 0, Math.PI * 2, true); g.fill('evenodd'); g.restore(); }
function toonCat(g, o = {}) {
  const { x = 0, y = 0, s = 1, t = 0, flip = false, pose = 'idle', eyes = 'normal', mouth = 'smile', sx = 1, sy = 1, lean = 0, look = 0, arm = 0 } = o, ph = o.ph === undefined ? t * 14 : o.ph, run = pose === 'run', sleep = pose === 'sleep';
  const OR = '#f29a38', OD = '#d9772a', CR = '#fff1d6', PK = '#f4a7b9', bob = run ? -Math.abs(Math.sin(ph)) * 16 : Math.sin(t * 2) * 2, bl = (t % 3.2) > 3.1;
  g.save(); g.translate(x, y); g.scale((flip ? -1 : 1) * s * sx, s * sy);
  const sg = g.createRadialGradient(0, 0, 4, 0, 0, 110); sg.addColorStop(0, 'rgba(0,0,0,.3)'); sg.addColorStop(1, 'rgba(0,0,0,0)'); g.save(); g.scale(1, .2); g.fillStyle = sg; g.beginPath(); g.arc(0, 0, 110, 0, 7); g.fill(); g.restore();
  // rabo balançando
  const tail = []; for (let i = 0; i <= 8; i++) tail.push([-48 - i * 9 + Math.sin(t * (run ? 12 : 3) + i * .6) * (6 + i * 1.6), -120 - i * 18 - (run ? i * 4 : 0)]); L.blobs2(g, [{ p: tail, w: 20, c: OR }], TINK, 5);
  // pernas
  const leg = (k) => { const p = ph + k * Math.PI, fx = run ? Math.sin(p) * 70 : k * 22 + (sleep ? 30 : 0), fy = run ? -Math.max(0, Math.cos(p)) * 40 : 0, hx = k * 18, hy = -90 + bob; return [{ p: [[hx, hy], [(hx + fx) / 2 + 10, (hy + fy) / 2], [fx, fy - 10]], w: 28, c: OR }, { p: [[fx - 6, fy - 8], [fx + 26, fy - 8]], w: 24, c: CR }]; };
  g.save(); g.translate(0, -90 + bob); g.rotate(lean); g.translate(0, 90 - bob);
  L.blobs2(g, leg(1), TINK, 5); L.blobs2(g, leg(0), TINK, 5);
  // corpo
  g.beginPath(); g.ellipse(0, -165 + bob, 64, 86, 0, 0, 7); L.fillStroke(g, OR, TINK, 6); g.fillStyle = CR; g.beginPath(); g.ellipse(14, -150 + bob, 40, 62, 0, 0, 7); g.fill(); g.strokeStyle = OD; g.lineWidth = 8; g.lineCap = 'round'; for (const yy of [-215, -190, -165]) { g.beginPath(); g.moveTo(-62, yy + bob); g.lineTo(-38, yy + 6 + bob); g.stroke(); }
  // braços
  const armS = (k) => { const a = run ? Math.sin(ph + (k ? 0 : Math.PI)) * 1.0 : (arm || .2) * (k ? 1 : .6), sx0 = 30, sy0 = -225 + bob; return [{ p: [[sx0, sy0], [sx0 + 26 + Math.sin(a) * 18, sy0 + 40], [sx0 + 40 + Math.sin(a) * 46, sy0 + 62 - Math.cos(a) * 10]], w: 22, c: OR }, { p: [[sx0 + 42 + Math.sin(a) * 46, sy0 + 62 - Math.cos(a) * 10]], w: 28, c: CR }]; };
  L.blobs2(g, armS(0), TINK, 5); L.blobs2(g, armS(1), TINK, 5);
  // cabeça
  g.save(); g.translate(16, -292 + bob); g.rotate(lean * .6 + (sleep ? .25 : 0));
  for (const [ex, ey, w] of [[-44, -52, 1], [48, -58, -1]]) { g.beginPath(); g.moveTo(ex - 28, ey + 18); g.lineTo(ex + w * 8, ey - 52); g.lineTo(ex + 28, ey + 18); g.closePath(); L.fillStroke(g, OR, TINK, 6); g.beginPath(); g.moveTo(ex - 14, ey + 14); g.lineTo(ex + w * 6, ey - 30); g.lineTo(ex + 14, ey + 14); g.closePath(); g.fillStyle = PK; g.fill(); }
  g.beginPath(); g.ellipse(0, 0, 82, 68, 0, 0, 7); L.fillStroke(g, OR, TINK, 6); g.strokeStyle = OD; g.lineWidth = 8; g.lineCap = 'round'; for (const xx of [-16, 0, 16]) { g.beginPath(); g.moveTo(xx, -66); g.lineTo(xx * .9, -44); g.stroke(); }
  g.fillStyle = CR; g.beginPath(); g.ellipse(12, 24, 34, 26, 0, 0, 7); g.fill(); g.beginPath(); g.ellipse(46, 24, 34, 26, 0, 0, 7); g.fill(); g.beginPath(); g.moveTo(40, 4); g.lineTo(56, 4); g.lineTo(48, 16); g.closePath(); L.fillStroke(g, '#e8678a', TINK, 4);
  g.strokeStyle = TINK; g.lineWidth = 3; for (const k of [-1, 0, 1]) { g.beginPath(); g.moveTo(70, 26 + k * 8); g.lineTo(112, 20 + k * 16); g.moveTo(-10, 26 + k * 8); g.lineTo(-52, 20 + k * 16); g.stroke(); }
  // olhos
  for (const [ex, ew] of [[2, 1], [44, 1]]) { const ey = -16, lx = look * 7;
    if (eyes === 'closed' || sleep || bl) { g.lineWidth = 6; g.strokeStyle = TINK; g.beginPath(); g.arc(ex, ey + 6, 16, .15, Math.PI - .15); g.stroke(); continue; }
    g.beginPath(); g.ellipse(ex, ey, 21, eyes === 'scared' ? 32 : 27, 0, 0, 7); L.fillStroke(g, '#ffffff', TINK, 5);
    if (eyes === 'dizzy') { g.strokeStyle = TINK; g.lineWidth = 4; g.beginPath(); for (let a = 0; a < 18; a += .3) g.lineTo(ex + Math.cos(a + t * 8) * a, ey + Math.sin(a + t * 8) * a); g.stroke(); }
    else { g.fillStyle = TINK; g.beginPath(); g.ellipse(ex + lx, ey + 3, eyes === 'scared' ? 4.5 : 8, eyes === 'scared' ? 5 : 12, 0, 0, 7); g.fill(); g.fillStyle = '#fff'; g.beginPath(); g.arc(ex + lx + 2, ey - 3, 2.6, 0, 7); g.fill(); }
    if (eyes === 'angry') { g.fillStyle = OR; g.beginPath(); g.moveTo(ex - 26, ey - 36); g.lineTo(ex + 26, ey - 6 + (ex < 20 ? 0 : -14)); g.lineTo(ex + 26, ey - 36); g.closePath(); g.fill(); g.strokeStyle = TINK; g.lineWidth = 7; g.beginPath(); g.moveTo(ex - 24, ey - 20 - (ex < 20 ? 8 : 0)); g.lineTo(ex + 24, ey - 2 - (ex < 20 ? 0 : 20)); g.stroke(); } }
  // boca
  g.strokeStyle = TINK; g.lineWidth = 5; if (mouth === 'open') { g.beginPath(); g.ellipse(34, 50, 24, 20 + Math.abs(Math.sin(t * 12)) * 6, 0, 0, 7); g.fillStyle = '#7a1f2b'; g.fill(); g.stroke(); g.fillStyle = '#ff8aa0'; g.beginPath(); g.ellipse(34, 58, 14, 8, 0, 0, 7); g.fill(); }
  else if (mouth === 'grin') { L.rr(g, 8, 40, 56, 24, 10); L.fillStroke(g, '#ffffff', TINK, 4); g.beginPath(); g.moveTo(8, 52); g.lineTo(64, 52); g.stroke(); for (const xx of [22, 36, 50]) { g.beginPath(); g.moveTo(xx, 40); g.lineTo(xx, 64); g.stroke(); } }
  else if (mouth === 'o') { g.beginPath(); g.ellipse(34, 50, 12, 16, 0, 0, 7); g.fillStyle = '#7a1f2b'; g.fill(); g.stroke(); }
  else if (mouth === 'flat') { g.beginPath(); g.moveTo(16, 50); g.lineTo(52, 50); g.stroke(); }
  else { g.beginPath(); g.moveTo(14, 44); g.quadraticCurveTo(34, 62, 56, 44); g.stroke(); }
  g.restore(); g.restore(); g.restore();
}
function toonMouse(g, o = {}) {
  const { x = 0, y = 0, s = 1, t = 0, flip = false, pose = 'idle', eyes = 'normal', mouth = 'smile', cheese: hasCh = false, sx = 1, sy = 1 } = o, ph = o.ph === undefined ? t * 18 : o.ph, run = pose === 'run', tip = pose === 'tiptoe';
  const GR = '#a9adc2', GD = '#8a8fa8', CR = '#f6ead8', PK = '#f5a0b5', bob = run ? -Math.abs(Math.sin(ph)) * 9 : tip ? Math.sin(t * 7) * 3 : Math.sin(t * 3) * 1.5;
  g.save(); g.translate(x, y); g.scale((flip ? -1 : 1) * s * sx, s * sy);
  const sg = g.createRadialGradient(0, 0, 3, 0, 0, 52); sg.addColorStop(0, 'rgba(0,0,0,.3)'); sg.addColorStop(1, 'rgba(0,0,0,0)'); g.save(); g.scale(1, .2); g.fillStyle = sg; g.beginPath(); g.arc(0, 0, 52, 0, 7); g.fill(); g.restore();
  const tail = []; for (let i = 0; i <= 8; i++) tail.push([-26 - i * 8, -30 - Math.sin(i * .8 + t * (run ? 14 : 4)) * 10 * (i / 8) - i * 2]); L.blobs2(g, [{ p: tail, w: 7, c: PK }], TINK, 3);
  const leg = (k) => { const p = ph + k * Math.PI, fx = run ? Math.sin(p) * 28 : k * 10, fy = run ? -Math.max(0, Math.cos(p)) * 18 : 0; return [{ p: [[k * 8, -26 + bob], [fx, fy - 5]], w: 12, c: GR }, { p: [[fx - 3, fy - 4], [fx + 14, fy - 4]], w: 11, c: PK }]; };
  L.blobs2(g, leg(1), TINK, 3); L.blobs2(g, leg(0), TINK, 3);
  g.beginPath(); g.ellipse(0, -56 + bob, 28, 36, 0, 0, 7); L.fillStroke(g, GR, TINK, 4); g.fillStyle = CR; g.beginPath(); g.ellipse(8, -50 + bob, 16, 24, 0, 0, 7); g.fill();
  const ar = run ? Math.sin(ph) * .8 : .3; L.blobs2(g, [{ p: [[16, -72 + bob], [30, -52 + bob + (hasCh ? 4 : 0)], [hasCh ? 40 : 34 + ar * 10, -46 + bob + ar * 8]], w: 9, c: GR }], TINK, 3);
  g.save(); g.translate(8, -104 + bob);
  for (const [ex, ey, r] of [[-20, -24, 28], [20, -30, 26]]) { g.beginPath(); g.arc(ex, ey, r, 0, 7); L.fillStroke(g, GR, TINK, 4); g.beginPath(); g.arc(ex, ey, r * .6, 0, 7); g.fillStyle = PK; g.fill(); }
  g.beginPath(); g.ellipse(0, 0, 35, 31, 0, 0, 7); L.fillStroke(g, GR, TINK, 4); g.fillStyle = CR; g.beginPath(); g.ellipse(26, 8, 22, 15, 0, 0, 7); g.fill(); g.beginPath(); g.arc(46, 4, 6, 0, 7); L.fillStroke(g, '#e8678a', TINK, 3);
  g.strokeStyle = TINK; g.lineWidth = 2.5; for (const k of [-1, 1]) { g.beginPath(); g.moveTo(40, 10 + k * 3); g.lineTo(66, 10 + k * 12); g.stroke(); }
  for (const ex of [-2, 20]) { const ey = -8, sc = eyes === 'scared'; g.beginPath(); g.ellipse(ex, ey, 11, sc ? 17 : 14, 0, 0, 7); L.fillStroke(g, '#fff', TINK, 3.5); g.fillStyle = TINK; g.beginPath(); g.ellipse(ex + (sc ? 0 : 3), ey + 2, sc ? 3.5 : 5, sc ? 4 : 7, 0, 0, 7); g.fill(); if (eyes === 'smug') { g.fillStyle = GR; g.fillRect(ex - 13, ey - 18, 26, 17); g.strokeStyle = TINK; g.lineWidth = 3.5; g.beginPath(); g.moveTo(ex - 12, ey - 1); g.lineTo(ex + 12, ey - 1); g.stroke(); } if (eyes === 'happy') { g.fillStyle = '#fff'; g.fillRect(ex - 14, ey - 18, 28, 18); } }
  g.strokeStyle = TINK; g.lineWidth = 3.5; if (mouth === 'tongue') { g.beginPath(); g.moveTo(24, 22); g.quadraticCurveTo(36, 28, 46, 20); g.stroke(); g.beginPath(); g.ellipse(36, 30, 8, 10, 0, 0, 7); L.fillStroke(g, '#ff6f91', TINK, 3); } else if (mouth === 'open') { g.beginPath(); g.ellipse(34, 22, 10, 9 + Math.abs(Math.sin(t * 12)) * 4, 0, 0, 7); g.fillStyle = '#7a1f2b'; g.fill(); g.stroke(); } else if (mouth === 'grin') { g.beginPath(); g.moveTo(20, 20); g.quadraticCurveTo(36, 36, 50, 18); g.stroke(); L.rr(g, 30, 24, 8, 10, 2); L.fillStroke(g, '#fff', TINK, 2.5); } else { g.beginPath(); g.moveTo(22, 20); g.quadraticCurveTo(34, 30, 48, 18); g.stroke(); }
  g.restore();
  if (hasCh) cheese(g, 42, -44 + bob, .55, -.2);
  g.restore();
}
// sala de estar em corte lateral (parede listrada, rodapé com toquinha de rato, assoalho, janela, quadro, sofá, mesa com abajur)
function livingRoom(g, W, H, t, k = 1) {
  const fy = H * .78, wall = g.createLinearGradient(0, 0, 0, fy); wall.addColorStop(0, '#7fc8c0'); wall.addColorStop(1, '#a8dcd3'); g.fillStyle = wall; g.fillRect(0, 0, W, fy);
  g.fillStyle = 'rgba(255,255,255,.18)'; for (let i = 0; i < W / (90 * k); i++) if (i % 2) g.fillRect(i * 90 * k, 0, 90 * k, fy);
  const fl = g.createLinearGradient(0, fy, 0, H); fl.addColorStop(0, '#b9783c'); fl.addColorStop(1, '#8f5a2c'); g.fillStyle = fl; g.fillRect(0, fy, W, H - fy); g.strokeStyle = 'rgba(60,30,10,.35)'; g.lineWidth = 3; for (let i = 0; i < 12; i++) { const yy = fy + (H - fy) * (i / 12) ** 1.4; g.beginPath(); g.moveTo(0, yy); g.lineTo(W, yy); g.stroke(); }
  g.fillStyle = '#f4ead4'; g.fillRect(0, fy - 34 * k, W, 34 * k); g.strokeStyle = TINK; g.lineWidth = 6; g.beginPath(); g.moveTo(0, fy); g.lineTo(W, fy); g.moveTo(0, fy - 34 * k); g.lineTo(W, fy - 34 * k); g.stroke();
  const win = (x, y, w, h) => { L.rr(g, x, y, w, h, 8); L.fillStroke(g, '#bfe6ff', TINK, 7); g.strokeStyle = TINK; g.lineWidth = 6; g.beginPath(); g.moveTo(x + w / 2, y); g.lineTo(x + w / 2, y + h); g.moveTo(x, y + h / 2); g.lineTo(x + w, y + h / 2); g.stroke(); g.fillStyle = '#e8452c'; g.beginPath(); g.moveTo(x - 20, y - 10); g.quadraticCurveTo(x + 10, y + h * .6, x - 14, y + h + 10); g.lineTo(x + 18, y + h + 10); g.quadraticCurveTo(x + 30, y + h * .5, x + 22, y - 10); g.closePath(); g.fill(); g.stroke(); };
  win(W * .12, fy * .22, W * .14, fy * .46);
  L.rr(g, W * .42, fy * .2, W * .1, fy * .3, 6); L.fillStroke(g, '#f4b942', TINK, 8); L.rr(g, W * .428, fy * .23, W * .084, fy * .24, 4); L.fillStroke(g, '#ffe9b8', TINK, 4); g.fillStyle = '#5fae6b'; g.beginPath(); g.moveTo(W * .43, fy * .47); g.quadraticCurveTo(W * .47, fy * .3, W * .51, fy * .47); g.fill();
  // mesa + abajur (centro) e sofá (esquerda-baixo)
  const tx = W * .5, tw = 300 * k; L.rr(g, tx - tw / 2, fy - 170 * k, tw, 22 * k, 6); L.fillStroke(g, '#8a5a2c', TINK, 6); for (const sx of [-1, 1]) { L.rr(g, tx + sx * (tw / 2 - 26 * k), fy - 150 * k, 16 * k, 150 * k, 4); L.fillStroke(g, '#7a4c22', TINK, 6); }
  g.beginPath(); g.moveTo(tx - 150 * k, fy - 170 * k); g.moveTo(tx + 90 * k, fy - 170 * k); L.rr(g, tx + 80 * k, fy - 188 * k, 20 * k, 20 * k, 4); L.fillStroke(g, '#6b4a2a', TINK, 5); g.beginPath(); g.moveTo(tx + 62 * k, fy - 188 * k); g.lineTo(tx + 118 * k, fy - 188 * k); g.lineTo(tx + 104 * k, fy - 250 * k); g.lineTo(tx + 76 * k, fy - 250 * k); g.closePath(); L.fillStroke(g, '#ffe27a', TINK, 6);
  const sx0 = W * .02; L.rr(g, sx0, fy - 190 * k, 330 * k, 160 * k, 34 * k); L.fillStroke(g, '#c0504a', TINK, 7); L.rr(g, sx0 - 20 * k, fy - 250 * k, 80 * k, 220 * k, 28 * k); L.fillStroke(g, '#a8403b', TINK, 7); L.rr(g, sx0 + 60 * k, fy - 140 * k, 250 * k, 70 * k, 20 * k); L.fillStroke(g, '#d9605a', TINK, 6);
  // toquinha do ratinho (arco escuro no rodapé)
  const hx = W * .9; g.beginPath(); g.moveTo(hx - 70 * k, fy); g.arc(hx, fy, 70 * k, Math.PI, 0); g.closePath(); g.fillStyle = '#1a0f0a'; g.fill(); g.strokeStyle = TINK; g.lineWidth = 8; g.stroke();
  return { fy, holeX: hx, tableX: tx, tableTop: fy - 170 * k, sofaX: sx0 + 160 * k, k };
}
