// Perseguição gato x rato — 10 s, 1920x1080 (troque CONFIG p/ 1080x1920 e ele se adapta)
const CONFIG = { w: 1920, h: 1080, fps: 30, dur: 10 };
window.WORDS = [];
function draw(g, t, W, H) {
  const vert = H > W, K = vert ? W / 1080 * .9 : H / 1080, R = (() => { g.save(); return L.cam(g, W, H, t, { zoom: 1.02 + .03 * (t / 10), drift: .004 }); })();
  const rm = livingRoom(g, W, H, t, K * 1.4), FY = rm.fy + (H - rm.fy) * .18, S = K * 1.05, hole = rm.holeX, tbl = rm.tableX;
  const crashT = 4.5, shake = (t > crashT && t < crashT + .5) ? (crashT + .5 - t) * 26 : 0;
  // --- fase 1 (0–2.2): rato sai da toquinha, pega o queijo da mesa; gato dorme no sofá ---
  const mouseOut = L.clamp((t - .3) / .7), mx1 = L.lerp(hole, tbl + 60 * K, L.ease.inOut(L.clamp((t - .9) / 1.1)));
  let m = { x: mx1, y: FY, pose: t < .9 ? 'peek' : 'tiptoe', flip: true, eyes: t < 1.9 ? 'normal' : 'smug', cheese: false }, c = { x: rm.sofaX + 40 * K, y: FY, pose: 'sleep', eyes: 'closed', mouth: 'smile', flip: false };
  const cheesePos = [tbl - 20 * K, rm.tableTop - 4];
  const wake = 2.0, run0 = 2.35, hit = crashT;
  // gato acorda (olhos arregalam), rato foge pra toquinha com o queijo; gato corre atrás
  if (t >= 1.9 && t < run0) { c = { x: rm.sofaX + 40 * K, y: FY - Math.max(0, Math.sin((t - wake) * 12)) * 16 * K, pose: 'idle', eyes: 'scared', mouth: 'open', flip: false, lean: -.15 }; }
  const rr0 = L.clamp((t - 2.0) / 2.3), mxRun = L.lerp(tbl + 60 * K, hole - 10 * K, rr0 * rr0 * .35 + rr0 * .65), cr = L.clamp((t - run0) / (hit - run0)), cx = L.lerp(rm.sofaX + 40 * K, hole - 130 * K, cr * cr * .4 + cr * .6);
  if (t >= 2.0 && t < hit - .15) m = { x: mxRun, y: FY, pose: 'run', flip: false, eyes: 'scared', mouth: 'open', cheese: true, ph: t * 22 };
  if (t >= run0 && t < hit) c = { x: cx, y: FY, pose: 'run', eyes: 'angry', mouth: 'open', flip: false, lean: .25, sx: 1.12, sy: .94, ph: t * 15 };
  // --- fase 2: rato some na toquinha; gato bate na parede (squash), estrelinhas ---
  const toHole = t >= hit - .15;
  if (toHole) m = { x: hole, y: FY, pose: 'peek', flip: true, eyes: 'happy', cheese: false, mouth: 'tongue' };
  let impact = null;
  if (t >= hit) { const a = t - hit, sq = 1 - .5 * Math.exp(-a * 6) * Math.cos(a * 30) * (a < .5 ? 1 : 0), dz = t > hit + 1.2; c = { x: hole - 130 * K - (a < .15 ? 0 : Math.min(30, (a - .15) * 80)) * K, y: FY, pose: 'idle', eyes: dz ? 'dizzy' : 'dizzy', mouth: 'o', flip: false, sx: a < .4 ? 1 - .35 * (1 - a / .4) : 1, sy: a < .4 ? 1.12 : 1, lean: a < .3 ? .22 : Math.sin(t * 5) * .08 }; impact = a; void sq; }
  // --- fase 3 (6.2–8): gato bravo espia a toquinha, rato dá "BONK" com martelo ---
  const peek = t > 6.3; let cat2 = null;
  if (peek) { const a = t - 6.3, k2 = L.ease.out(L.clamp(a / .4)); c = { x: hole - 150 * K - (1 - k2) * 60 * K, y: FY, pose: 'idle', eyes: a > 1.0 ? 'dizzy' : 'angry', mouth: a > 1.0 ? 'o' : 'flat', flip: false, lean: .3 + (a > 1.0 ? -.2 : 0), sy: a > 1.1 ? .86 : 1, sx: a > 1.1 ? 1.12 : 1 }; }
  g.save(); g.translate(Math.sin(t * 90) * shake, Math.cos(t * 77) * shake);
  // objetos
  const chTaken = t > 1.9; if (!chTaken) cheese(g, cheesePos[0], cheesePos[1], 1.1 * K);
  // rachadura na parede
  if (t > hit) { g.save(); g.translate(hole - 40 * K, FY - 260 * K); g.strokeStyle = TINK; g.lineWidth = 6; g.lineCap = 'round'; for (let i = 0; i < 9; i++) { const a = i * .7 + .3, l = (60 + L.hash(i, 2) * 90) * K * L.clamp((t - hit) * 8); g.beginPath(); g.moveTo(0, 0); g.lineTo(Math.cos(a) * l * .5, Math.sin(a) * l * .5); g.lineTo(Math.cos(a + .2) * l, Math.sin(a + .2) * l); g.stroke(); } g.restore(); }
  // Zzz
  if (t < 1.9) { g.fillStyle = '#fff'; g.strokeStyle = TINK; g.lineWidth = 5; g.font = '900 54px "Archivo Black","Impact",sans-serif'; g.lineJoin = 'round'; for (let i = 0; i < 3; i++) { const f = ((t * .5 + i * .33) % 1); g.globalAlpha = 1 - f; g.strokeText('Z', rm.sofaX + 150 * K + f * 60 * K, FY - 330 * K - f * 120 * K - i * 20); g.fillText('Z', rm.sofaX + 150 * K + f * 60 * K, FY - 330 * K - f * 120 * K - i * 20); } g.globalAlpha = 1; }
  toonCat(g, { ...c, s: S, t }); toonMouse(g, { ...m, s: S * 1.0, t });
  if (t > 7.0 && t < 8.3) { const a = t - 7.0, sw = a < .25 ? -1.5 + a / .25 * 2.1 : .6 - (a - .25) * .8; g.save(); g.translate(hole + 30 * K, FY - 120 * K); g.rotate(sw); g.strokeStyle = TINK; g.lineWidth = 16 * K; g.lineCap = 'round'; g.beginPath(); g.moveTo(0, 0); g.lineTo(0, -110 * K); g.stroke(); g.strokeStyle = '#c98a4a'; g.lineWidth = 8 * K; g.beginPath(); g.moveTo(0, 0); g.lineTo(0, -108 * K); g.stroke(); L.rr(g, -34 * K, -150 * K, 68 * K, 44 * K, 8 * K); L.fillStroke(g, '#8a8fa8', TINK, 5); g.restore(); }
  if (t > run0 && t < hit) { speedLines(g, c.x - 90 * K, FY - 160 * K, 220 * K, t); L.puff(g, c.x - 60 * K, FY, (t * 4) % .7, 1.4 * K); }
  if (impact !== null) { bonk(g, hole - 200 * K, FY - 420 * K, impact, 'BAM!'); if (impact > .3 && t < 6.3) stars(g, c.x + 20 * K, FY - 400 * K * S, t, 90 * K); }
  if (t > 6.3) { const a = t - 6.3; if (a > 1.0) { bonk(g, hole - 150 * K, FY - 480 * K, a - 1.0, 'BONK!'); stars(g, c.x + 20 * K, FY - 400 * K * S, t, 90 * K); } }
  g.restore(); g.restore();
  if (t > 8.2) { const p = L.clamp((t - 8.2) / 1.6), ix = hole, iy = FY - 80 * K; irisOut(g, W, H, ix, iy, p); if (p > .85) { g.fillStyle = '#fff'; g.font = '900 ' + 90 * K + 'px "Archivo Black","Impact",sans-serif'; g.textAlign = 'center'; g.fillText('FIM!', W / 2, H / 2); } }
}
