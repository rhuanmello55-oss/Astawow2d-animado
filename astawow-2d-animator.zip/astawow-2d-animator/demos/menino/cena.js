const CONFIG = { w: 1080, h: 1920, fps: 30, dur: 10 };
// window.WORDS vem do words.js gerado por audio/mix.py (legenda = fala)
function leaf(g, x, y, a, s) { g.save(); g.translate(x, y); g.rotate(a); g.scale(s, s); g.fillStyle = '#7bd56a'; g.beginPath(); g.moveTo(-26, 0); g.quadraticCurveTo(0, -20, 26, 0); g.quadraticCurveTo(0, 20, -26, 0); g.fill(); g.strokeStyle = '#2f8a38'; g.lineWidth = 4; g.beginPath(); g.moveTo(-26, 0); g.lineTo(26, 0); g.stroke(); g.restore(); }
function bulb(g, x, y, k, t) { if (k < .02) return; g.save(); g.translate(x, y + Math.sin(t * 4) * 5); g.scale(k, k); const gl = g.createRadialGradient(0, 0, 5, 0, 0, 120); gl.addColorStop(0, 'rgba(255,240,150,.85)'); gl.addColorStop(1, 'rgba(255,240,150,0)'); g.fillStyle = gl; g.beginPath(); g.arc(0, 0, 120, 0, 7); g.fill(); g.beginPath(); g.arc(0, -6, 38, 0, 7); L.fillStroke(g, '#ffe14a', '#111318', 7); L.rr(g, -18, 28, 36, 26, 6); L.fillStroke(g, '#cfd3da', '#111318', 6); g.strokeStyle = '#111318'; g.lineWidth = 5; g.beginPath(); g.moveTo(-14, -4); g.lineTo(0, 10); g.lineTo(14, -4); g.stroke(); for (let i = 0; i < 8; i++) { const a = i * .785; g.beginPath(); g.moveTo(Math.cos(a) * 58, -6 + Math.sin(a) * 58); g.lineTo(Math.cos(a) * 80, -6 + Math.sin(a) * 80); g.stroke(); } g.restore(); }
function draw(g, t, W, H) {
  const k = L.clamp(t / 10), GY = 1340, punch = .05 * Math.max(0, 1 - (t - 7.2) * 3) * (t > 7.2 ? 1 : 0);
  g.save(); L.cam(g, W, H, t, { zoom: 1.02 + .08 * k + punch, drift: .008, px: 30 - 60 * k, py: -20 * k });
  L.sky(g, W, H, '#6fb9f0', '#f4fbff');
  const sun = g.createRadialGradient(170, 210, 10, 170, 210, 420); sun.addColorStop(0, 'rgba(255,250,210,.95)'); sun.addColorStop(1, 'rgba(255,250,210,0)'); g.fillStyle = sun; g.fillRect(0, 0, W, 800); g.fillStyle = '#fffbe0'; g.beginPath(); g.arc(170, 210, 58, 0, 7); g.fill();
  L.cloudLP(g, 380 + t * 14, 330, 1.5); L.cloudLP(g, 880 - t * 8, 520, 1.0);
  g.save(); g.translate(-k * 40, 0); L.hill(g, W + 90, H, 900, 40, 1.1, .6, '#8fcf9a', '#5fae6b'); g.restore();
  g.save(); g.translate(-k * 80, 0); L.hill(g, W + 90, H, 980, 50, .9, 2.2, '#6fc06a', '#3f9a48'); g.restore();
  L.hill(g, W, H, 1060, 36, 1.3, 4, '#5db14f', '#2f8a3a'); L.field(g, W, 1060, 1400, 8, 20, t, 3);
  for (let i = 0; i < 16; i++) L.flower(g, 40 + L.hash(i, 8) * 1000, 1120 + L.hash(i, 9) * 280, .8 + L.hash(i, 7) * .5, t, ['#ff6f91', '#ffd23f', '#ffffff', '#b28dff'][i % 4]);
  L.bigTree(g, 800, 1250, 1, t);
  // passarinho na galha: voa quando a folha solta (t≈4)
  if (t < 4) L.bird(g, 640, 700 + Math.sin(t * 3) * 1.5, t, '#3b6fd8', .9, 0); else { const f = t - 4; L.bird(g, 640 + f * 260, 700 - f * 220 - Math.sin(f * 6) * 12, t, '#3b6fd8', .9 * Math.max(.3, 1 - f * .25), 1); }
  L.butterfly(g, 540 + Math.sin(t * .9) * 380, 1000 + Math.sin(t * 1.7) * 110, t, '#ff9f1c', 1.1);
  // roteiro: anda (0–1.5) → pula e senta (1.5–1.8) → acena (2.2–3.8) → folha cai (4–6.6) e pousa na mão → ideia! (7.2) → acena (8.4+)
  const hx = 200 + 94 * 1.1, hy = GY - 104 * 1.1; let lx = 0, ly = 0, lf = 0;
  if (t > 4) { lf = L.clamp((t - 4) / 2.6); lx = L.lerp(330 + Math.sin(lf * 9) * 70 * (1 - lf), hx, L.ease.inOut(lf)) ; ly = L.lerp(620, hy - 10, lf * lf * .4 + lf * .6); if (t >= 6.6) { lx = hx; ly = hy - 12 + Math.sin(t * 2) * 1.5; } }
  const lookX = t > 4 ? L.clamp((lx - 200) / 220, -1, 1) : .5, lookUp = t > 4 && t < 6.2 ? L.clamp((GY - ly) / 600, 0, 1) : .2;
  if (t < 1.65) { const kk = Math.min(1, t / 1.5), x = L.lerp(-150, 210, kk), hop = t > 1.5 ? Math.sin((t - 1.5) / .15 * Math.PI) * 34 : 0, st = t > 1.5 ? 1 + .08 * Math.sin((t - 1.5) / .15 * Math.PI) : 1;
    L.shadow(g, x, GY + 4, 90 * (1 - hop / 90), 16, .22); for (let q = 0; q < 6; q++) { const t0 = .15 + q * .24; if (t0 < 1.5) L.puff(g, L.lerp(-150, 210, t0 / 1.5) - 24, GY + 2, t - t0, .5); }
    g.save(); g.translate(x, GY - hop); g.scale(1 / st, st); L.ballGuy(g, { x: 0, y: 0, s: .95, t, pose: 'walk', walk: t < 1.5 ? 1 : 0, ph: t * 9, look: .4, shadow: false }); g.restore(); }
  else { const sq = 1 + .07 * Math.max(0, 1 - (t - 1.65) / .22) * Math.sin((t - 1.65) * 28), wave = (t > 2.2 && t < 3.8) || t > 8.4, surprised = t > 5.2 && t < 6.6;
    L.puff(g, 260, GY + 2, t - 1.65, 1.2); L.puff(g, 170, GY + 2, t - 1.65, 1.0);
    g.save(); g.translate(200, GY); g.scale(1 / sq, sq); g.translate(-200, -GY);
    L.ballGuy(g, { x: 200, y: GY, s: 1.1, t, pose: 'sit', look: lookX, up: lookUp, wave: wave ? 1 : 0, talk: wave ? Math.abs(Math.sin(t * 10)) * .8 : 0, mouth: surprised ? 'o' : 'smile', tilt: t > 4 && t < 6.6 ? -.08 + Math.sin(t * 1.5) * .03 : Math.sin(t * 2) * .03 }); g.restore();
    if (t >= 4) { leaf(g, lx, ly, t < 6.6 ? lf * 9 : .5, t < 6.6 ? 1.5 : .8); }
    if (t > 7.2) { bulb(g, 215, 780, L.spring(t - 7.2), t); for (let i = 0; i < 6; i++) { const a = i * 1.047 + t * .5, r = 60 + (t - 7.2) * 50; if (t - 7.2 < 1.2) L.sparkle(g, 215 + Math.cos(a) * r, 780 + Math.sin(a) * r, 11 * (1 - (t - 7.2) / 1.2), t * 3); } } }
  L.field(g, W, 1560, 1980, 6, 14, t, 11, .15); for (let i = 0; i < 8; i++) L.flower(g, 60 + L.hash(i, 12) * 960, 1700 + L.hash(i, 13) * 200, 1.8, t, ['#ff6f91', '#ffd23f', '#ffffff', '#b28dff'][i % 4]);
  L.rays(g, W, H, 170, 210, t, .10); L.drift(g, W, H, t, 18, ['#b9f08a', '#7bd56a', '#fff3a0'], 11);
  g.restore();
  if (t > 6.2) L.title(g, W, 'RESPIRA...', 330, t - 6.2, { t0: 0, size: 64, bg: '#14161c' });
  L.captions(g, W, H, WORDS, t, { y: H * .78, size: 92, group: 2 });
}
