/* shop.js — cena isométrica de loja pronta (mercadinho, padaria, farmácia...). Troque só o objeto C.
   Uso:  shopScene(g, t, W, H, SHOP_BLUE)   — t = tempo local; clientes/carros em laço de 4 s. */
const SHOP_BLUE = { sky: ['#2f86e0', '#cfeaff'], ground: '#8fd0f7', roof: '#1f5fd0', wall: '#e9f4ff', walk: '#dcebfd', curb: '#a8c1e6', road: '#263353', sign: '#12306b', tree: ['#1f8f9c', '#187a86', '#29a3b0', '#36b7c4'], car: '#ffc93c',
  name: 'MERCADINHO', sub: 'FRUTAS • BEBIDAS • PÃO', rival: 'SUPERMERCADÃO', p1: 'R$ 9,99', p2: 'R$ 5,99', title: 'MAIS BARATO QUE O SUPERMERCADO!' };
const SHOP_BAKERY = { sky: ['#ff9a62', '#ffe8c6'], ground: '#ffd9a0', roof: '#d9552b', wall: '#fff3e0', walk: '#f6dcc0', curb: '#d7b08a', road: '#3a2b33', sign: '#6b2b1a', tree: ['#d9822f', '#c06a22', '#eea04a', '#f7bd6e'], car: '#7ec8ff',
  name: 'PADARIA', sub: 'PÃO QUENTINHO • BOLOS', rival: 'MEGA PADARIA', p1: 'R$ 1,80', p2: 'R$ 0,99', title: 'PÃO QUENTINHO TODA HORA!' };
const SHOP_PHARMA = { sky: ['#37b88f', '#d9fff0'], ground: '#a6e6c8', roof: '#14925f', wall: '#f2fffa', walk: '#e2f6ee', curb: '#9fd1bb', road: '#27403a', sign: '#0b5c3b', tree: ['#2f9a6a', '#27855a', '#44b784', '#5acb98'], car: '#ff6f61',
  name: 'FARMÁCIA', sub: 'REMÉDIOS • BELEZA • 24H', rival: 'MEGAFARMA', p1: 'R$ 29,90', p2: 'R$ 17,90', title: 'ECONOMIZE EM CADA COMPRA!' };
// --- Cena 2: MERCADINHO low-poly isométrico, tudo azul, colado na rua; clientes entram/saem, carros passam ---
function shopScene(g, t, W, H, C) {
  const u = t % 4;
  L.sky(g, W, H, C.sky[0], C.sky[1]); L.cloudLP(g, 220 + t * 22, 240, 1.3); L.cloudLP(g, 840 - t * 14, 370, 1.0);
  g.fillStyle = C.ground; g.fillRect(0, 700, W, H - 700);
  // supermercado do fundo (frio e caro)
  const sx = 30, sy = 500; g.fillStyle = '#8f9db8'; g.fillRect(sx, sy, 400, 200); g.fillStyle = '#6f7e9b'; g.fillRect(sx, sy, 400, 28); g.fillStyle = '#c4d4ec'; for (let i = 0; i < 5; i++) g.fillRect(sx + 20 + i * 76, sy + 60, 58, 90);
  g.fillStyle = '#c0392b'; L.rr(g, sx + 60, sy + 34, 280, 40, 8); g.fill(); g.font = '900 26px "Archivo Black","Impact","DejaVu Sans",sans-serif'; g.fillStyle = '#fff'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(C.rival, sx + 200, sy + 55);
  const P = L.iso(560, 1010, 98), BLU = C.tree;
  // rua azul-marinho colada na calçada, com faixas rolando
  L.box(g, P, -12, 3.2, 0, 24, 3.0, .06, C.road); L.box(g, P, -12, 3.2, .06, 24, .12, 0, '#7f93bd');
  for (let i = -14; i < 14; i++) { const x0 = i * 1.6 + ((t * 2.4) % 1.6), A = P(x0, 4.7, .07), B = P(x0 + .8, 4.7, .07); g.strokeStyle = '#eaf2ff'; g.lineWidth = 7; g.lineCap = 'butt'; g.beginPath(); g.moveTo(A[0], A[1]); g.lineTo(B[0], B[1]); g.stroke(); }
  L.box(g, P, -3.4, -2.2, 0, 6.8, 5.4, .14, C.walk); L.box(g, P, -3.4, 3.0, .14, 6.8, .2, 0, C.curb);
  const rise = L.spring(t - .05), hh = 3.0 * rise;
  L.box(g, P, -2.6, -1.6, 0, 5.2, 3.2, hh, C.wall);
  L.box(g, P, -2.72, -1.72, hh, 5.44, 3.44, .24 * rise, C.roof);
  L.treeLP(g, P, 3.4, -1.4, Math.sin(t * 2), BLU); L.treeLP(g, P, -3.1, 2.4, Math.sin(t * 2 + 1), BLU);
  if (rise > .95) {
    L.box(g, P, 1.4, -1.0, hh + .24, .9, .8, .35, '#9db4d8');                                                     // ar-condicionado no telhado
    const pop = L.spring(t - .5); L.box(g, P, -2.2, -.5, hh + .24, 4.4, .16, 1.15 * pop, C.sign);            // letreiro no telhado
    if (pop > .5) { g.save(); L.faceY(g, P, -2.2, -.34); g.globalAlpha = Math.min(1, pop); const glow = .75 + .25 * Math.sin(t * 6); g.font = '900 50px "Archivo Black","Impact","DejaVu Sans",sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.shadowColor = '#7cc8ff'; g.shadowBlur = 18 * glow; g.fillStyle = '#ffffff'; g.fillText(C.name, 220, -(hh + .24 + .55) * 100); g.restore(); }
    g.save(); L.faceY(g, P, -2.6, 1.6);
    const wall = (x0, x1, z0, z1, f, st) => { L.rr(g, x0 * 100, -z1 * 100, (x1 - x0) * 100, (z1 - z0) * 100, 8); L.fillStroke(g, f, st, 6); };
    for (const [x0, x1] of [[.3, 1.6], [3.5, 4.8]]) { wall(x0, x1, .75, 1.85, '#aee3ff', '#1c2a4a'); g.fillStyle = 'rgba(255,240,180,.55)'; g.fillRect(x0 * 100 + 6, -178, (x1 - x0) * 100 - 12, 40); g.fillStyle = 'rgba(255,255,255,.6)'; g.beginPath(); g.moveTo(x0 * 100 + 18, -176); g.lineTo(x0 * 100 + 58, -176); g.lineTo(x0 * 100 + 8, -90); g.lineTo(x0 * 100 - 32 + 18, -90); g.fill(); }
    const open = L.ease.smooth((u - 1.35) / .35) * (1 - L.ease.smooth((u - 2.5) / .35)); wall(2.05, 3.05, 0, 1.75, '#1b2b4a', '#1c2a4a');
    g.save(); L.rr(g, 205, -175, 100 * (1 - .85 * open), 175, 8); g.clip(); g.fillStyle = '#9fdcff'; g.fillRect(205, -175, 100, 175); g.restore(); g.strokeStyle = '#1c2a4a'; g.lineWidth = 6; L.rr(g, 205, -175, 100 * (1 - .85 * open), 175, 8); g.stroke();
    const sw = Math.sin(t * 2.4) * 6; for (let i = 0; i < 9; i++) { const x0 = 20 + i * 55; g.fillStyle = i % 2 ? '#ffffff' : C.roof; g.beginPath(); g.moveTo(x0, -215); g.lineTo(x0 + 55, -215); g.lineTo(x0 + 55 + 8, -188 + sw * .3); g.lineTo(x0 + 8, -188 + sw * .3); g.fill(); }
    g.fillStyle = C.sign; L.rr(g, 40, -280, 440, 60, 12); g.fill(); g.font = '900 27px "Archivo Black","Impact","DejaVu Sans",sans-serif'; g.fillStyle = '#ffd23f'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(C.sub, 260, -250);
    g.restore();
  }
  L.lampLP(g, P, -3.3, 3.0, t); L.lampLP(g, P, 3.3, 3.0, t);
  // carros em duas faixas
  const car = (x0, y0, col, dir) => { L.box(g, P, x0, y0, .1, 1.9, .9, .42, col); L.box(g, P, x0 + (dir > 0 ? .5 : .4), y0 + .05, .52, 1.0, .8, .36, '#d9f0ff'); for (const wx2 of [x0 + .25, x0 + 1.35]) { const [qx, qy] = P(wx2, y0 + .9, .12); g.fillStyle = '#10131c'; g.beginPath(); g.arc(qx, qy, 17, 0, 7); g.fill(); g.fillStyle = '#c9d4ea'; g.beginPath(); g.arc(qx, qy, 7, 0, 7); g.fill(); } };
  car(L.lerp(-8, 8, (t / 4 + .1) % 1), 3.55, C.car, 1);
  // caixotes de frutas
  for (const [cx, cy, c1] of [[-2.3, 2.15, '#e8452c'], [-1.5, 2.15, '#f4a21d']]) { L.box(g, P, cx, cy, 0, .7, .6, .35, '#b98652'); const [qx, qy] = P(cx + .35, cy + .3, .4); for (let k = 0; k < 4; k++) { g.fillStyle = c1; g.beginPath(); g.arc(qx - 18 + k * 12, qy - 4 + (k % 2) * 6, 11, 0, 7); g.fill(); g.fillStyle = 'rgba(255,255,255,.4)'; g.beginPath(); g.arc(qx - 21 + k * 12, qy - 8 + (k % 2) * 6, 3.5, 0, 7); g.fill(); } }
  // cliente 1 entra pela porta; cliente 2 sai com sacola
  const pers = (wx, wy, al, shirt, bag) => { const [px, py] = P(wx, wy, 0); g.save(); g.globalAlpha = al; L.person(g, { x: px, y: py, s: .42, t, pose: 'walk', shirt, pants: '#2c3550', skin: '#f2c6a0', hair: '#1c1412', mouth: 'smile', brow: .4, prop: bag ? (h) => { h.fillStyle = '#ffc93c'; L.rr(h, -18, -10, 44, 52, 6); L.fillStroke(h, '#ffc93c', C.sign, 5); h.beginPath(); h.arc(4, -10, 14, Math.PI, 0); h.strokeStyle = C.sign; h.lineWidth = 5; h.stroke(); } : undefined }); g.restore(); };
  if (u < 2.25) { const k1 = L.clamp((u - .1) / 1.4), k2 = L.clamp((u - 1.5) / .7); pers(L.lerp(.7, 2.55, k1), L.lerp(2.75, 1.85, k2), 1 - L.ease.smooth((u - 1.95) / .3), '#2f6fd1', false); }
  if (u > 1.9) { const k = L.clamp((u - 1.9) / .6), k2 = L.clamp((u - 2.5) / .5); pers(L.lerp(2.55, 3.4, k2), L.lerp(1.85, 2.8, k), L.ease.smooth((u - 1.9) / .25), '#e8704a', true); }
  L.priceTag(g, 240, 440, C.p1, t, '#c0392b', { t0: .8, size: 46, rot: -.1 });
  L.priceTag(g, 800, 1090, C.p2, t, '#1fa84f', { t0: 1.8, size: 78, rot: .06 });
  L.title(g, W, C.title, 190, t, { t0: .15, size: 40, bg: C.roof });
}
