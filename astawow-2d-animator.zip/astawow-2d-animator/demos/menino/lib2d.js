/* lib2d.js — biblioteca da skill astawow-2d-animator.
   Script clássico (sem import/export). Tudo é função pura do tempo: nada de Math.random/Date/setTimeout.
   Uso: <script src="lib2d.js"></script>  → global `L`. */
const L = (() => {
  const clamp = (x, a = 0, b = 1) => Math.min(b, Math.max(a, x));
  const lerp = (a, b, t) => a + (b - a) * t;
  const mixc = (c1, c2, t) => { const p = (c) => [1, 3, 5].map((i) => parseInt(c.slice(i, i + 2), 16)); const a = p(c1), b = p(c2); return '#' + a.map((v, i) => Math.round(lerp(v, b[i], t)).toString(16).padStart(2, '0')).join(''); };
  const ease = { out: (t) => 1 - Math.pow(1 - clamp(t), 3), inOut: (t) => { t = clamp(t); return t < .5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; }, smooth: (t) => { t = clamp(t); return t * t * (3 - 2 * t); } };
  // mola amortecida de forma fechada (0→1). k = rigidez, d = amortecimento.
  const spring = (t, k = 190, d = 15) => { if (t <= 0) return 0; const w = Math.sqrt(k), z = d / (2 * w); if (z < 1) { const wd = w * Math.sqrt(1 - z * z); return 1 - Math.exp(-z * w * t) * (Math.cos(wd * t) + (z * w / wd) * Math.sin(wd * t)); } return 1 - Math.exp(-w * t) * (1 + w * t); };
  const hash = (i, s = 0) => { let x = (i * 374761393 + s * 668265263) | 0; x = (x ^ (x >>> 13)) * 1274126177 | 0; return ((x ^ (x >>> 16)) >>> 0) / 4294967295; };
  const tri = (t) => Math.abs(((t % 1) + 1) % 1 * 2 - 1);

  /* ---------- primitivas ---------- */
  const rr = (g, x, y, w, h, r) => { g.beginPath(); g.roundRect(x, y, w, h, Math.min(r, w / 2, h / 2)); };
  const fillStroke = (g, fill, stroke, lw) => { if (fill) { g.fillStyle = fill; g.fill(); } if (stroke && lw) { g.strokeStyle = stroke; g.lineWidth = lw; g.lineJoin = 'round'; g.stroke(); } };
  const poly = (g, pts, fill, stroke, lw) => { g.beginPath(); pts.forEach((p, i) => (i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1]))); g.closePath(); fillStroke(g, fill, stroke, lw); };
  const shadow = (g, x, y, w, h = w * .22, a = .22) => { g.save(); g.fillStyle = `rgba(0,0,0,${a})`; g.beginPath(); g.ellipse(x, y, w, h, 0, 0, 7); g.fill(); g.restore(); };

  /* ---------- câmera ---------- */
  // zoom/pan suaves + respiração. Chame g.save() antes e g.restore() depois.
  const cam = (g, W, H, t, o = {}) => { const z = (o.zoom || 1) + (o.drift === undefined ? .03 : o.drift) * Math.sin(t * .6); const sx = (o.shake || 0) * Math.sin(t * 61) * (o.shakeOn ? 1 : 0); g.translate(W / 2 + (o.px || 0) + sx, H / 2 + (o.py || 0)); g.scale(z, z); g.translate(-W / 2, -H / 2); };

  /* ---------- PERSONAGEM 2D plano (estilo vetor limpo, cabeçona) ----------
     Origem = pés. Altura total ≈ 400 unidades (multiplique por s).
     o = { x,y,s,flip, skin,hair,hairStyle('short'|'spiky'|'cap'|'bun'|'none'|'bald'), shirt,pants,shoes, outline,
           mustache,blush,beard, brow(-1..1 raiva↔surpresa), mouth('smile'|'A'|'O'|'E'|'M'|'sad'), look:[dx,dy],
           armL:ang, armR:ang (rad; 0 = pendurado; positivo = abre o braço para FORA do corpo, 1.5 ≈ horizontal), pose:'idle'|'walk'|'run'|'sit', t, walkSpeed, prop:fn(g) }  */
  const OUT_DEFAULT = '#2a1b2e';
  const person = (g, o) => {
    const s = o.s || 1, t = o.t || 0, ol = o.outline || OUT_DEFAULT, lw = (o.lw || 6);
    const skin = o.skin || '#f2c6a0', hair = o.hair || '#3a2a20', shirt = o.shirt || '#4a6a96', pants = o.pants || '#2c3550', shoes = o.shoes || '#5a3b2b';
    const walking = o.pose === 'walk' || o.pose === 'run'; const sp = o.walkSpeed || (o.pose === 'run' ? 9 : 5.5);
    const ph = t * sp, bob = walking ? Math.abs(Math.sin(ph)) * 10 : Math.sin(t * 2.2) * 3;
    const breathe = 1 + Math.sin(t * 2.2) * .008;
    g.save(); g.translate(o.x || 0, o.y || 0); g.scale((o.flip ? -1 : 1) * s, s);
    if (o.shadow !== false) shadow(g, 0, 4, 78, 15);
    const legA = walking ? Math.sin(ph) * .55 : 0;
    const leg = (dx, a, col) => { g.save(); g.translate(dx, -118 - bob * .4); g.rotate(a); rr(g, -17, 0, 34, 112, 14); fillStroke(g, col, ol, lw); rr(g, -22, 102, 52, 24, 12); fillStroke(g, shoes, ol, lw); g.restore(); };
    leg(-24, -legA, mixc(pants, '#000000', .12)); leg(24, legA, pants);
    // tronco
    g.save(); g.translate(0, -bob); g.scale(1, breathe);
    const armPose = (side) => { const base = side < 0 ? (o.armL === undefined ? (walking ? -Math.sin(ph) * .7 : .12) : o.armL) : (o.armR === undefined ? (walking ? Math.sin(ph) * .7 : .12) : o.armR); return base; };
    const arm = (side) => { const a = armPose(side); g.save(); g.translate(side * 62, -262); g.rotate(a * -side); rr(g, -17, -8, 34, 116, 16); fillStroke(g, shirt, ol, lw); g.fillStyle = skin; g.beginPath(); g.arc(0, 118, 21, 0, 7); fillStroke(g, skin, ol, lw); g.restore(); };
    arm(-1);
    rr(g, -62, -300, 124, 192, 34); fillStroke(g, shirt, ol, lw);
    if (o.collar !== false) { g.fillStyle = mixc(shirt, '#ffffff', .25); g.beginPath(); g.moveTo(-22, -300); g.lineTo(0, -270); g.lineTo(22, -300); g.closePath(); g.fill(); g.strokeStyle = ol; g.lineWidth = lw * .7; g.stroke(); }
    if (o.buttons) { g.fillStyle = mixc(shirt, '#ffffff', .6); for (let i = 0; i < 4; i++) { g.beginPath(); g.arc(0, -250 + i * 34, 5, 0, 7); g.fill(); } }
    if (o.belt) { rr(g, -62, -142, 124, 20, 6); fillStroke(g, o.belt, ol, lw * .8); }
    arm(1);
    if (o.prop) { g.save(); g.translate(side0(o), 0); o.prop(g); g.restore(); }
    // pescoço + cabeça
    rr(g, -16, -318, 32, 28, 10); fillStroke(g, skin, ol, lw);
    const hy = -388 + Math.sin(t * 2.2 + .6) * 2; g.save(); g.translate(0, hy);
    if (o.hairStyle === 'bun') { g.fillStyle = hair; g.beginPath(); g.arc(0, -86, 26, 0, 7); fillStroke(g, hair, ol, lw); }
    // orelhas
    for (const sx of [-1, 1]) { g.beginPath(); g.ellipse(sx * 76, 4, 15, 21, 0, 0, 7); fillStroke(g, skin, ol, lw); }
    g.beginPath(); g.ellipse(0, 0, 82, 88, 0, 0, 7); fillStroke(g, skin, ol, lw);
    // cabelo
    const hs = o.hairStyle || 'short';
    if (hs === 'short' || hs === 'cap' || hs === 'bun') { g.beginPath(); g.moveTo(-82, -8); g.bezierCurveTo(-90, -92, -40, -104, 0, -102); g.bezierCurveTo(40, -104, 92, -92, 82, -8); g.bezierCurveTo(52, -40, 22, -50, -4, -42); g.bezierCurveTo(-30, -52, -60, -36, -82, -8); fillStroke(g, hair, ol, lw); }
    if (hs === 'spiky') { const pts = [[-84, -6]]; for (let i = 0; i < 7; i++) { const a = Math.PI + (i / 6) * Math.PI; pts.push([Math.cos(a) * 96, Math.sin(a) * 100 - 6]); pts.push([Math.cos(a + .2) * 126, Math.sin(a + .2) * 134 - 6]); } pts.push([84, -6], [50, -38], [0, -30], [-50, -38]); poly(g, pts, hair, ol, lw); }
    if (hs === 'cap') { g.beginPath(); g.moveTo(-86, -30); g.bezierCurveTo(-80, -110, 80, -110, 86, -30); g.closePath(); fillStroke(g, o.capColor || '#c8402f', ol, lw); rr(g, 10, -40, 92, 20, 10); fillStroke(g, mixc(o.capColor || '#c8402f', '#000000', .2), ol, lw); }
    // olhos
    const look = o.look || [0, 0], blink = (Math.sin(t * 1.37 + 1.1) > .985 || (t % 4.1) > 4.0) ? .12 : 1;
    for (const sx of [-1, 1]) { const ex = sx * 34, ey = 4; g.save(); g.translate(ex, ey); g.scale(1, blink); g.beginPath(); g.ellipse(0, 0, 21, 25, 0, 0, 7); fillStroke(g, '#ffffff', ol, lw * .8); g.fillStyle = ol; g.beginPath(); g.arc(look[0] * 6, look[1] * 6, 10, 0, 7); g.fill(); g.fillStyle = '#fff'; g.beginPath(); g.arc(look[0] * 6 + 4, look[1] * 6 - 4, 3.4, 0, 7); g.fill(); g.restore();
      const br = o.brow === undefined ? 0 : o.brow; g.save(); g.translate(ex, -34 - br * 8); g.rotate(sx * (-br) * .45 * -1 + 0); g.strokeStyle = o.browColor || ol; g.lineWidth = lw + 2; g.lineCap = 'round'; g.beginPath(); g.moveTo(-18, br < 0 ? -sx * -6 : 0); g.lineTo(18, br < 0 ? sx * -6 : 0); g.stroke(); g.restore(); }
    // nariz
    g.beginPath(); g.ellipse(0, 36, 12, 9, 0, 0, 7); fillStroke(g, mixc(skin, '#8a4b2a', .18), ol, lw * .7);
    if (o.blush) { g.fillStyle = 'rgba(224,100,100,.35)'; for (const sx of [-1, 1]) { g.beginPath(); g.ellipse(sx * 52, 40, 17, 11, 0, 0, 7); g.fill(); } }
    if (o.mustache) { g.fillStyle = o.mustacheColor || hair; g.beginPath(); g.moveTo(0, 46); g.bezierCurveTo(-30, 30, -62, 40, -60, 58); g.bezierCurveTo(-40, 56, -20, 58, 0, 54); g.bezierCurveTo(20, 58, 40, 56, 60, 58); g.bezierCurveTo(62, 40, 30, 30, 0, 46); fillStroke(g, o.mustacheColor || hair, ol, lw * .7); }
    mouth(g, o.mouth || 'smile', 0, o.mustache ? 72 : 62, ol, lw, o.mouthOpen === undefined ? 1 : o.mouthOpen);
    g.restore(); g.restore(); g.restore();
  };
  const side0 = (o) => 0;
  // boca por visema. open 0..1 modula a abertura (use o envelope do áudio).
  const mouth = (g, kind, x, y, ol, lw, open = 1) => {
    g.save(); g.translate(x, y); g.lineCap = 'round';
    if (kind === 'smile') { g.beginPath(); g.arc(0, -8, 26, .15, Math.PI - .15); g.strokeStyle = ol; g.lineWidth = lw; g.stroke(); }
    else if (kind === 'sad') { g.beginPath(); g.arc(0, 22, 24, Math.PI + .25, -.25); g.strokeStyle = ol; g.lineWidth = lw; g.stroke(); }
    else if (kind === 'M') { g.beginPath(); g.moveTo(-22, 0); g.lineTo(22, 0); g.strokeStyle = ol; g.lineWidth = lw; g.stroke(); }
    else { const w = kind === 'E' ? 34 : kind === 'O' ? 15 : 24, h = (kind === 'O' ? 26 : kind === 'E' ? 12 : 30) * (.25 + .75 * open); g.beginPath(); g.ellipse(0, 6, w, h, 0, 0, 7); fillStroke(g, '#5a1d26', ol, lw * .9); g.save(); g.clip(); g.fillStyle = '#e8718a'; g.beginPath(); g.ellipse(0, 6 + h * .7, w * .7, h * .5, 0, 0, 7); g.fill(); g.restore(); }
    g.restore();
  };
  // converte envelope (0..1) em visema alternando para dar vida
  const visemeFrom = (env, t) => (env < .08 ? 'M' : env < .3 ? 'E' : (Math.floor(t * 9) % 3 === 0 ? 'O' : 'A'));

  /* ---------- ISOMÉTRICO LOW-POLY (cenários 3D falsos) ----------
     L.iso(cx,cy,u): projeta (x,y,z) mundo → tela. x para a direita-baixo, y para a esquerda-baixo, z para cima. */
  const iso = (cx, cy, u = 60, rot = 0) => { const c = Math.cos(rot), s = Math.sin(rot); return (x, y, z = 0) => { const rx = x * c - y * s, ry = x * s + y * c; return [cx + (rx - ry) * .866 * u, cy + (rx + ry) * .5 * u - z * u]; }; };
  const box = (g, P, x, y, z, w, d, h, col, edge) => { // caixa com 3 faces sombreadas (cima, esquerda, direita)
    const top = col, left = mixc(col, '#000000', .22), right = mixc(col, '#000000', .38);
    const A = P(x, y, z + h), B = P(x + w, y, z + h), C = P(x + w, y + d, z + h), D = P(x, y + d, z + h), E = P(x, y + d, z), F = P(x + w, y + d, z), G = P(x + w, y, z);
    poly(g, [D, E, F, C], left, edge, edge ? 2 : 0); poly(g, [B, G, F, C], right, edge, edge ? 2 : 0); poly(g, [A, B, C, D], top, edge, edge ? 2 : 0);
  };
  const roof = (g, P, x, y, z, w, d, h, col) => { const a = P(x, y, z), b = P(x + w, y, z), c = P(x + w, y + d, z), dd = P(x, y + d, z), t1 = P(x + w / 2, y + d / 2, z + h); poly(g, [dd, c, t1], mixc(col, '#000000', .25)); poly(g, [b, c, t1], mixc(col, '#000000', .4)); poly(g, [a, b, t1], col); poly(g, [a, dd, t1], mixc(col, '#ffffff', .1)); };
  const treeLP = (g, P, x, y, sway = 0, pal = ['#2f8f4a', '#237a3c', '#3aa95a', '#46b868']) => { box(g, P, x - .08, y - .08, 0, .16, .16, .7, '#8a5a35'); for (let i = 0; i < 3; i++) { const w = 1.1 - i * .3, z = .6 + i * .5; const c = P(x + sway * (i + 1) * .02, y, z + .9), l = P(x - w / 2, y - w / 2, z), r = P(x + w / 2, y + w / 2, z), f = P(x + w / 2, y - w / 2, z), b = P(x - w / 2, y + w / 2, z); poly(g, [b, r, c], pal[0]); poly(g, [f, r, c], pal[1]); poly(g, [l, f, c], pal[2]); poly(g, [l, b, c], pal[3]); } };
  const cloudLP = (g, x, y, s, col = '#ffffff') => { g.save(); g.translate(x, y); g.scale(s, s); const blobs = [[0, 0, 60, 34], [58, 6, 48, 28], [-56, 8, 44, 26], [20, -22, 42, 30]]; blobs.forEach(([bx, by, rx, ry], i) => { g.beginPath(); for (let k = 0; k < 7; k++) { const a = k / 7 * 6.283, r = 1 + .08 * Math.sin(k * 2.3 + i); g.lineTo(bx + Math.cos(a) * rx * r, by + Math.sin(a) * ry * r); } g.closePath(); g.fillStyle = col; g.fill(); }); g.restore(); };
  // estrada vista de cima/iso com faixas rolando
  const roadH = (g, x0, x1, y, w, t, speed = 300) => { g.fillStyle = '#3b3f48'; g.fillRect(x0, y, x1 - x0, w); g.fillStyle = '#e8e6df'; const dash = 90, gap = 70, off = (t * speed) % (dash + gap); for (let x = x0 - dash - gap + off; x < x1; x += dash + gap) g.fillRect(x, y + w / 2 - 5, dash, 10); g.fillStyle = '#6f737d'; g.fillRect(x0, y - 14, x1 - x0, 14); g.fillRect(x0, y + w, x1 - x0, 14); };

  /* ---------- GRAMA / campo (estilo 3D aberto) ---------- */
  const grass = (g, x0, x1, y0, y1, n, t, pal = ['#4fb24a', '#78d159', '#2f8f3a', '#9be36a'], wind = 1, seed = 1) => {
    for (let i = 0; i < n; i++) { const r1 = hash(i, seed), r2 = hash(i, seed + 7), r3 = hash(i, seed + 13); const x = lerp(x0, x1, r1), depth = r2, y = lerp(y0, y1, depth), h = lerp(18, 90, depth) * (.6 + r3 * .8), sw = Math.sin(t * 1.8 + r1 * 20) * 8 * wind * depth; g.beginPath(); g.moveTo(x - 4 * (1 + depth * 2), y); g.quadraticCurveTo(x + sw * .3, y - h * .55, x + sw, y - h); g.quadraticCurveTo(x + sw * .3 + 5 * (1 + depth * 2), y - h * .5, x + 4 * (1 + depth * 2), y); g.closePath(); g.fillStyle = pal[i % pal.length]; g.fill(); }
  };
  const sky = (g, W, H, top = '#7cc4f4', bot = '#d8f0ff') => { const gr = g.createLinearGradient(0, 0, 0, H); gr.addColorStop(0, top); gr.addColorStop(1, bot); g.fillStyle = gr; g.fillRect(0, 0, W, H); };
  const dots = (g, W, H, col = 'rgba(255,255,255,.12)', step = 70, r = 10, t = 0) => { g.fillStyle = col; for (let y = -step; y < H + step; y += step) for (let x = -step; x < W + step; x += step) { g.beginPath(); g.arc(x + ((y / step) % 2 ? step / 2 : 0) + (t * 10) % step, y, r, 0, 7); g.fill(); } };

  /* ---------- LEGENDAS (palavra por palavra, estilo Shorts) ----------
     words = [{w:'texto', t0, t1}]; mostra 1–3 palavras por vez; a palavra atual faz pop com mola. */
  const captions = (g, W, H, words, t, o = {}) => {
    const y = o.y || H * .72, size = o.size || 96, fam = o.font || '"Archivo Black","Anton","Impact","DejaVu Sans",sans-serif', hi = o.hi || '#ffd23f', fill = o.fill || '#ffffff', stroke = o.stroke || '#111111';
    let idx = words.findIndex((w) => t >= w.t0 && t < w.t1); if (idx < 0) { const past = words.filter((w) => w.t1 <= t); if (!past.length || t - past[past.length - 1].t1 > (o.hold || .25)) return; idx = words.indexOf(past[past.length - 1]); }
    const group = o.group || 2, gi = Math.floor(idx / group) * group, list = words.slice(gi, gi + group);
    const label = (s) => (o.upper === false ? s : s.toUpperCase());
    g.save(); g.font = `900 ${size}px ${fam}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.lineJoin = 'round'; g.miterLimit = 2;
    const texts = list.map((w) => label(w.w)), widths = texts.map((s) => g.measureText(s).width), gap = size * .4; let total = widths.reduce((a, b) => a + b, 0) + gap * (list.length - 1);
    let scale = total > W * .92 ? W * .92 / total : 1; let x = W / 2 - total * scale / 2; g.translate(0, y);
    list.forEach((w, i) => { const cur = gi + i === idx, age = t - w.t0, pop = cur ? 1 + .1 * (1 - clamp(spring(age, 420, 20))) : 1, cx = x + widths[i] * scale / 2; g.save(); g.translate(cx, 0); g.scale(scale * (age < 0 ? 0 : pop), scale * (age < 0 ? 0 : pop)); g.lineWidth = size * .2; g.strokeStyle = stroke; g.strokeText(texts[i], 0, 0); g.fillStyle = cur ? hi : fill; g.fillText(texts[i], 0, 0); g.restore(); x += (widths[i] + gap) * scale; });
    g.restore();
  };
  const title = (g, W, text, y, t, o = {}) => { const k = spring(t - (o.t0 || 0)); if (k <= 0.01) return; g.save(); g.translate(W / 2, y); g.rotate(-.03); g.scale(k, k); g.font = `900 ${o.size || 44}px ${o.font || '"Archivo Black","Anton","Impact","DejaVu Sans",sans-serif'}`; const w = g.measureText(text).width + 56, h = (o.size || 44) + 34; rr(g, -w / 2, -h / 2, w, h, 14); fillStroke(g, o.bg || '#1b2340', '#ffffff', 4); g.fillStyle = o.fg || '#ffffff'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(text, 0, 3); g.restore(); };

  /* ---------- timing a partir de palavras ---------- */
  // words.json (do align) → [{w,t0,t1}]. Se só houver texto + duração, distribui por nº de letras.
  const wordsFromText = (text, t0, t1) => { const ws = text.trim().split(/\s+/), tot = ws.reduce((a, w) => a + w.length + 2, 0); let t = t0; return ws.map((w) => { const d = (w.length + 2) / tot * (t1 - t0); const o = { w, t0: t, t1: t + d }; t += d; return o; }); };
  const envAt = (env, fps, t) => { if (!env || !env.length) return 0; const i = Math.min(env.length - 1, Math.max(0, Math.floor(t * fps))); return env[i]; };

  /* ---------- CAMPO / NATUREZA (estilo 3D suave: camadas, luz e sombra) ---------- */
  // morro ondulado: faixa com degradê vertical. y = linha média; amp = altura da onda
  const hill = (g, W, H, y, amp, freq, ph, top, bot) => { const gr = g.createLinearGradient(0, y - amp, 0, y + amp * 3); gr.addColorStop(0, top); gr.addColorStop(1, bot); g.fillStyle = gr; g.beginPath(); g.moveTo(0, H); for (let x = 0; x <= W; x += 20) g.lineTo(x, y + Math.sin(x / W * Math.PI * 2 * freq + ph) * amp); g.lineTo(W, H); g.closePath(); g.fill(); };
  // um tufo de grama: lâminas em leque, metade escura/metade clara (dá volume)
  const tuft = (g, x, y, s, t, pal, seed = 0) => {
    const n = 7; for (let i = 0; i < n; i++) { const r = hash(i, seed), a = (i / (n - 1) - .5) * 1.5, h = s * (34 + r * 36) * (1 - Math.abs(a) * .35), sw = Math.sin(t * 1.9 + x * .013 + i) * s * 6, bw = s * 5.5;
      const tx = x + Math.sin(a) * h * .75 + sw, ty = y - Math.cos(a) * h; const c = pal[i % pal.length];
      g.fillStyle = c[1]; g.beginPath(); g.moveTo(x - bw + i * 1.5 * s, y); g.quadraticCurveTo(x + (tx - x) * .35, y - h * .55, tx, ty); g.lineTo(x + bw * .2 + i * 1.5 * s, y); g.closePath(); g.fill();
      g.fillStyle = c[0]; g.beginPath(); g.moveTo(x + bw * .2 + i * 1.5 * s, y); g.quadraticCurveTo(x + (tx - x) * .45, y - h * .5, tx, ty); g.lineTo(x + bw + i * 1.5 * s, y); g.closePath(); g.fill(); }
  };
  // campo de grama em fileiras de trás pra frente (perspectiva: mais perto = maior, mais escuro e mais saturado)
  const field = (g, W, y0, y1, rows, perRow, t, seed = 1, tint = 0) => {
    for (let r = 0; r < rows; r++) { const d = r / (rows - 1), y = lerp(y0, y1, d * d * .6 + d * .4), s = lerp(.45, 2.1, d), n = Math.round(perRow * lerp(1.3, .55, d));
      const pal = [[mixc('#58b84a', '#2f8f3a', d * .8 + tint), mixc('#7fd35c', '#3fa043', d * .8 + tint)], [mixc('#6fcb55', '#349a3c', d * .8 + tint), mixc('#9be36a', '#4cb24a', d * .8 + tint)]];
      for (let i = 0; i < n; i++) tuft(g, (i + hash(i, seed + r)) / n * (W + 160) - 80, y + hash(i, seed + r * 3) * 14, s, t, pal, i + r * 31); }
  };
  // árvore grande: raiz aberta, tronco com luz/sombra, copa em 3 tons com folhas balançando e sombra no chão
  const bigTree = (g, x, y, s, t, o = {}) => {
    const dark = o.dark || '#2e7d32', mid = o.mid || '#43a047', lite = o.lite || '#7bd56a', sway = Math.sin(t * .9) * 6 * s;
    g.save(); g.translate(x, y); g.scale(s, s);
    g.fillStyle = 'rgba(20,60,30,.28)'; g.beginPath(); g.ellipse(-120, 20, 360, 50, 0, 0, 7); g.fill(); // sombra projetada
    g.fillStyle = '#6a4630'; g.beginPath(); g.moveTo(-95, 10); g.quadraticCurveTo(-60, -40, -50, -140); g.lineTo(-40, -520); g.lineTo(50, -520); g.lineTo(58, -140); g.quadraticCurveTo(66, -40, 110, 10); g.closePath(); g.fill();
    g.fillStyle = '#4f3322'; g.beginPath(); g.moveTo(10, 8); g.quadraticCurveTo(40, -40, 18, -140); g.lineTo(14, -520); g.lineTo(50, -520); g.lineTo(58, -140); g.quadraticCurveTo(66, -40, 110, 10); g.closePath(); g.fill();
    g.strokeStyle = '#3a2417'; g.lineWidth = 5; g.lineCap = 'round'; for (const [a, b, c, d] of [[-25, -100, -18, -180], [-10, -250, -4, -330], [-30, -380, -26, -430]]) { g.beginPath(); g.moveTo(a, b); g.lineTo(c, d); g.stroke(); }
    g.strokeStyle = '#6a4630'; g.lineWidth = 26; g.beginPath(); g.moveTo(-30, -420); g.lineTo(-170, -560); g.stroke(); g.beginPath(); g.moveTo(40, -430); g.lineTo(170, -580); g.stroke();
    const blobs = [[-210, -600, 150], [-60, -690, 170], [110, -700, 160], [250, -610, 140], [0, -560, 190], [-140, -480, 120], [180, -470, 120], [30, -820, 120]];
    for (const [pass, col, dx, dy, k] of [[0, dark, 0, 18, 1.02], [1, mid, 0, 0, .98], [2, lite, -26, -30, .66]]) blobs.forEach(([bx, by, r], i) => { const w = Math.sin(t * 1.3 + i * 1.7) * 5 * s + sway * (by < -560 ? 1 : .5); g.fillStyle = col; g.beginPath(); g.arc(bx + dx + w, by + dy, r * k, 0, 7); g.fill(); });
    for (let i = 0; i < 26; i++) { const a = hash(i, 4) * 6.28, rr = hash(i, 5) * 260, lx = Math.cos(a) * rr + 20 + sway, ly = -640 + Math.sin(a) * rr * .6; g.fillStyle = i % 2 ? '#a8ec7e' : '#2f8a38'; g.beginPath(); g.ellipse(lx, ly, 14, 8, a, 0, 7); g.fill(); }
    g.restore();
  };
  // "esqueleto de blobs": segmentos grossos desenhados em 2 passadas (contorno e preenchimento) => silhueta unida sem linhas internas
  const blobs2 = (g, segs, ink = '#1b2a3a', lw = 8) => { g.save(); g.lineCap = 'round'; g.lineJoin = 'round'; for (const pass of [0, 1]) for (const sg of segs) { g.strokeStyle = pass ? sg.c : ink; g.lineWidth = pass ? sg.w : sg.w + lw * 2; g.beginPath(); sg.p.forEach((q, i) => (i ? g.lineTo(q[0], q[1]) : g.moveTo(q[0], q[1]))); if (sg.p.length === 1) g.lineTo(sg.p[0][0] + .01, sg.p[0][1]); g.stroke(); } g.restore(); };
  // mão com palma, polegar e 3 dedos apontando na direção ang (rad). Retorna segmentos p/ blobs2.
  const handSegs = (x, y, ang, s = 1, c = '#ffffff', curl = 0) => { const rot = (dx, dy) => [x + (dx * Math.cos(ang) - dy * Math.sin(ang)) * s, y + (dx * Math.sin(ang) + dy * Math.cos(ang)) * s]; const f = (dy, len) => ({ p: [rot(10, dy), rot(10 + len * (1 - curl * .5), dy + curl * 10)], w: 10 * s, c }); return [{ p: [rot(0, 0)], w: 30 * s, c }, f(-9, 22), f(0, 25), f(9, 21), { p: [rot(-2, -12), rot(12, -22)], w: 10 * s, c }]; };
  const footSegs = (x, y, c = '#d9402f') => [{ p: [[x - 10, y - 14], [x + 26, y - 6]], w: 34, c }, { p: [[x - 8, y + 8], [x + 36, y + 8]], w: 11, c: '#f3efe6' }];
  // cabeça da bolinha: bola branca com sombra, boné (gomos+botão+aba), olhos que piscam, bochechas, boca (smile|o|talk)
  const ballHead = (g, o = {}) => {
    const { cap = '#15171c', ink = '#111318', look = 0, up = 0, bl = 1, tilt = 0, mouth = 'smile', talk = 0 } = o;
    g.save(); g.rotate(tilt); g.beginPath(); g.arc(0, 0, 84, 0, 7); fillStroke(g, '#ffffff', ink, 9);
    g.save(); g.beginPath(); g.arc(0, 0, 80, 0, 7); g.clip(); g.fillStyle = 'rgba(110,120,140,.30)'; g.beginPath(); g.arc(-34, -28, 112, 0, 7); g.arc(0, 0, 90, 0, 7); g.fill('evenodd'); g.restore();
    g.beginPath(); g.arc(0, -20, 82, Math.PI * 1.05, Math.PI * 1.95); g.lineTo(62, -34); g.closePath(); fillStroke(g, cap, ink, 9);
    g.strokeStyle = 'rgba(255,255,255,.22)'; g.lineWidth = 5; g.beginPath(); g.moveTo(0, -102); g.quadraticCurveTo(-26, -70, -34, -34); g.stroke(); g.beginPath(); g.moveTo(0, -102); g.quadraticCurveTo(30, -70, 38, -36); g.stroke();
    g.beginPath(); g.arc(0, -102, 9, 0, 7); fillStroke(g, '#ffffff', ink, 5);
    g.beginPath(); g.moveTo(24, -50); g.quadraticCurveTo(112, -62, 130, -34); g.quadraticCurveTo(84, -24, 40, -32); g.closePath(); fillStroke(g, '#2a2d36', ink, 8);
    g.fillStyle = ink; for (const ex of [-24, 30]) { g.beginPath(); g.ellipse(ex + look * 8, 16 - up * 6, 7, 9 * bl + .8, 0, 0, 7); g.fill(); g.fillStyle = '#fff'; g.beginPath(); g.arc(ex + look * 8 + 2, 13 - up * 6, 2.2, 0, 7); g.fill(); g.fillStyle = ink; }
    g.fillStyle = 'rgba(120,130,150,.35)'; for (const ex of [-46, 54]) { g.beginPath(); g.ellipse(ex, 34, 12, 7, 0, 0, 7); g.fill(); }
    g.strokeStyle = ink; g.lineWidth = 7; g.lineCap = 'round';
    if (mouth === 'o' || talk > .05) { const r = mouth === 'o' ? 10 : 4 + talk * 12; g.beginPath(); g.ellipse(12 + look * 6, 48, 10, r, 0, 0, 7); g.fillStyle = ink; g.fill(); }
    else { g.beginPath(); g.moveTo(-2 + look * 6, 46); g.quadraticCurveTo(12 + look * 6, 56, 26 + look * 6, 44); g.stroke(); }
    g.restore();
  };
  // personagem bolinha COMPLETO, preto e branco (original). pose:'sit' | 'walk' (andando; walk:0 = parado em pé). Pés em (x,y).
  // opções: x,y,s,t,flip, cap,shirt,shorts,shoe, look,up,wave,talk,mouth,tilt, ph (fase do passo), walk (0..1 velocidade)
  const ballGuy = (g, o = {}) => {
    const { x = 0, y = 0, s = 1, t = 0, pose = 'sit', cap = '#15171c', shirt = '#15171c', shorts = '#4a4f5c', shoe = '#15171c', look = 0, up = 0, wave = 0, talk = 0, mouth = 'smile', tilt = 0, flip = false } = o, ink = '#111318', W = '#ffffff';
    const br = Math.sin(t * 2) * 2.2, bl = (t % 3.4) > 3.28 ? .1 : 1, wv = Math.sin(t * 7) * .45, sole = '#f3f3f3';
    const shoeS = (px, py) => [{ p: [[px - 10, py - 14], [px + 26, py - 6]], w: 34, c: shoe }, { p: [[px - 8, py + 8], [px + 36, py + 8]], w: 11, c: sole }];
    g.save(); g.translate(x, y); g.scale(flip ? -s : s, s); const sh = (...a) => { if (o.shadow !== false) shadow(g, ...a); };
    if (pose === 'walk') {
      const wk = o.walk === undefined ? 1 : o.walk, ph = o.ph === undefined ? t * 8 : o.ph, by = -Math.abs(Math.sin(ph)) * 8 * wk + br * .6, hipY = -172 + by;
      sh(0, 4, 90, 16, .22);
      const leg = (k) => { const p = ph + k * Math.PI, ax = (k ? -14 : 14) * (1 - wk) + Math.sin(p) * 62 * wk, ay = -Math.max(0, Math.cos(p)) * 36 * wk; return [{ p: [[0, hipY], [ax * .5 + 16, (hipY + ay) * .5 + 6], [ax, ay - 14]], w: 34, c: W }, ...shoeS(ax + 4, ay)]; };
      blobs2(g, leg(1), ink, 8);
      const sy = -290 + by, arm = (k) => { const a = (Math.sin(ph + (k ? 0 : Math.PI)) * .85 * wk) + (k ? .06 : -.06) + Math.sin(t * 2 + k) * .04, ex = Math.sin(a) * 42, ey = Math.cos(a) * 42, hx = Math.sin(a * 1.25) * 80, hy = Math.cos(a * 1.25) * 76; return [{ p: [[0, sy], [ex, sy + ey], [hx, sy + hy]], w: 26, c: W }, ...handSegs(hx, sy + hy + 4, Math.PI / 2 - a * .7, .9, W, .35)]; };
      blobs2(g, arm(1), ink, 8); blobs2(g, leg(0), ink, 8);
      g.save(); rr(g, -46, -300 + by, 92, 138, 34); fillStroke(g, shirt, ink, 8); g.fillStyle = 'rgba(255,255,255,.9)'; rr(g, -46, -246 + by, 92, 10, 2); g.fill(); rr(g, -48, -178 + by, 96, 46, 16); fillStroke(g, shorts, ink, 8); g.restore();
      g.save(); g.translate(2, -372 + by); ballHead(g, { cap, look: look + .5, up, bl, tilt: tilt + Math.sin(ph) * .03 * wk, mouth, talk }); g.restore();
      if (wave) blobs2(g, [{ p: [[0, sy], [70, sy - 30], [96 + wv * 22, sy - 110]], w: 26, c: W }, ...handSegs(96 + wv * 22, sy - 118, -1.5 + wv, .95, W, .1)], ink, 8); else blobs2(g, arm(0), ink, 8);
      g.restore(); return;
    }
    sh(70, 6, 190, 24, .22);
    blobs2(g, [{ p: [[0, -18], [95, -22], [170, -14]], w: 34, c: W }, ...shoeS(178, -4).slice(0, 2)], ink, 8);
    blobs2(g, [{ p: [[-34, -112 + br], [-78, -62], [-84, -14]], w: 26, c: W }, ...handSegs(-84, -8, 1.9, .9)], ink, 8);
    blobs2(g, [{ p: [[14, -22], [88, -96], [150, -10]], w: 36, c: W }, ...shoeS(158, -2)], ink, 8);
    g.save(); g.translate(0, br * .5); rr(g, -50, -140, 100, 122, 34); fillStroke(g, shirt, ink, 8); g.fillStyle = 'rgba(255,255,255,.9)'; rr(g, -50, -92, 100, 10, 2); g.fill();
    rr(g, -52, -44, 104, 44, 16); fillStroke(g, shorts, ink, 8); g.restore();
    g.save(); g.translate(0, -214 + br); ballHead(g, { cap, look, up, bl, tilt, mouth, talk }); g.restore();
    if (wave) blobs2(g, [{ p: [[36, -112 + br], [116, -140], [150 + wv * 26, -214]], w: 26, c: W }, ...handSegs(150 + wv * 26, -224, -1.5 + wv, .95, W, .1)], ink, 8);
    else blobs2(g, [{ p: [[36, -112 + br], [84, -70], [92, -96]], w: 26, c: W }, ...handSegs(94, -104, -.5, .9, W, .35)], ink, 8);
    g.restore();
  };
  const lampLP = (g, P, x, y, t, h = 2.3) => { const b = P(x, y, 0), tp = P(x, y, h); g.strokeStyle = '#1c2a4a'; g.lineWidth = 8; g.lineCap = 'round'; g.beginPath(); g.moveTo(b[0], b[1]); g.lineTo(tp[0], tp[1]); g.stroke(); const gl = g.createRadialGradient(tp[0], tp[1], 2, tp[0], tp[1], 70); gl.addColorStop(0, 'rgba(255,240,170,.9)'); gl.addColorStop(1, 'rgba(255,240,170,0)'); g.fillStyle = gl; g.beginPath(); g.arc(tp[0], tp[1], 70, 0, 7); g.fill(); g.fillStyle = '#fff6c2'; g.beginPath(); g.arc(tp[0], tp[1], 11, 0, 7); fillStroke(g, '#fff6c2', '#1c2a4a', 4); };
  // partículas deterministas (folhas/poeira/pétalas) descendo e balançando
  const drift = (g, W, H, t, n = 14, cols = ['#a8ec7e', '#7bd56a', '#f6e27a'], size = 12) => { for (let i = 0; i < n; i++) { const sp = 40 + hash(i, 1) * 70, y = ((hash(i, 2) * (H + 200) + t * sp) % (H + 200)) - 100, x = hash(i, 3) * W + Math.sin(t * 1.2 + i) * 60, a = t * (1 + hash(i, 4) * 2) + i; g.fillStyle = cols[i % cols.length]; g.beginPath(); g.ellipse(x, y, size, size * .5, a, 0, 7); g.fill(); } };
  // raios de sol suaves a partir de (sx,sy)
  const rays = (g, W, H, sx, sy, t, a = .12) => { g.save(); g.globalCompositeOperation = 'lighter'; for (let i = 0; i < 6; i++) { const ang = .55 + i * .16 + Math.sin(t * .4 + i) * .02; g.fillStyle = `rgba(255,244,190,${a * (.6 + .4 * Math.sin(t * .8 + i))})`; g.beginPath(); g.moveTo(sx, sy); g.lineTo(sx + Math.cos(ang - .04) * H * 1.6, sy + Math.sin(ang - .04) * H * 1.6); g.lineTo(sx + Math.cos(ang + .04) * H * 1.6, sy + Math.sin(ang + .04) * H * 1.6); g.fill(); } g.restore(); };
  // aplica um plano vertical da caixa isométrica (face y=const): desenhe em coords de 100 por unidade, y negativo = para cima
  const faceY = (g, P, x, y) => { const o = P(x, y, 0), ax = P(x + 1, y, 0), az = P(x, y, 1); g.transform((ax[0] - o[0]) / 100, (ax[1] - o[1]) / 100, (o[0] - az[0]) / 100, (o[1] - az[1]) / 100, o[0], o[1]); };
  // etiqueta de preço que "pula" com mola
  const priceTag = (g, x, y, text, t, col = '#1fa84f', o = {}) => { const k = spring(t - (o.t0 || 0)); if (k < .02) return; g.save(); g.translate(x, y + Math.sin(t * 3) * 4); g.rotate((o.rot || -.06)); g.scale(k, k); g.font = `900 ${o.size || 64}px "Archivo Black","Anton","Impact","DejaVu Sans",sans-serif`; const w = g.measureText(text).width + 70, h = (o.size || 64) + 40; g.fillStyle = 'rgba(0,0,0,.22)'; rr(g, -w / 2 + 6, -h / 2 + 10, w, h, 22); g.fill(); rr(g, -w / 2, -h / 2, w, h, 22); fillStroke(g, col, '#ffffff', 8); g.fillStyle = '#fff'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(text, 0, 4); g.restore(); };

  /* ---------- v5: câmera por keyframes + micro-detalhes ---------- */
  // keys: [{t,x,y,z}] foco em coords do canvas e zoom; interpola suave entre keyframes. Chame g.save() antes e g.restore() depois.
  const camKeys = (g, W, H, t, keys) => { let a = keys[0], b = keys[0]; for (let i = 0; i < keys.length; i++) { if (t >= keys[i].t) { a = keys[i]; b = keys[Math.min(i + 1, keys.length - 1)]; } } const f = a === b ? 0 : ease.smooth((t - a.t) / (b.t - a.t)); const x = lerp(a.x, b.x, f), y = lerp(a.y, b.y, f), z = lerp(a.z, b.z, f); g.translate(W / 2, H / 2); g.scale(z, z); g.translate(-x, -y); };
  // plano vertical x=const da caixa iso (parede da esquerda / face direita): desenhe em 100 por unidade, y negativo = cima
  const faceX = (g, P, x, y) => { const o = P(x, y, 0), ay = P(x, y + 1, 0), az = P(x, y, 1); g.transform((ay[0] - o[0]) / 100, (ay[1] - o[1]) / 100, (o[0] - az[0]) / 100, (o[1] - az[1]) / 100, o[0], o[1]); };
  // nuvenzinha de poeira (age em segundos desde o impacto)
  const puff = (g, x, y, age, s = 1) => { if (age < 0 || age > .7) return; const k = age / .7; g.save(); g.globalAlpha = (1 - k) * .6; g.fillStyle = '#f4f1e6'; for (let i = 0; i < 5; i++) { const a = -Math.PI * (.1 + i * .2); g.beginPath(); g.arc(x + Math.cos(a) * 34 * k * s * (1 + i % 2 * .3), y + Math.sin(a) * 18 * k * s, (8 + 10 * k) * s, 0, 7); g.fill(); } g.restore(); };
  const flower = (g, x, y, s, t, col = '#ff6f91') => { const sw = Math.sin(t * 2 + x * .05) * 6 * s; g.save(); g.strokeStyle = '#2f8a38'; g.lineWidth = 4 * s; g.lineCap = 'round'; g.beginPath(); g.moveTo(x, y); g.quadraticCurveTo(x + sw * .4, y - 20 * s, x + sw, y - 38 * s); g.stroke(); g.fillStyle = col; for (let i = 0; i < 5; i++) { const a = i * 1.2566; g.beginPath(); g.arc(x + sw + Math.cos(a) * 8 * s, y - 38 * s + Math.sin(a) * 8 * s, 6.5 * s, 0, 7); g.fill(); } g.fillStyle = '#ffe14a'; g.beginPath(); g.arc(x + sw, y - 38 * s, 5 * s, 0, 7); g.fill(); g.restore(); };
  const butterfly = (g, x, y, t, col = '#ff9f1c', s = 1) => { const f = Math.abs(Math.sin(t * 16)); g.save(); g.translate(x, y); g.rotate(Math.sin(t * 3) * .3); g.scale(s, s); g.fillStyle = col; for (const sg of [-1, 1]) { g.beginPath(); g.ellipse(sg * 9 * f, -5, 10 * f + 2, 13, sg * .4, 0, 7); g.fill(); g.beginPath(); g.ellipse(sg * 7 * f, 8, 7 * f + 1, 9, -sg * .4, 0, 7); g.fill(); } g.fillStyle = '#2a2230'; g.beginPath(); g.ellipse(0, 0, 3, 11, 0, 0, 7); g.fill(); g.restore(); };
  const bird = (g, x, y, t, col = '#3b6fd8', s = 1, fly = 0) => { const w = fly ? Math.sin(t * 22) * 16 : 0; g.save(); g.translate(x, y); g.scale(s, s); g.fillStyle = col; g.beginPath(); g.ellipse(0, 0, 20, 14, 0, 0, 7); g.fill(); g.beginPath(); g.arc(17, -8, 10, 0, 7); g.fill(); g.fillStyle = '#ffb02e'; g.beginPath(); g.moveTo(26, -9); g.lineTo(38, -6); g.lineTo(26, -3); g.fill(); g.fillStyle = '#fff'; g.beginPath(); g.arc(20, -10, 2.5, 0, 7); g.fill(); g.fillStyle = mixc(col, '#000000', .2); g.beginPath(); g.moveTo(-8, 0); g.quadraticCurveTo(-2, -22 - w, 14, -4 - w * .4); g.quadraticCurveTo(2, 8, -8, 0); g.fill(); g.beginPath(); g.moveTo(-18, -2); g.lineTo(-36, -8 + w * .3); g.lineTo(-18, 6); g.fill(); g.restore(); };
  const sparkle = (g, x, y, r, a = 0, col = '#fff6a8') => { g.save(); g.translate(x, y); g.rotate(a); g.fillStyle = col; g.beginPath(); for (let j = 0; j < 8; j++) { const rr2 = j % 2 ? r * .25 : r; g.lineTo(Math.cos(j * .785) * rr2, Math.sin(j * .785) * rr2); } g.closePath(); g.fill(); g.restore(); };
  // interpolação por pontos de caminho: pts=[{t,x,y}] → {x,y,vx,vy,moving}
  const path = (pts, t) => { let i = 0; while (i < pts.length - 2 && t > pts[i + 1].t) i++; const a = pts[i], b = pts[i + 1], k = clamp((t - a.t) / (b.t - a.t)), kk = ease.inOut(k) * .35 + k * .65; return { x: lerp(a.x, b.x, kk), y: lerp(a.y, b.y, kk), moving: t > a.t && t < b.t && (a.x !== b.x || a.y !== b.y), dx: b.x - a.x, dy: b.y - a.y }; };

  // --- estúdio: movimento de cinema (funções puras do tempo) ---
  const springU = spring;                                              // alias: mola fechada, sem estado
  const wobble = (t, amp = .12, f = 9, d = 7) => t <= 0 ? 0 : amp * Math.exp(-d * t) * Math.sin(2 * Math.PI * f * t);   // esmaga-e-assenta (squash & settle)
  const shake = (t, t0, dur = .35, amp = 14, seed = 1) => { const u = (t - t0) / dur; if (u < 0 || u > 1) return [0, 0]; const k = (1 - u) * (1 - u) * amp; return [(hash(seed, Math.floor(t * 60)) - .5) * 2 * k, (hash(seed + 7, Math.floor(t * 60)) - .5) * 2 * k]; };  // tremor de impacto
  const zoomLog = (a, b, p) => a * Math.pow(b / a, clamp(p));          // zoom em espaço log = dolly constante (não "demora grande")
  const kf = (t, keys, e = ease.inOut) => { if (t <= keys[0][0]) return keys[0][1]; for (let i = 1; i < keys.length; i++) if (t <= keys[i][0]) { const [t0, v0] = keys[i - 1], [t1, v1] = keys[i]; return v0 + (v1 - v0) * e((t - t0) / (t1 - t0)); } return keys[keys.length - 1][1]; };  // chaves com easing
  // --- acabamento de cinema (vira o último passo do seek): bloom suave, vinheta, grade quente/fria, grão de filme determinístico ---
  const finish = (g, W, H, t, o = {}) => {
    const v = o.vignette ?? .28, gr = o.grain ?? .022, bl = o.bloom ?? .16, gd = o.grade ?? .10;
    g.save(); g.setTransform(1, 0, 0, 1, 0, 0);
    if (bl > 0 && 'filter' in g) { g.globalCompositeOperation = 'soft-light'; g.globalAlpha = bl; g.filter = `blur(${Math.round(W / 60)}px) saturate(1.25)`; g.drawImage(g.canvas, 0, 0); g.filter = 'none'; g.globalAlpha = 1; }
    if (gd > 0) { g.globalCompositeOperation = 'soft-light'; const q = g.createLinearGradient(0, 0, 0, H); q.addColorStop(0, `rgba(255,214,150,${gd})`); q.addColorStop(1, `rgba(90,130,255,${gd * .8})`); g.fillStyle = q; g.fillRect(0, 0, W, H); }
    g.globalCompositeOperation = 'source-over';
    if (v > 0) { const r = g.createRadialGradient(W / 2, H * .46, Math.min(W, H) * .35, W / 2, H / 2, Math.max(W, H) * .78); r.addColorStop(0, 'rgba(0,0,0,0)'); r.addColorStop(1, `rgba(12,10,30,${v})`); g.fillStyle = r; g.fillRect(0, 0, W, H); }
    if (gr > 0) { const f = Math.floor(t * 24), n = Math.round(W * H / 1800), sz = Math.max(2, Math.round(W / 540)); for (let i = 0; i < n; i++) { const x = hash(i, f * 3) * W, y = hash(i, f * 3 + 1) * H; g.fillStyle = hash(i, f * 3 + 2) > .5 ? `rgba(255,255,255,${gr})` : `rgba(0,0,0,${gr})`; g.fillRect(x, y, sz, sz); } }
    g.restore();
  };
  return { finish, springU, wobble, shake, zoomLog, kf, camKeys, faceX, puff, flower, butterfly, bird, sparkle, path, ballHead, lampLP, blobs2, handSegs, footSegs, hill, tuft, field, bigTree, ballGuy, drift, rays, faceY, priceTag, clamp, lerp, mixc, ease, spring, hash, tri, rr, fillStroke, poly, shadow, cam, person, mouth, visemeFrom, iso, box, roof, treeLP, cloudLP, roadH, grass, sky, dots, captions, title, wordsFromText, envAt };
})();
if (typeof window !== 'undefined') window.L = L;
