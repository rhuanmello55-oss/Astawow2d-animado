const CONFIG = { w: 1080, h: 1920, fps: 30, dur: 10 };
// window.WORDS vem do words.js gerado por audio/mix.py (legenda = fala)
function draw(g, t, W, H) {
  g.save(); L.cam(g, W, H, t, { zoom: 1.02 + .07 * L.clamp(t / 10), drift: .008, px: 18 - 36 * L.clamp(t / 10) });
  shopScene(g, t, W, H, SHOP_BLUE);
  g.restore();
  L.title(g, W, 'VISITE HOJE!', 305, t - 7.4, { t0: 0, size: 64, bg: '#e8452c' });
  L.captions(g, W, H, WORDS, t, { y: H * .76, size: 92, group: 2 });
}
