const CONFIG = { w: 1080, h: 1920, fps: 30, dur: 10 };
// window.WORDS vem do words.js gerado por audio/mix.py (legenda = fala)
function draw(g, t, W, H) {
  const P = MARKET_P, a = P(3.4, 2.6, 1), b = P(5.2, 1.9, 1), c = P(6.4, 4.0, 1);
  g.save();
  L.camKeys(g, W, H, t, [{ t: 0, x: 540, y: 940, z: 1.12 }, { t: 1.3, x: 540, y: 940, z: 1.15 }, { t: 2.0, x: a[0] + 30, y: a[1] + 90, z: 1.45 }, { t: 4.3, x: b[0] + 35, y: b[1] + 110, z: 1.42 }, { t: 5.6, x: b[0] + 40, y: b[1] + 150, z: 1.4 }, { t: 6.3, x: c[0] - 40, y: c[1] + 82, z: 1.55 }, { t: 8.3, x: c[0] - 60, y: c[1] + 96, z: 1.55 }, { t: 9.3, x: 540, y: 940, z: 1.12 }, { t: 10, x: 540, y: 940, z: 1.18 }]);
  marketScene(g, t, W, H, MARKET_BLUE);
  g.restore();
  if (t < 2.2) L.title(g, W, 'POR DENTRO DO MERCADINHO', 190, t, { t0: .2, size: 44, bg: '#1f5fd0' });
  if (t > 8.9) L.title(g, W, 'VENHA CONFERIR!', 190, t - 8.9, { t0: 0, size: 60, bg: '#e8452c' });
  L.captions(g, W, H, WORDS, t, { y: H * .82, size: 92, group: 2 });
}
