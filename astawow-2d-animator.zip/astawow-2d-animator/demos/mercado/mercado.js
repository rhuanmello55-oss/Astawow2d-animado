/* mercado.js — INTERIOR de mercado em corte isométrico: prateleiras, caixa com esteira, carrinho, cliente pegando produtos,
   itens voando da prateleira pro carrinho e pra esteira, BIP + total, placas das seções. Tudo função pura de t (0–10 s).
   Uso:  marketScene(g, t, W, H, MARKET_BLUE)   (use L.camKeys por fora para os zooms) */
const MARKET_BLUE = { bg: ['#bfe0fb', '#eef7ff'], wall: '#f3f8ff', wall2: '#e4eefb', floor: ['#e8f1fb', '#c9dcf2'], slab: '#9fb6d6', shelf: '#dfe8f5', counter: '#2f6fd1', accent: '#1f5fd0', accent2: '#12306b', money: '#1fa84f', total: 'R$ 24,90' };
const MARKET_P = L.iso(551, 850, 82);
function marketScene(g, t, W, H, C) {
  const P = MARKET_P, font = (px) => `900 ${px}px "Archivo Black","Anton","Impact","DejaVu Sans",sans-serif`;
  const bgG = g.createLinearGradient(0, 0, 0, H); bgG.addColorStop(0, C.bg[0]); bgG.addColorStop(1, C.bg[1]); g.fillStyle = bgG; g.fillRect(-W, -H, W * 3, H * 3);
  const rise = L.spring(t - .08), ready = rise > .95;
  // ---------- piso e paredes ----------
  L.box(g, P, 0, 0, 0, 8, 6, .2 * rise, C.slab);
  if (ready) for (let i = 0; i < 8; i++) for (let j = 0; j < 6; j++) L.poly(g, [P(i, j, .2), P(i + 1, j, .2), P(i + 1, j + 1, .2), P(i, j + 1, .2)], C.floor[(i + j) % 2]);
  L.box(g, P, 0, 0, .2, 8, .2, 3.0 * rise, C.wall); L.box(g, P, 0, 0, .2, .2, 6, 3.0 * rise, C.wall2);
  const ing = (r) => 1; void ing;
  // ---------- produtos ----------
  const prod = (kind, col, s = 1) => { g.save(); g.scale(s, s); if (kind === 'apple' || kind === 'orange') { g.beginPath(); g.arc(0, -15, 15, 0, 7); L.fillStroke(g, kind === 'apple' ? '#e63946' : '#ff9f1c', '#00000033', 3); g.fillStyle = 'rgba(255,255,255,.45)'; g.beginPath(); g.arc(-5, -20, 4, 0, 7); g.fill(); g.fillStyle = '#2f8a38'; g.fillRect(-1, -32, 3, 7); }
    else if (kind === 'bottle') { L.rr(g, -9, -52, 18, 52, 6); L.fillStroke(g, col, '#00000033', 3); g.fillStyle = '#fff'; g.fillRect(-5, -60, 10, 10); g.fillStyle = 'rgba(255,255,255,.5)'; g.fillRect(-5, -40, 4, 26); }
    else { g.beginPath(); g.ellipse(0, -12, 20, 11, -.15, 0, 7); L.fillStroke(g, '#e0a458', '#00000033', 3); g.strokeStyle = '#b97a34'; g.lineWidth = 3; for (const x of [-8, 0, 8]) { g.beginPath(); g.moveTo(x - 3, -17); g.lineTo(x + 2, -8); g.stroke(); } } g.restore(); };
  const BCOL = ['#3a8de0', '#ffb703', '#2ec4b6', '#e63946'];
  const PICK = [{ sh: 'C', r: 1, i: 1, t: 2.1, kind: 'bread' }, { sh: 'C', r: 1, i: 3, t: 2.45, kind: 'bread' }, { sh: 'A', r: 1, i: 2, t: 3.4, kind: 'apple' }, { sh: 'A', r: 0, i: 4, t: 3.75, kind: 'orange' }, { sh: 'B', r: 1, i: 2, t: 4.9, kind: 'bottle', col: '#3a8de0' }, { sh: 'B', r: 1, i: 4, t: 5.25, kind: 'bottle', col: '#ffb703' }];
  const itemWorld = (o, xd, zb) => (o.ori === 'Y' ? P(o.x + xd / 100, o.y + o.d, zb + .05) : P(o.x + o.w, o.y + xd / 100, zb + .05));
  const shelf = (o) => {
    L.box(g, P, o.x, o.y, .2, o.w, o.d, o.h, C.shelf); if (!ready) return;
    g.save(); const len = o.ori === 'Y' ? o.w * 100 : o.d * 100; if (o.ori === 'Y') L.faceY(g, P, o.x, o.y + o.d); else L.faceX(g, P, o.x + o.w, o.y);
    for (let r = 0; r < 3; r++) { const zb = .2 + .3 + r * .52, n = Math.floor((len - 20) / 38); g.fillStyle = '#b9c9e0'; g.fillRect(6, -zb * 100, len - 12, 7); g.fillStyle = 'rgba(0,0,0,.08)'; g.fillRect(6, -zb * 100 - 78, len - 12, 78);
      for (let i = 0; i < n; i++) { const xd = 28 + i * 38, taken = PICK.find((p) => p.sh === o.id && p.r === r && p.i === i && t >= p.t); if (taken) continue; g.save(); g.translate(xd, -zb * 100);
        if (o.id === 'A') prod(r === 0 ? 'orange' : 'apple'); else if (o.id === 'B') prod('bottle', BCOL[(i + r) % 4]); else prod('bread'); g.restore(); } }
    g.restore();
  };
  const SA = { id: 'A', ori: 'Y', x: 1.15, y: .45, w: 2.3, d: .7, h: 1.9 }, SB = { id: 'B', ori: 'Y', x: 4.3, y: .45, w: 2.3, d: .7, h: 1.9 }, SC = { id: 'C', ori: 'X', x: .45, y: 1.3, w: .7, d: 2.7, h: 1.9 };
  shelf(SA); shelf(SB); shelf(SC);
  // decoração das paredes
  if (ready) {
    g.save(); L.faceY(g, P, 0, .2); g.translate(0, 0);
    g.fillStyle = C.accent; L.rr(g, 355, -300, 110, 150, 10); g.fill(); g.fillStyle = '#ffd23f'; g.font = font(28); g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('OFERTA', 410, -262); g.font = font(40); g.fillStyle = '#fff'; g.fillText('-30%', 410, -212); g.font = font(18); g.fillText('HOJE!', 410, -172);
    g.strokeStyle = C.accent2; g.lineWidth = 6; g.fillStyle = '#fff'; g.beginPath(); g.arc(740, -250, 36, 0, 7); g.fill(); g.stroke(); const ch = t * .6; g.lineWidth = 5; g.lineCap = 'round'; g.beginPath(); g.moveTo(740, -250); g.lineTo(740 + Math.sin(ch) * 24, -250 - Math.cos(ch) * 24); g.stroke(); g.beginPath(); g.moveTo(740, -250); g.lineTo(740 + Math.sin(ch / 12) * 16, -250 - Math.cos(ch / 12) * 16); g.stroke();
    g.fillStyle = C.accent2; g.fillRect(0, -26, 800, 16); g.restore();
  }
  // placas das seções (pulam quando a câmera chega)
  const sign = (txt, o, t0) => { const q = P(o.x + (o.ori === 'Y' ? o.w / 2 : o.w), o.y + (o.ori === 'Y' ? o.d : o.d / 2), o.h + 1.35); L.priceTag(g, q[0], q[1], txt, t, C.accent, { t0, size: 34, rot: 0 }); };
  // ---------- ilha de ofertas ----------
  const customerBefore = [], customerAfter = [];
  const island = () => { L.box(g, P, 3.0, 2.7, .2, 1.7, 1.0, .5, '#f6d58e'); L.box(g, P, 3.05, 2.75, .7, 1.6, .9, .06, '#fff3cf'); for (let i = 0; i < 12; i++) { const q = P(3.25 + (i % 4) * .4, 2.95 + Math.floor(i / 4) * .3, .85); g.fillStyle = i % 3 ? '#ff9f1c' : '#e63946'; g.beginPath(); g.arc(q[0], q[1], 12, 0, 7); g.fill(); g.fillStyle = 'rgba(255,255,255,.4)'; g.beginPath(); g.arc(q[0] - 4, q[1] - 4, 3.5, 0, 7); g.fill(); } };
  // ---------- pessoas ----------
  const PATH = [{ t: 0, x: 1.7, y: 7.0 }, { t: .6, x: 1.7, y: 6.6 }, { t: 1.9, x: 1.9, y: 2.7 }, { t: 2.6, x: 1.9, y: 2.7 }, { t: 3.1, x: 2.3, y: 1.9 }, { t: 3.9, x: 2.3, y: 1.9 }, { t: 4.5, x: 5.2, y: 1.9 }, { t: 5.4, x: 5.2, y: 1.9 }, { t: 6.2, x: 6.2, y: 5.0 }, { t: 8.2, x: 6.2, y: 5.0 }, { t: 9.6, x: 6.2, y: 7.2 }, { t: 10.5, x: 6.2, y: 7.4 }];
  const me = L.path(PATH, t), mflip = (me.dx - me.dy) < 0, mWalk = me.moving ? 1 : 0, hasBag = t > 8.2;
  const cart = (cx, cy) => { const cp = [cx + .35, cy + .35]; L.box(g, P, cp[0], cp[1], .45, .8, .55, .3, '#c7d3e6'); L.box(g, P, cp[0] + .03, cp[1] + .03, .75, .74, .49, .03, '#9fb0cc'); for (const [wx, wy] of [[0, 0], [.7, .45]]) { const q = P(cp[0] + wx, cp[1] + wy + .05, .3); g.fillStyle = '#222a3a'; g.beginPath(); g.arc(q[0], q[1], 7, 0, 7); g.fill(); }
    const inCart = PICK.filter((p) => t >= p.t + .55 && t < 6.5); inCart.forEach((p, k) => { const q = P(cp[0] + .15 + (k % 3) * .22, cp[1] + .15 + Math.floor(k / 3) * .25, .8); g.save(); g.translate(q[0], q[1] + 6); prod(p.kind, p.col, .55); g.restore(); }); };
  const meDraw = () => { const sh = hasBag ? undefined : undefined; void sh; const q = P(me.x, me.y, .2); L.shadow(g, q[0], q[1] + 4, 34, 8, .2);
    L.person(g, { x: q[0], y: q[1], s: .4, t, flip: mflip, pose: mWalk ? 'walk' : 'idle', shirt: '#e8704a', pants: '#2c3550', skin: '#f2c6a0', hair: '#1c1412', hairStyle: 'short', mouth: 'smile', brow: .3, walkSpeed: 7, armL: mWalk ? undefined : .12,
      prop: hasBag ? (h) => { h.fillStyle = '#ffc93c'; L.rr(h, -14, -8, 36, 46, 6); L.fillStroke(h, '#ffc93c', C.accent2, 5); h.beginPath(); h.arc(4, -8, 11, Math.PI, 0); h.strokeStyle = C.accent2; h.lineWidth = 5; h.stroke(); } : undefined });
    if (!hasBag && t < 8.2) cart(me.x, me.y); };
  if (me.y < 2.5) meDraw();
  // cliente de fundo olhando a ilha
  const bx = 3.2 + Math.sin(t * .7) * .8, bq = P(bx, 2.2, .2), bflip = Math.cos(t * .7) < 0; L.shadow(g, bq[0], bq[1] + 4, 30, 7, .18); L.person(g, { x: bq[0], y: bq[1], s: .38, t, flip: bflip, pose: 'walk', walkSpeed: 4, shirt: '#8a5fd0', pants: '#3a3f55', skin: '#8a5a3c', hair: '#1c1412', hairStyle: 'bun', mouth: 'smile' });
  island();
  // ---------- caixa ----------
  const CQ = P(6.6, 3.1, .2); L.shadow(g, CQ[0], CQ[1] + 4, 34, 8, .2);
  const scanning = [0, 1, 2, 3, 4, 5].some((k) => Math.abs(t - (7.05 + k * .22)) < .1);
  L.person(g, { x: CQ[0], y: CQ[1], s: .4, t, flip: false, pose: 'idle', shirt: C.accent, pants: '#26304a', skin: '#f2c6a0', hair: '#5a3a22', hairStyle: 'bun', mouth: 'smile', blush: true, armR: scanning ? 1.0 + Math.sin(t * 40) * .15 : .5, armL: .2 });
  L.box(g, P, 5.2, 3.7, .2, 2.6, .9, .95, C.counter);
  if (ready) { g.save(); L.faceY(g, P, 5.2, 4.6); g.fillStyle = '#ffffff'; g.font = font(30); g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('CAIXA 1', 130, -62); g.fillStyle = 'rgba(255,255,255,.25)'; g.fillRect(250, -90, 6, 70); g.restore(); }
  L.box(g, P, 5.3, 3.8, 1.15, 1.6, .7, .05, '#2a2f3a');
  for (let i = 0; i < 9; i++) { const x0 = 5.3 + ((i * .2 + t * .6) % 1.6), a = P(x0, 3.85, 1.2), b = P(x0, 4.45, 1.2); g.strokeStyle = 'rgba(255,255,255,.12)'; g.lineWidth = 3; g.beginPath(); g.moveTo(a[0], a[1]); g.lineTo(b[0], b[1]); g.stroke(); }
  L.box(g, P, 7.0, 3.85, 1.15, .6, .6, .4, '#3a4256'); const RG = P(7.3, 4.15, 1.62);
  g.save(); g.translate(RG[0], RG[1]); L.rr(g, -18, -12, 36, 22, 4); L.fillStroke(g, '#10261c', '#00000055', 2); g.fillStyle = '#7dffb0'; g.font = '800 14px "DejaVu Sans",monospace'; g.textAlign = 'center'; g.textBaseline = 'middle';
  const amts = [3.5, 3.5, 3.9, 3.9, 5.05, 5.05]; let tot = 0; amts.forEach((a, k) => { if (t >= 7.05 + k * .22 + .45) tot += a; }); g.fillText(tot.toFixed(2).replace('.', ','), 0, 0); g.restore();
  // itens: prateleira → carrinho, carrinho → esteira → bipe
  PICK.forEach((p) => { const o = p.sh === 'A' ? SA : p.sh === 'B' ? SB : SC, len = o.ori === 'Y' ? o.w * 100 : o.d * 100; void len; const xd = 28 + p.i * 38, zb = .2 + .3 + p.r * .52, from = itemWorld(o, xd, zb), f = (t - p.t) / .55; if (f > 0 && f < 1) { const cp = L.path(PATH, t), to = P(cp.x + .5, cp.y + .5, .85), x = L.lerp(from[0], to[0], L.ease.out(f)), y = L.lerp(from[1], to[1], f) - Math.sin(f * Math.PI) * 90; g.save(); g.translate(x, y); g.rotate(f * 6); prod(p.kind, p.col, 1 - f * .45); g.restore(); L.sparkle(g, from[0], from[1] - 10, 14 * (1 - f), f * 4); if (f < .3) L.priceTag(g, from[0], from[1] - 70 - f * 60, '+1', t, C.money, { t0: p.t, size: 26, rot: 0 }); } });
  PICK.forEach((p, k) => { const tb = 6.5 + k * .22, f = (t - tb) / .3; const start = P(me.x + .5, me.y + .5, .85), belt0 = P(5.5, 4.1, 1.28), belt1 = P(6.75, 4.1, 1.28); if (f > 0 && f < 1) { const x = L.lerp(start[0], belt0[0], L.ease.out(f)), y = L.lerp(start[1], belt0[1], f) - Math.sin(f * Math.PI) * 60; g.save(); g.translate(x, y); prod(p.kind, p.col, .75); g.restore(); }
    else if (t >= tb + .3 && t < tb + .3 + .5) { const m = (t - tb - .3) / .5; g.save(); g.translate(L.lerp(belt0[0], belt1[0], m), L.lerp(belt0[1], belt1[1], m)); prod(p.kind, p.col, .75); g.restore(); }
    const ts = 7.05 + k * .22 - .05 + .12; if (t > ts + .38 && t < ts + .8) { const m = (t - ts - .38) / .42, bp = P(6.75, 4.1, 1.28); g.save(); g.globalAlpha = 1 - m; g.strokeStyle = C.money; g.lineWidth = 5; for (let r = 1; r <= 2; r++) { g.beginPath(); g.arc(bp[0] + 10, bp[1] - 30, 14 * r * (.5 + m), -1, 1); g.stroke(); } g.fillStyle = C.accent2; g.font = font(22); g.textAlign = 'center'; g.fillText('BIP!', bp[0] + 6, bp[1] - 66 - m * 16); g.restore(); } });
  // plantinha, entrada e cestas
  { const q = P(7.4, .7, .2); L.box(g, P, 7.2, .5, .2, .45, .45, .4, '#b9714a'); for (let i = 0; i < 6; i++) { const a = -2.7 + i * .5 + Math.sin(t * 1.5 + i) * .08; g.fillStyle = i % 2 ? '#2fa86a' : '#3fc77d'; g.beginPath(); g.ellipse(q[0] + Math.cos(a) * 20, q[1] - 70 + Math.sin(a) * 30, 14, 34, a + 1.57, 0, 7); g.fill(); }
    L.poly(g, [P(1.1, 5.2, .21), P(2.4, 5.2, .21), P(2.4, 6, .21), P(1.1, 6, .21)], C.accent); const mt = P(1.75, 5.6, .21); g.fillStyle = '#fff'; g.font = font(14); g.textAlign = 'center'; g.fillText('ENTRADA', mt[0], mt[1] + 5); }
  if (me.y >= 2.5) meDraw();
  sign('PÃES', SC, 1.5); sign('FRUTAS', SA, 2.9); sign('BEBIDAS', SB, 4.5);
  { if (t > 8.3) { const q = P(6.2, 5.0, 2.7); L.priceTag(g, q[0], q[1] - 20, 'TOTAL ' + C.total, t, C.money, { t0: 8.3, size: 40, rot: -.04 }); } }
}
