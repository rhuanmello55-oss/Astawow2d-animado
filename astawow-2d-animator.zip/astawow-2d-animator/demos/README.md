# Demos (10 s cada) — ponto de partida para `new_project.sh`
| pasta | estilo | formato | o que mostra |
|---|---|---|---|
| mercadinho | iso-loja | 9:16 | lojinha azul, clientes entram e saem, rua colada à calçada |
| padaria | padaria | 9:16 | mesma estrutura, paleta e produtos de padaria |
| mercado | mercado | 9:16 | corte por dentro: prateleiras, caixa, esteira, carrinho, itens voando |
| menino | campo | 9:16 | menino de boné (preto e branco) sob a árvore; ideia (lâmpada) |
| palito | palito | 9:16 | escritório → sala japonesa, telha cai, chefe espia |
| toon | toon | 16:9 | gato × rato (perseguição, bonk, iris-out) |
Cada pasta: `cena.js`, `audio.json`, `cues.json`, `index.html`, libs. Rode `bash scripts/audio.sh <pasta>` e `node scripts/render.mjs <pasta> --audio <pasta>/mix.wav --out v.mp4 --blur 3`.
