/* stick.js — estilo "STICK FIGURE" de shorts: cabeção redondo, corpo de pílula, braços/pernas finos com contorno grosso, olhos/bocas expressivos
   (sorriso, dentes de grade, meio-lidado, arregalado, suor) em cenários de perspectiva com contorno preto: escritório e quarto azul (estilo japonês).
   Tudo pure(t). Personagens ORIGINAIS (receita de estilo, não cópia de personagem).
   stickGuy(g,{x,y,s,t,flip,pose:'stand'|'walk'|'sit',hair:'gray'|'black'|'bald',hairCol,suit,shirt,tie,badge,eyes:'normal'|'half'|'happy'|'wide'|'dots',mouth:'smile'|'grin'|'grid'|'o'|'flat'|'smirk',talk,brow,tilt,lean,armL,armR,sweat,look,walk,headOnly})
   officeRoom(g,W,H,t)  •  japanRoom(g,W,H,t)  •  ceilingHole(g,W,H) */
const INK = '#111111';
function stickGuy(g, o = {}) {
  const { x = 0, y = 0, s = 1, t = 0, flip = false, pose = 'stand', hair = 'black', hairCol, suit = '#27407a', shirt = null, tie = null, badge = false, eyes = 'normal', mouth = 'smile', talk = 0, brow = 0, tilt = 0, lean = 0, armL = .25, armR = .25, sweat = 0, look = 0, walk = 0, headOnly = false, pants = '#2a2f45' } = o;
  const br = Math.sin(t * 2.2) * 2, blink = (t % 3.6) > 3.5, sit = pose === 'sit', hipY = sit ? -112 : -72, ph = t * 8;
  const hc = hairCol || (hair === 'gray' ? '#b9bcc4' : '#1a1a1f');
  g.save(); g.translate(x, y); g.scale(flip ? -s : s, s); g.lineCap = 'round'; g.lineJoin = 'round';
  if (!headOnly) {
    // sombra de contato no chão (efeito de volume)
    const sg = g.createRadialGradient(0, 4, 4, 0, 4, 90); sg.addColorStop(0, 'rgba(0,0,0,.34)'); sg.addColorStop(1, 'rgba(0,0,0,0)'); g.save(); g.scale(1, .22); g.fillStyle = sg; g.beginPath(); g.arc(0, 4 / .22, 90, 0, 7); g.fill(); g.restore();
    // pernas: tracinho preto + pezinho
    g.strokeStyle = INK; g.lineWidth = 9;
    for (const k of [-1, 1]) { const sw = Math.sin(ph + (k > 0 ? 0 : Math.PI)) * walk * 26, lift = Math.max(0, Math.cos(ph + (k > 0 ? 0 : Math.PI))) * walk * 16;
      const fx = k * 20 + (sit ? k * 14 : sw), fy = -lift; g.beginPath(); g.moveTo(k * 14, hipY);
      if (sit) { g.lineTo(k * 46, hipY + 12); g.lineTo(k * 38, fy - 4); } else g.lineTo(fx, fy - 6); g.stroke();
      g.lineWidth = 11; g.beginPath(); g.moveTo(fx - 3, fy - 3); g.lineTo(fx + 20, fy - 3); g.stroke(); g.lineWidth = 9; }
    g.save(); g.translate(0, hipY); g.rotate(lean); g.translate(0, -hipY);
    // braços finos (traço preto) com mãozinha
    const arm = (k, a) => { const sx = k * 32, sy = -214 + br, ex = sx + Math.sin(a) * k * 48, ey = sy + Math.cos(a) * 52, hx = sx + Math.sin(a * 1.2) * k * 96, hy = sy + Math.cos(a * 1.2) * 98; g.strokeStyle = INK; g.lineWidth = 9; g.beginPath(); g.moveTo(sx, sy); g.quadraticCurveTo(ex + k * 6, ey, hx, hy); g.stroke(); g.fillStyle = INK; g.beginPath(); g.arc(hx, hy + 3, 9, 0, 7); g.fill(); };
    arm(-1, armL); arm(1, armR);
    // corpo fininho com volume (degradê + brilho)
    const base = shirt || suit, bg = g.createLinearGradient(-38, 0, 38, 0); bg.addColorStop(0, L.mixc(base, '#ffffff', .28)); bg.addColorStop(.45, base); bg.addColorStop(1, L.mixc(base, '#000000', .38));
    L.rr(g, -38, -238 + br, 76, hipY + 238 - br, 38); L.fillStroke(g, bg, INK, 7);
    g.fillStyle = 'rgba(255,255,255,.22)'; L.rr(g, -27, -222 + br, 9, hipY + 190 - br, 5); g.fill();
    if (!shirt) { g.fillStyle = '#f4f4f4'; g.beginPath(); g.moveTo(-13, -236 + br); g.lineTo(0, -184); g.lineTo(13, -236 + br); g.closePath(); g.fill(); g.strokeStyle = INK; g.lineWidth = 4; g.stroke(); g.beginPath(); g.moveTo(-13, -236 + br); g.lineTo(-22, -150); g.moveTo(13, -236 + br); g.lineTo(22, -150); g.stroke(); }
    if (tie) { g.fillStyle = tie; g.beginPath(); g.moveTo(-6, -206); g.lineTo(6, -206); g.lineTo(4, -192); g.lineTo(10, -124); g.lineTo(0, -112); g.lineTo(-10, -124); g.lineTo(-4, -192); g.closePath(); g.fill(); g.strokeStyle = INK; g.lineWidth = 3; g.stroke(); }
    if (badge) { g.strokeStyle = '#17306b'; g.lineWidth = 5; g.beginPath(); g.moveTo(-16, -236 + br); g.lineTo(0, -158); g.lineTo(16, -236 + br); g.stroke(); L.rr(g, -13, -162, 26, 38, 4); L.fillStroke(g, '#ffffff', INK, 4); g.fillStyle = '#9aa7c2'; g.fillRect(-7, -151, 14, 4); g.fillRect(-7, -141, 11, 4); g.fillRect(-7, -131, 8, 4); }
    if (shirt) { g.fillStyle = '#f4f9ff'; g.beginPath(); g.moveTo(-15, -238 + br); g.lineTo(0, -218); g.lineTo(15, -238 + br); g.closePath(); g.fill(); }
    g.save(); g.translate(0, -306 + br); g.rotate(tilt + lean * .6); drawHead(g); g.restore(); g.restore();
  } else drawHead(g);
  function drawHead(g) {
    const hg = g.createRadialGradient(-28, -32, 8, 0, 0, 104); hg.addColorStop(0, '#ffffff'); hg.addColorStop(.55, '#f1f4fa'); hg.addColorStop(1, '#bcc5d6'); g.beginPath(); g.ellipse(0, 0, 88, 80, 0, 0, 7); L.fillStroke(g, hg, INK, 9);
    g.fillStyle = 'rgba(255,255,255,.8)'; g.beginPath(); g.ellipse(-44, -40, 14, 8, -.6, 0, 7); g.fill();
    g.save(); g.beginPath(); g.ellipse(0, 0, 80, 73, 0, 0, 7); g.clip(); g.fillStyle = 'rgba(120,130,150,.18)'; g.beginPath(); g.ellipse(-30, -26, 118, 104, 0, 0, 7); g.ellipse(0, 0, 100, 90, 0, 0, 7); g.fill('evenodd');
    if (hair !== 'bald') { g.fillStyle = hc; g.beginPath(); if (hair === 'gray') { g.moveTo(-100, -110); g.lineTo(100, -110); g.lineTo(100, -26); g.quadraticCurveTo(60, -58, 14, -40); g.quadraticCurveTo(-30, -68, -100, -20); } else { g.moveTo(-100, -110); g.lineTo(100, -110); g.lineTo(100, -14); g.quadraticCurveTo(70, -40, 34, -34); g.quadraticCurveTo(-10, -48, -40, -22); g.quadraticCurveTo(-60, -50, -100, -30); } g.closePath(); g.fill(); g.strokeStyle = INK; g.lineWidth = 6; g.stroke();
      g.strokeStyle = 'rgba(255,255,255,.35)'; g.lineWidth = 4; g.beginPath(); g.moveTo(-60, -52); g.quadraticCurveTo(-10, -78, 50, -62); g.stroke(); }
    g.restore();
    const lx = look * 6;
    for (const k of [-1, 1]) { const ex = k * 29 + lx, ey = 2; g.fillStyle = INK; g.strokeStyle = INK;
      if (blink && eyes !== 'happy') { g.lineWidth = 6; g.beginPath(); g.moveTo(ex - 10, ey + 2); g.lineTo(ex + 10, ey + 2); g.stroke(); }
      else if (eyes === 'normal') { g.beginPath(); g.ellipse(ex, ey, 7, 10, 0, 0, 7); g.fill(); g.fillStyle = '#fff'; g.beginPath(); g.arc(ex + 2, ey - 3, 2.5, 0, 7); g.fill(); }
      else if (eyes === 'half') { g.beginPath(); g.arc(ex, ey - 2, 10, 0, Math.PI); g.fill(); g.lineWidth = 6; g.beginPath(); g.moveTo(ex - 13, ey - 2); g.lineTo(ex + 13, ey - 2); g.stroke(); }
      else if (eyes === 'happy') { g.lineWidth = 6; g.beginPath(); g.arc(ex, ey + 6, 12, Math.PI * 1.12, Math.PI * 1.88); g.stroke(); }
      else if (eyes === 'wide') { g.beginPath(); g.arc(ex, ey, 19, 0, 7); L.fillStroke(g, '#fff', INK, 6); g.fillStyle = INK; g.beginPath(); g.arc(ex + lx * .8, ey, 5, 0, 7); g.fill(); }
      else { g.beginPath(); g.arc(ex, ey, 6, 0, 7); g.fill(); } }
    if (brow) { g.strokeStyle = INK; g.lineWidth = 6; for (const k of [-1, 1]) { const by = -30 - Math.max(0, brow) * 12; g.beginPath(); g.moveTo(k * 46 + lx, by + (brow < 0 ? -k * -8 * -brow * -1 : 0) + (brow < 0 ? 8 * -brow * (k > 0 ? -1 : 1) * -1 : 0)); g.lineTo(k * 14 + lx, by + (brow < 0 ? 10 * -brow : -Math.max(0, brow) * 2)); g.stroke(); } }
    const my = 42 + look * 0, op = Math.max(talk, 0);
    g.strokeStyle = INK; g.lineWidth = 6;
    if (mouth === 'grin' || mouth === 'grid') { const w = mouth === 'grid' ? 38 : 56, h = mouth === 'grid' ? 26 : 34; L.rr(g, -w / 2 + lx * .6, my - h / 2 + 4, w, h + op * 8, 11); L.fillStroke(g, '#ffffff', INK, 5); g.lineWidth = 3; const cols = mouth === 'grid' ? 4 : 5; for (let i = 1; i < cols; i++) { g.beginPath(); g.moveTo(-w / 2 + lx * .6 + i * w / cols, my - h / 2 + 4); g.lineTo(-w / 2 + lx * .6 + i * w / cols, my + h / 2 + 4 + op * 8); g.stroke(); } g.beginPath(); g.moveTo(-w / 2 + lx * .6, my + 4); g.lineTo(w / 2 + lx * .6, my + 4); g.stroke(); }
    else if (mouth === 'o') { g.beginPath(); g.ellipse(lx * .6, my + 6, 11 + op * 4, 13 + op * 8, 0, 0, 7); g.fillStyle = INK; g.fill(); }
    else if (mouth === 'flat') { g.beginPath(); g.moveTo(-14 + lx, my + 4); g.lineTo(14 + lx, my + 4); g.stroke(); }
    else if (mouth === 'smirk') { g.beginPath(); g.moveTo(-18 + lx, my + 6); g.quadraticCurveTo(4 + lx, my + 16, 22 + lx, my - 2); g.stroke(); }
    else if (op > .08) { g.beginPath(); g.ellipse(lx * .6, my + 6, 16, 6 + op * 14, 0, 0, 7); g.fillStyle = INK; g.fill(); }
    else { g.beginPath(); g.moveTo(-18 + lx, my); g.quadraticCurveTo(lx, my + 16, 18 + lx, my); g.stroke(); }
    if (sweat) { const k = 1 + Math.sin(t * 6) * .06; g.save(); g.translate(62, -34 + sweat * 8); g.scale(k, k); g.beginPath(); g.moveTo(0, -22); g.quadraticCurveTo(15, 0, 0, 14); g.quadraticCurveTo(-15, 0, 0, -22); L.fillStroke(g, '#7fd3ff', INK, 4); g.fillStyle = 'rgba(255,255,255,.7)'; g.beginPath(); g.arc(-4, -2, 3.5, 0, 7); g.fill(); g.restore(); }
  }
  g.restore();
}
// ---------- cenários em perspectiva de 1 ponto ----------
function roomFrame(g, W, H, c, vpy) {
  const bx0 = W * .05, bx1 = W * .95, by0 = H * (vpy - .16), by1 = H * (vpy + .22);
  const poly = (pts, f) => { g.beginPath(); pts.forEach((q, i) => (i ? g.lineTo(q[0], q[1]) : g.moveTo(q[0], q[1]))); g.closePath(); g.fillStyle = f; g.fill(); g.strokeStyle = INK; g.lineWidth = 7; g.stroke(); };
  poly([[0, 0], [W, 0], [W, H], [0, H]], c.wall);
  poly([[0, 0], [bx0, by0], [bx0, by1], [0, H]], c.side); poly([[W, 0], [bx1, by0], [bx1, by1], [W, H]], c.side);
  poly([[0, 0], [W, 0], [bx1, by0], [bx0, by0]], c.ceil); poly([[0, H], [W, H], [bx1, by1], [bx0, by1]], c.floor);
  poly([[bx0, by0], [bx1, by0], [bx1, by1], [bx0, by1]], c.wall);
  // telhas do teto (perspectiva)
  g.save(); g.beginPath(); g.moveTo(0, 0); g.lineTo(W, 0); g.lineTo(bx1, by0); g.lineTo(bx0, by0); g.closePath(); g.clip();
  g.strokeStyle = c.tile; g.lineWidth = 3; const vx = W / 2, vy = H * vpy, N = 10;
  for (let i = 0; i <= N; i++) { const xb = bx0 + (bx1 - bx0) * i / N, f = (vy - 0) / (vy - by0), xf = vx + (xb - vx) * f; g.beginPath(); g.moveTo(xb, by0); g.lineTo(xf, 0); g.stroke(); }
  for (const z of [1.0, 1.18, 1.42, 1.75, 2.3, 3.4]) { const yy = vy - (vy - by0) * z; if (yy < 0) break; const f = (vy - yy) / (vy - by0); g.beginPath(); g.moveTo(vx + (bx0 - vx) * f, yy); g.lineTo(vx + (bx1 - vx) * f, yy); g.stroke(); }
  g.restore();
  // listras do piso
  g.strokeStyle = c.stripe; g.lineWidth = 3; for (let i = 0; i <= N; i++) { const xb = bx0 + (bx1 - bx0) * i / N, f = (H - vy) / (by1 - vy), xf = vx + (xb - vx) * f; g.beginPath(); g.moveTo(xb, by1); g.lineTo(xf, H); g.stroke(); }
  return { bx0, bx1, by0, by1, vx, vy };
}
function officeRoom(g, W, H, t) {
  const R = roomFrame(g, W, H, { wall: '#f6f7f9', side: '#e9ecf1', ceil: '#fbfcfe', floor: '#2d62c9', tile: '#d4d9e3', stripe: '#2650a8' }, .42), { bx0, bx1, by0, by1 } = R;
  const box = (x, y, w, h, f, lw = 6) => { L.rr(g, x, y, w, h, 4); L.fillStroke(g, f, INK, lw); };
  // quadro de cortiça com recados
  box(bx0 + 24, by0 + 70, 96, 130, '#e8a23a'); [[10, 14, '#fff'], [52, 22, '#ffe28a'], [18, 74, '#cfe8ff'], [56, 84, '#fff']].forEach(([a, b, c]) => { g.fillStyle = c; g.fillRect(bx0 + 24 + a, by0 + 70 + b, 32, 36); g.strokeStyle = '#00000044'; g.lineWidth = 2; g.strokeRect(bx0 + 24 + a, by0 + 70 + b, 32, 36); });
  // janela com prédios
  box(bx1 - 130, by0 + 30, 100, 230, '#6fb0ff'); g.fillStyle = '#3c78d8'; [[10, 100, 30, 120], [44, 60, 26, 160], [74, 120, 20, 100]].forEach(([a, b, w, h]) => g.fillRect(bx1 - 130 + a, by0 + 30 + b, w, h)); g.fillStyle = '#cfe6ff'; for (let i = 0; i < 9; i++) g.fillRect(bx1 - 124 + (i % 3) * 30, by0 + 140 + Math.floor(i / 3) * 34, 14, 18);
  // estante com livros coloridos
  const sx = W * .5, sy = by1 - 270, sw = 250; box(sx, sy, sw, 270, '#d9dde6'); const CO = ['#e8452c', '#2f8bd6', '#f4b400', '#2ea36b', '#8a5fd0', '#ff7f50', '#1d4a9a'];
  for (let r = 0; r < 3; r++) { const ry = sy + 14 + r * 84; g.fillStyle = '#b8bfcc'; g.fillRect(sx + 6, ry + 70, sw - 12, 8); let bx = sx + 12; for (let i = 0; i < 12; i++) { const bw = 12 + L.hash(i + r * 12, 3) * 10, bh = 44 + L.hash(i + r * 12, 4) * 24; g.fillStyle = CO[(i * 3 + r * 2) % 7]; g.fillRect(bx, ry + 70 - bh, bw, bh); g.strokeStyle = INK; g.lineWidth = 2.5; g.strokeRect(bx, ry + 70 - bh, bw, bh); bx += bw + 3; if (bx > sx + sw - 24) break; } }
  box(sx + 10, sy - 38, 40, 38, '#1f8a70'); box(sx + 70, sy - 38, 40, 38, '#176d58');
  // planta
  g.fillStyle = '#2fa86a'; for (let i = 0; i < 5; i++) { g.beginPath(); g.ellipse(bx1 - 26 + (i - 2) * 9, by1 - 160 + Math.sin(t * 1.3 + i) * 3, 12, 34, (i - 2) * .3, 0, 7); g.fill(); g.strokeStyle = INK; g.lineWidth = 3; g.stroke(); } box(bx1 - 52, by1 - 100, 52, 60, '#b9714a');
  // mesa com monitor "READY"
  box(bx0 + 10, by1 - 70, 330, 70, '#ffffff'); box(bx0 + 40, by1 - 120, 120, 50, '#bfe6ff'); g.fillStyle = '#2f6fd1'; g.font = '800 22px "DejaVu Sans",sans-serif'; g.textAlign = 'center'; g.fillText('READY', bx0 + 100, by1 - 88);
  box(bx0 + 190, by1 - 108, 8, 40, '#cfd6e2'); box(bx0 + 220, by1 - 100, 70, 30, '#ff8a3d');
  // divisórias em primeiro plano (azul-acinzentado, contorno grosso)
  g.beginPath(); g.moveTo(W * .64, H * .86); g.lineTo(W * .92, H * .78); g.lineTo(W, H * .78); g.lineTo(W, H); g.lineTo(W * .64, H); g.closePath(); g.fillStyle = '#8fa3c9'; g.fill(); g.strokeStyle = INK; g.lineWidth = 8; g.stroke();
  g.beginPath(); g.moveTo(W * .64, H * .86); g.lineTo(W * .92, H * .78); g.lineTo(W * .92, H * .8); g.lineTo(W * .64, H * .88); g.closePath(); g.fillStyle = '#e8eef9'; g.fill(); g.stroke();
  return R;
}
function japanRoom(g, W, H, t) {
  const R = roomFrame(g, W, H, { wall: '#2c5fb6', side: '#234f9c', ceil: '#8fb2ff', floor: '#1b3a7a', tile: '#6f93e0', stripe: '#16306a' }, .44), { bx0, bx1, by0, by1 } = R;
  const box = (x, y, w, h, f, lw = 6) => { L.rr(g, x, y, w, h, 3); L.fillStyle = 0; L.fillStroke(g, f, INK, lw); };
  g.strokeStyle = '#1b3f86'; g.lineWidth = 4; for (let i = 0; i < 5; i++) { const x = bx0 + 20 + i * ((bx1 - bx0 - 40) / 4); g.strokeRect(x, by0 + 24, (bx1 - bx0 - 40) / 4 - 12, by1 - by0 - 60); }
  // shoji (janela de papel) com luz quente
  const wx = W * .26, wy = by0 + 70, ww = W * .3, wh = by1 - wy - 10, gl = g.createLinearGradient(0, wy, 0, wy + wh); gl.addColorStop(0, '#ffe3a1'); gl.addColorStop(1, '#ffb25b'); box(wx, wy, ww, wh, gl); g.strokeStyle = '#8a4a1e'; g.lineWidth = 5; for (let i = 1; i < 4; i++) { g.beginPath(); g.moveTo(wx + ww * i / 4, wy); g.lineTo(wx + ww * i / 4, wy + wh); g.stroke(); } for (let j = 1; j < 3; j++) { g.beginPath(); g.moveTo(wx, wy + wh * j / 3); g.lineTo(wx + ww, wy + wh * j / 3); g.stroke(); }
  box(wx - 12, wy + wh - 6, ww + 24, 16, '#b8743a');
  // pôster da torre
  const px = wx + ww + 24, pw = W * .12; box(px, wy - 10, pw, wh + 6, '#bfe0ff'); g.fillStyle = '#e8452c'; g.beginPath(); g.moveTo(px + pw / 2, wy + 14); g.lineTo(px + pw * .72, wy + wh * .8); g.lineTo(px + pw * .28, wy + wh * .8); g.closePath(); g.fill(); g.strokeStyle = INK; g.lineWidth = 4; g.stroke(); g.fillStyle = '#fff'; for (const f of [.3, .48, .64]) g.fillRect(px + pw * (.5 - .17 * (1 - f * .3)), wy + wh * f, pw * .34 * (1 - f * .3), 10);
  // pergaminho com pinceladas
  box(bx0 + 30, wy - 20, 60, 190, '#f3efe6'); g.strokeStyle = INK; g.lineCap = 'round'; g.lineWidth = 8; g.beginPath(); g.moveTo(bx0 + 46, wy + 10); g.lineTo(bx0 + 76, wy + 10); g.moveTo(bx0 + 60, wy + 4); g.lineTo(bx0 + 60, wy + 60); g.moveTo(bx0 + 44, wy + 90); g.quadraticCurveTo(bx0 + 62, wy + 70, bx0 + 78, wy + 100); g.moveTo(bx0 + 50, wy + 120); g.lineTo(bx0 + 72, wy + 150); g.stroke(); g.fillStyle = '#e8452c'; g.fillRect(bx0 + 40, wy + 150, 14, 14);
  // prateleira + gatinho da sorte (acena)
  const sx = bx1 - 70; box(sx - 30, by1 - 150, 90, 10, '#b8743a'); const cy2 = by1 - 150; g.save(); g.translate(sx + 14, cy2); g.beginPath(); g.ellipse(0, -26, 20, 26, 0, 0, 7); L.fillStroke(g, '#ffffff', INK, 4); g.beginPath(); g.arc(0, -62, 18, 0, 7); L.fillStroke(g, '#ffffff', INK, 4); for (const k of [-1, 1]) { g.beginPath(); g.moveTo(k * 18, -72); g.lineTo(k * 12, -88); g.lineTo(k * 4, -76); g.fill(); g.stroke(); } g.save(); g.translate(18, -40); g.rotate(-.7 + Math.sin(t * 6) * .35); g.fillStyle = '#fff'; L.rr(g, -5, -26, 12, 30, 6); L.fillStroke(g, '#fff', INK, 3); g.restore(); g.fillStyle = INK; g.fillRect(-8, -64, 4, 4); g.fillRect(5, -64, 4, 4); g.restore();
  return R;
}
// buraco no teto onde a telha sai
function ceilingHole(g, W, H) { g.beginPath(); g.moveTo(W * .39, H * .075); g.lineTo(W * .61, H * .075); g.lineTo(W * .58, H * .16); g.lineTo(W * .42, H * .16); g.closePath(); g.fillStyle = '#0b1020'; g.fill(); g.strokeStyle = INK; g.lineWidth = 7; g.stroke(); }
