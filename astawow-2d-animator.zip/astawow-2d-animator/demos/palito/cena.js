const CONFIG = { w: 1080, h: 1920, fps: 30, dur: 10 };
const T1 = 'Meu chefe chegou todo sorridente e falou assim: bora conversar um pouquinho?', T2 = 'Só que aí o teto abriu... e olha quem apareceu!';
// window.WORDS vem do words.js gerado por audio/mix.py (legenda = fala)
function shotA(g, t, W, H) {
  officeRoom(g, W, H, t); const FY = H * .82, wk = L.clamp(t / 1.2);
  // funcionário (camisa azul, crachá) — desconfiado
  stickGuy(g, { x: W * .66, y: FY, s: 1.75, t, shirt: '#8fc3ff', badge: true, pants: '#2f3d5e', hair: 'black', eyes: t > 1.6 ? 'half' : 'normal', mouth: t > 3.3 ? 'flat' : 'smile', brow: t > 1.6 ? -.4 : 0, tilt: Math.sin(t * 1.5) * .04, armL: .2, armR: .3 + Math.sin(t * 2) * .04, look: -.6 });
  // chefe (terno, gravata, cabelo grisalho) — entra andando, sorri com dentes
  const bx = L.lerp(-160, W * .34, L.ease.out(wk)), talking = t > 1.3 && t < 4.3;
  stickGuy(g, { x: bx, y: FY, s: 1.9, t, suit: '#1f2f5c', tie: '#d9402f', hair: 'gray', pose: 'walk', walk: wk < 1 ? 1 : 0, ph: t * 8, eyes: 'happy', mouth: 'grin', talk: talking ? Math.abs(Math.sin(t * 11)) * .8 : 0, lean: t > 1.2 ? .1 + Math.sin(t * 2) * .02 : 0, armL: .25, armR: talking ? 1.2 + Math.sin(t * 5) * .25 : .3 });
}
function shotB(g, t, W, H) {
  japanRoom(g, W, H, t); ceilingHole(g, W, H); const lt = t - 4.6, FY = H * .81, tile = lt - 1.5;   // tile: 1.5 s -> sobe, cai
  // cadeira de escritório (encosto atrás, assento, haste e estrela com rodinhas)
  const yf = H * .9, cx = W * .5; L.rr(g, cx - 92, yf - 420, 184, 250, 34); L.fillStroke(g, '#202a3d', INK, 8);
  const scared = lt > 2.0, shake = lt < 2.0 ? Math.sin(lt * 40) * 2.2 : 0, jump = scared ? Math.max(0, .25 - (lt - 2.0)) * 160 : 0;
  g.strokeStyle = INK; g.lineWidth = 12; g.beginPath(); g.moveTo(cx, yf - 170); g.lineTo(cx, yf - 26); g.moveTo(cx - 120, yf - 6); g.lineTo(cx + 120, yf - 6); g.stroke(); for (const k of [-120, 0, 120]) { g.fillStyle = INK; g.beginPath(); g.arc(cx + k, yf + 2, 11, 0, 7); g.fill(); }
  L.rr(g, cx - 120, yf - 205, 240, 52, 22); L.fillStroke(g, '#2b3a58', INK, 8);
  stickGuy(g, { x: cx + shake, y: yf - jump, s: 1.8, t, pose: 'sit', shirt: '#8fc3ff', badge: true, hair: 'black', eyes: 'wide', mouth: scared ? 'o' : 'grid', talk: scared ? .9 : 0, sweat: 1, brow: .6, look: scared ? 0 : .5, armL: .9, armR: .9, lean: scared ? -.12 : 0 });
  for (const k of [-1, 1]) { L.rr(g, cx + k * 150 - 22, yf - 250, 44, 20, 8); L.fillStroke(g, '#2b3a58', INK, 6); }
  // telha empurrada → cai
  if (tile > -.3 && tile < 1.0) { const up = tile < 0 ? -tile : 0, f = Math.max(0, tile); g.save(); const cx = W * .5, cy = H * .12; g.translate(cx, cy + f * f * H * 1.4); g.rotate(f * 3 + Math.sin(lt * 25) * (tile < 0 ? .04 : 0)); const sc = 1 + f * 1.1; g.scale(sc, sc); g.translate(0, -up * 20); g.beginPath(); g.moveTo(-W * .1, -H * .045); g.lineTo(W * .1, -H * .045); g.lineTo(W * .085, H * .045); g.lineTo(-W * .085, H * .045); g.closePath(); L.fillStroke(g, '#a9c3ff', INK, 7); g.restore(); }
  // chefe espiando de cabeça pra baixo no buraco
  if (lt > 2.2) { const k = L.spring(lt - 2.2), g2 = 1; g.save(); g.beginPath(); g.moveTo(W * .39, H * .075); g.lineTo(W * .61, H * .075); g.lineTo(W * .58, H * .16); g.lineTo(W * .42, H * .16); g.closePath(); g.clip(); g.translate(W * .5, H * .118 + (1 - k) * -170); g.rotate(Math.PI); g.scale(1.1 * g2, 1.1); stickGuy(g, { headOnly: true, t, hair: 'gray', eyes: 'happy', mouth: 'grin', talk: Math.abs(Math.sin(t * 10)) * .6 }); g.restore(); }
}
function draw(g, t, W, H) {
  const A = t < 4.6, lt = t - 4.6, shk = (!A && lt > 2.0 && lt < 2.5) ? (2.5 - lt) * 18 : 0;
  g.save(); L.cam(g, W, H, t, { zoom: 1.02 + .05 * (A ? t / 4.6 : lt / 5.4), drift: .006, px: Math.sin(t * 60) * shk, py: Math.cos(t * 53) * shk });
  if (A) shotA(g, t, W, H); else shotB(g, t, W, H);
  g.restore();
  if (Math.abs(t - 4.6) < .08) { g.fillStyle = `rgba(255,255,255,${1 - Math.abs(t - 4.6) / .08})`; g.fillRect(0, 0, W, H); }
  L.captions(g, W, H, WORDS, t, { y: H * .86, size: 84, group: 3, hi: '#ff8a3d' });
}
