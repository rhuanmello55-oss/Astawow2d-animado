# Changelog
## v12
- **Áudio reconstruído**: legendas por texto = fala (`captions` → `words.js`); voz neural (Kokoro) deixada como experimental e DESLIGADA (soou pt-PT e com chiado); música com instrumentos reais (SoundFont) em 6 estilos, efeitos suaves (click/digitar sem estridência), `audio/models.py` baixa modelos 1x; fallback sintético se offline.
- **Enquadramento corrigido nos demos** (letreiros/etiquetas não cobrem pessoas nem saem do quadro) + `scripts/composicao.py` (verificador automático).
- Agentes: `detalhista` mais duro, novo `audio-qa`; `requirements.txt`.
## v11
- Acabamento de cinema (`L.finish`: bloom, grade quente/fria, vinheta, grão) ligado por padrão no `index.html` (`CONFIG.finish=false` desliga).
- Agente **detalhista** (auditor que questiona tudo) + versões universais (`agents/universal/`), `AGENTS.md`, `CLAUDE.md`, `GEMINI.md`, `chatgpt/`, `install.sh`.
- `references/composicao.md` (regras de enquadramento), `references/3d.md` (roteiro para 3D), `templates/shotlist.md`, `templates/critique.md`, LICENSE MIT.
## v10
- Motor de áudio `audio/` (música em 6 estilos, 34 efeitos, 10 vozes de personagem, ambientes, mixagem −14 LUFS com ducking e relatório).
- Render: `--blur`, `--hits`, `--strip`, `--phone`. Lib: `springU wobble shake zoomLog kf`.
## v9
- Prompt mestre embutido (MODO PEDIDO), `/animar`, agente `animation-qa`, `new_project.sh`, `qa_video.sh`, 6 demos.
