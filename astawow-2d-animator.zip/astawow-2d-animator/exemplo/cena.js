const CONFIG = { w: 1080, h: 1920, fps: 30, dur: 9 };
const CREAM = '#fff3c4';
// --- Cena 1: fundo plano com bolinhas + personagem apontando para o robô ---
function cena1(g, t, W, H) {
  g.fillStyle = '#1aa7a8'; g.fillRect(0, 0, W, H); L.dots(g, W, H, 'rgba(255,255,255,.14)', 90, 12, t);
  const k = L.spring(t - 0.05); // entrada com mola
  // robô flutuando (personagem original, não é de marca)
  g.save(); g.translate(790, 760 + Math.sin(t * 2.2) * 14); g.scale(1.25 * L.spring(t - .35), 1.25 * L.spring(t - .35));
  L.shadow(g, 0, 250, 70, 14, .15);
  g.strokeStyle = '#2a1b2e'; g.lineWidth = 6; g.beginPath(); g.moveTo(0, -150); g.lineTo(0, -190); g.stroke(); g.fillStyle = '#ff6a5a'; g.beginPath(); g.arc(0, -198, 12, 0, 7); L.fillStroke(g, '#ff6a5a', '#2a1b2e', 6);
  L.rr(g, -90, -150, 180, 150, 26); L.fillStroke(g, '#c9d4e8', '#2a1b2e', 6);
  L.rr(g, -66, -120, 132, 70, 14); L.fillStroke(g, '#1b2340', '#2a1b2e', 5); g.fillStyle = '#4de3ff'; for (const sx of [-30, 30]) { g.beginPath(); g.arc(sx, -86, 15, 0, 7); g.fill(); }
  L.rr(g, -60, -22, 120, 14, 5); L.fillStroke(g, '#7b8bab', '#2a1b2e', 4); L.rr(g, -70, 0, 140, 110, 22); L.fillStroke(g, '#aebbd6', '#2a1b2e', 6); g.restore();
  const env = Math.abs(Math.sin(t * 11)) * (t < 3 ? 1 : 0);
  L.person(g, { x: 330, y: 1250 + (1 - k) * 400, s: 2.1, t, skin: '#8a5a3c', hair: '#1c1412', hairStyle: 'short', shirt: '#f2b632', pants: '#2c4a8a', shoes: '#5a3b2b', mustache: true, blush: true, buttons: true, belt: '#6a4326',
    mouth: L.visemeFrom(env, t), mouthOpen: env, brow: -0.3 + 0.5 * Math.sin(t * 2), look: [0.8, -0.3], armR: 1.45 + Math.sin(t * 5) * .07, armL: 0.15 + Math.sin(t * 3.1) * .12 });
  for (let i = 0; i < 7; i++) { const a = t * 1.4 + i * 0.9, r = 190 + 30 * Math.sin(t * 2 + i), sx = 790 + Math.cos(a) * r, sy = 740 + Math.sin(a) * r * .8, k = .5 + .5 * Math.sin(t * 6 + i * 2); g.save(); g.translate(sx, sy); g.rotate(a); g.fillStyle = `rgba(255,255,255,${.35 + .5 * k})`; g.beginPath(); for (let j = 0; j < 8; j++) { const rr2 = j % 2 ? 6 : 16 * (.6 + k * .6); g.lineTo(Math.cos(j * .785) * rr2, Math.sin(j * .785) * rr2); } g.fill(); g.restore(); }
  L.title(g, W, 'SIMULAÇÃO', 120, t, { t0: .2 });
}
// --- Cena 2: MERCADINHO low-poly isométrico, tudo azul, colado na rua; clientes entram/saem, carros passam ---
function cena2(g, t, W, H) {
  L.sky(g, W, H, '#2f86e0', '#cfeaff'); L.cloudLP(g, 220 + t * 22, 240, 1.3); L.cloudLP(g, 840 - t * 14, 370, 1.0);
  g.fillStyle = '#8fd0f7'; g.fillRect(0, 700, W, H - 700);
  // supermercado do fundo (frio e caro)
  const sx = 30, sy = 500; g.fillStyle = '#8f9db8'; g.fillRect(sx, sy, 400, 200); g.fillStyle = '#6f7e9b'; g.fillRect(sx, sy, 400, 28); g.fillStyle = '#c4d4ec'; for (let i = 0; i < 5; i++) g.fillRect(sx + 20 + i * 76, sy + 60, 58, 90);
  g.fillStyle = '#c0392b'; L.rr(g, sx + 60, sy + 34, 280, 40, 8); g.fill(); g.font = '900 26px "Archivo Black","Impact","DejaVu Sans",sans-serif'; g.fillStyle = '#fff'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('SUPERMERCADÃO', sx + 200, sy + 55);
  const P = L.iso(560, 1010, 98), BLU = ['#1f8f9c', '#187a86', '#29a3b0', '#36b7c4'];
  // rua azul-marinho colada na calçada, com faixas rolando
  L.box(g, P, -12, 3.2, 0, 24, 3.0, .06, '#263353'); L.box(g, P, -12, 3.2, .06, 24, .12, 0, '#7f93bd');
  for (let i = -14; i < 14; i++) { const x0 = i * 1.6 + ((t * 2.4) % 1.6), A = P(x0, 4.7, .07), B = P(x0 + .8, 4.7, .07); g.strokeStyle = '#eaf2ff'; g.lineWidth = 7; g.lineCap = 'butt'; g.beginPath(); g.moveTo(A[0], A[1]); g.lineTo(B[0], B[1]); g.stroke(); }
  L.box(g, P, -3.4, -2.2, 0, 6.8, 5.4, .14, '#dcebfd'); L.box(g, P, -3.4, 3.0, .14, 6.8, .2, 0, '#a8c1e6');
  const rise = L.spring(t - .05), hh = 3.0 * rise;
  L.box(g, P, -2.6, -1.6, 0, 5.2, 3.2, hh, '#e9f4ff');
  L.box(g, P, -2.72, -1.72, hh, 5.44, 3.44, .24 * rise, '#1f5fd0');
  L.treeLP(g, P, 3.4, -1.4, Math.sin(t * 2), BLU); L.treeLP(g, P, -3.1, 2.4, Math.sin(t * 2 + 1), BLU);
  if (rise > .95) {
    L.box(g, P, 1.4, -1.0, hh + .24, .9, .8, .35, '#9db4d8');                                                     // ar-condicionado no telhado
    const pop = L.spring(t - .5); L.box(g, P, -2.2, -.5, hh + .24, 4.4, .16, 1.15 * pop, '#12306b');            // letreiro no telhado
    if (pop > .5) { g.save(); L.faceY(g, P, -2.2, -.34); g.globalAlpha = Math.min(1, pop); const glow = .75 + .25 * Math.sin(t * 6); g.font = '900 50px "Archivo Black","Impact","DejaVu Sans",sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.shadowColor = '#7cc8ff'; g.shadowBlur = 18 * glow; g.fillStyle = '#ffffff'; g.fillText('MERCADINHO', 220, -(hh + .24 + .55) * 100); g.restore(); }
    g.save(); L.faceY(g, P, -2.6, 1.6);
    const wall = (x0, x1, z0, z1, f, st) => { L.rr(g, x0 * 100, -z1 * 100, (x1 - x0) * 100, (z1 - z0) * 100, 8); L.fillStroke(g, f, st, 6); };
    for (const [x0, x1] of [[.3, 1.6], [3.5, 4.8]]) { wall(x0, x1, .75, 1.85, '#aee3ff', '#1c2a4a'); g.fillStyle = 'rgba(255,240,180,.55)'; g.fillRect(x0 * 100 + 6, -178, (x1 - x0) * 100 - 12, 40); g.fillStyle = 'rgba(255,255,255,.6)'; g.beginPath(); g.moveTo(x0 * 100 + 18, -176); g.lineTo(x0 * 100 + 58, -176); g.lineTo(x0 * 100 + 8, -90); g.lineTo(x0 * 100 - 32 + 18, -90); g.fill(); }
    const open = L.ease.smooth((t - 1.35) / .35) * (1 - L.ease.smooth((t - 2.5) / .35)); wall(2.05, 3.05, 0, 1.75, '#1b2b4a', '#1c2a4a');
    g.save(); L.rr(g, 205, -175, 100 * (1 - .85 * open), 175, 8); g.clip(); g.fillStyle = '#9fdcff'; g.fillRect(205, -175, 100, 175); g.restore(); g.strokeStyle = '#1c2a4a'; g.lineWidth = 6; L.rr(g, 205, -175, 100 * (1 - .85 * open), 175, 8); g.stroke();
    const sw = Math.sin(t * 2.4) * 6; for (let i = 0; i < 9; i++) { const x0 = 20 + i * 55; g.fillStyle = i % 2 ? '#ffffff' : '#1f5fd0'; g.beginPath(); g.moveTo(x0, -215); g.lineTo(x0 + 55, -215); g.lineTo(x0 + 55 + 8, -188 + sw * .3); g.lineTo(x0 + 8, -188 + sw * .3); g.fill(); }
    g.fillStyle = '#12306b'; L.rr(g, 40, -280, 440, 60, 12); g.fill(); g.font = '900 27px "Archivo Black","Impact","DejaVu Sans",sans-serif'; g.fillStyle = '#ffd23f'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('FRUTAS • BEBIDAS • PÃO', 260, -250);
    g.restore();
  }
  L.lampLP(g, P, -3.3, 3.0, t); L.lampLP(g, P, 3.3, 3.0, t);
  // carros em duas faixas
  const car = (x0, y0, col, dir) => { L.box(g, P, x0, y0, .1, 1.9, .9, .42, col); L.box(g, P, x0 + (dir > 0 ? .5 : .4), y0 + .05, .52, 1.0, .8, .36, '#d9f0ff'); for (const wx2 of [x0 + .25, x0 + 1.35]) { const [qx, qy] = P(wx2, y0 + .9, .12); g.fillStyle = '#10131c'; g.beginPath(); g.arc(qx, qy, 17, 0, 7); g.fill(); g.fillStyle = '#c9d4ea'; g.beginPath(); g.arc(qx, qy, 7, 0, 7); g.fill(); } };
  car(L.lerp(-8, 8, (t / 3 + .1) % 1), 3.55, '#ffc93c', 1);
  // caixotes de frutas
  for (const [cx, cy, c1] of [[-2.3, 2.15, '#e8452c'], [-1.5, 2.15, '#f4a21d']]) { L.box(g, P, cx, cy, 0, .7, .6, .35, '#b98652'); const [qx, qy] = P(cx + .35, cy + .3, .4); for (let k = 0; k < 4; k++) { g.fillStyle = c1; g.beginPath(); g.arc(qx - 18 + k * 12, qy - 4 + (k % 2) * 6, 11, 0, 7); g.fill(); g.fillStyle = 'rgba(255,255,255,.4)'; g.beginPath(); g.arc(qx - 21 + k * 12, qy - 8 + (k % 2) * 6, 3.5, 0, 7); g.fill(); } }
  // cliente 1 entra pela porta; cliente 2 sai com sacola
  const pers = (wx, wy, al, shirt, bag) => { const [px, py] = P(wx, wy, 0); g.save(); g.globalAlpha = al; L.person(g, { x: px, y: py, s: .42, t, pose: 'walk', shirt, pants: '#2c3550', skin: '#f2c6a0', hair: '#1c1412', mouth: 'smile', brow: .4, prop: bag ? (h) => { h.fillStyle = '#ffc93c'; L.rr(h, -18, -10, 44, 52, 6); L.fillStroke(h, '#ffc93c', '#12306b', 5); h.beginPath(); h.arc(4, -10, 14, Math.PI, 0); h.strokeStyle = '#12306b'; h.lineWidth = 5; h.stroke(); } : undefined }); g.restore(); };
  if (t < 2.25) { const k1 = L.clamp((t - .1) / 1.4), k2 = L.clamp((t - 1.5) / .7); pers(L.lerp(.7, 2.55, k1), L.lerp(2.75, 1.85, k2), 1 - L.ease.smooth((t - 1.95) / .3), '#2f6fd1', false); }
  if (t > 1.9) { const k = L.clamp((t - 1.9) / .6), k2 = L.clamp((t - 2.5) / .5); pers(L.lerp(2.55, 3.4, k2), L.lerp(1.85, 2.8, k), L.ease.smooth((t - 1.9) / .25), '#e8704a', true); }
  L.priceTag(g, 240, 440, 'R$ 9,99', t, '#c0392b', { t0: .5, size: 46, rot: -.1 });
  L.priceTag(g, 800, 1090, 'R$ 5,99', t, '#1fa84f', { t0: 1.1, size: 78, rot: .06 });
  L.title(g, W, 'MAIS BARATO QUE O SUPERMERCADO!', 190, t, { t0: .15, size: 40, bg: '#1f5fd0' });
}
// --- Cena 3: o menino de preto e branco chega andando, senta sob a árvore e acena; câmera empurra devagar ---
function cena3(g, t, W, H) {
  const px = L.lerp(26, -26, t / 3);
  L.sky(g, W, H, '#6fb9f0', '#f4fbff');
  const sun = g.createRadialGradient(170, 210, 10, 170, 210, 420); sun.addColorStop(0, 'rgba(255,250,210,.95)'); sun.addColorStop(1, 'rgba(255,250,210,0)'); g.fillStyle = sun; g.fillRect(0, 0, W, 800);
  g.fillStyle = '#fffbe0'; g.beginPath(); g.arc(170, 210, 58, 0, 7); g.fill();
  L.cloudLP(g, 380 + t * 16, 330, 1.5); L.cloudLP(g, 880 - t * 9, 520, 1.0);
  g.save(); g.translate(px * .3, 0); L.hill(g, W + 60, H, 900, 40, 1.1, 0.6, '#8fcf9a', '#5fae6b'); g.restore();
  g.save(); g.translate(px * .6, 0); L.hill(g, W + 60, H, 980, 50, 0.9, 2.2, '#6fc06a', '#3f9a48'); g.restore();
  L.hill(g, W, H, 1060, 36, 1.3, 4.0, '#5db14f', '#2f8a3a');
  L.field(g, W, 1060, 1400, 8, 20, t, 3);
  L.bigTree(g, 800, 1250, 1.0, t);
  // timeline: anda (0–1.35s) → pulo e senta (1.35–1.6s) → olha pra cima e acena (1.9s+)
  const GY = 1340;
  if (t < 1.5) { const k = Math.min(1, t / 1.35), x = L.lerp(-150, 210, k), moving = t < 1.35 ? 1 : 0, hop = t > 1.35 ? Math.sin((t - 1.35) / .15 * Math.PI) * 34 : 0; L.ballGuy(g, { x, y: GY - hop, s: .95, t, pose: 'walk', walk: moving, ph: t * 9, look: .4, mouth: 'smile' }); }
  else { const sq = 1 + .06 * Math.max(0, 1 - (t - 1.5) / .2) * Math.sin((t - 1.5) * 30); g.save(); g.translate(200, GY); g.scale(1 / sq, sq); g.translate(-200, -GY); L.ballGuy(g, { x: 200, y: GY, s: 1.1, t, pose: 'sit', look: .7, up: Math.min(.8, (t - 1.6) * 2), wave: t > 1.95 ? 1 : 0, talk: t > 2.0 ? Math.abs(Math.sin(t * 10)) * .8 : 0, tilt: Math.sin(t * 2.2) * .04 }); g.restore(); }
  L.field(g, W, 1560, 1980, 6, 14, t, 11, .15);
  L.rays(g, W, H, 170, 210, t, .10);
  L.drift(g, W, H, t, 18, ['#b9f08a', '#7bd56a', '#fff3a0'], 11);
}
function draw(g, t, W, H) {
  const sc = t < 3 ? 0 : t < 6 ? 1 : 2, lt = t - sc * 3;
  g.save(); L.cam(g, W, H, lt, { zoom: 1.03 + .03 * L.clamp(lt / 3), drift: .01 });
  [cena1, cena2, cena3][sc](g, lt, W, H);
  g.restore();
  // corte seco com flash de 3 frames
  const d = lt; if (d < .1 && sc > 0) { g.fillStyle = `rgba(255,255,255,${.5 * (1 - d / .1)})`; g.fillRect(0, 0, W, H); }
  L.captions(g, W, H, WORDS, t, { y: H * .76, size: 92, group: 2 });
}
