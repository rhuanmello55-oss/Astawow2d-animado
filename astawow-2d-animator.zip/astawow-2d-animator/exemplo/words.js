window.WORDS = L.wordsFromText('Você já imaginou criar vídeos assim só com inteligência artificial', 0.2, 3.0)
  .concat(L.wordsFromText('Um mercadinho barato abre na esquina', 3.1, 6.0))
  .concat(L.wordsFromText('E a história continua no campo', 6.1, 8.8));
window.ENV = [];
