# astawow-2d-animator
Skill para criar **animações 2D por código** (flat, isométrico low-poly, palito, desenho de perseguição) e exportar **MP4** (Shorts 9:16, YouTube 16:9, quadrado) — com música, vozes de personagem, efeitos e mixagem prontos. Funciona no Claude Code, Codex, Gemini CLI/Antigravity, Cursor e (com ajuda) no ChatGPT.

## Instalar
```bash
bash install.sh all        # claude | codex | gemini | all
# requisitos: node 18+, ffmpeg, python3 (numpy scipy), playwright + chromium
npm i playwright && npx playwright install chromium && pip install -r requirements.txt && pip install --no-deps tinysoundfont && python3 audio/models.py   # áudio: instrumentos reais da música (~35 MB, 1x)
```
## Usar (3 jeitos)
1. **Pedindo**: "faz um vídeo de 10 s do mercadinho, vertical" (o `SKILL.md` tem o prompt mestre embutido). No Claude Code: `/animar <ideia>`.
2. **Formulário**: cole o `PROMPT_MESTRE.md` preenchido (história, duração, formato, estilo, personagens, cenário, narração, legendas, final).
3. **À mão**: `bash scripts/new_project.sh toon meu_video` → edite `cena.js` e `audio.json` → `bash scripts/audio.sh meu_video` → `node scripts/render.mjs meu_video --audio meu_video/mix.wav --out video.mp4 --blur 3`.

## O que vem dentro
| pasta/arquivo | para quê |
|---|---|
| `SKILL.md` | regras, fluxo e modo pedido (fonte da verdade) |
| `PROMPT_MESTRE.md` | formulário para colar + exemplos |
| `AGENTS.md` `CLAUDE.md` `GEMINI.md` `chatgpt/` | instruções por agente/plataforma |
| `agents/` | revisores: **detalhista** (tolerância zero), **audio-qa** (mede o áudio), animation-qa; `universal/` p/ qualquer IA |
| `templates/` | libs (`lib2d.js`, `shop.js`, `mercado.js`, `stick.js`, `toon.js`), `index.html`, `audio.json`, shotlist, crítica |
| `audio/` | motor de áudio: 6 músicas, 34 efeitos, 10 vozes, ambientes, mixagem −14 LUFS; `exemplos/` com MP3 |
| `scripts/` | render (blur, hits, strip, phone), lint, new_project, audio, qa_video, prep_audio |
| `references/` | api, escala, estilos, personagens, cenários, legendas, áudio, estúdio, composição, 3D, qa, dicas |
| `demos/` `exemplo/` | 7 projetos prontos com MP4 |

## Qualidade
Acabamento de cinema (`L.finish`), motion blur, escala real (pessoa < porta < carro), ação em toda cena, legenda = fala, voz ≥ 8 LU acima do fundo, revisão por agente cético. Personagens, músicas e efeitos são originais — nada de marcas de terceiros. Licença MIT (`LICENSE`).

## Limites honestos
É 2D (iso "falso 3D"); 3D real está no roteiro (`references/3d.md`). Vozes sintéticas são fala de desenho, não narração: para narrar com legenda use sua própria voz (`voz.mp3`). Fontes Archivo/Montserrat caem para Impact/DejaVu se não instaladas.
