# QA antes de entregar
1. `render.mjs` terminou sem "JS errors".
2. `ffprobe -v error -show_entries format=duration:stream=codec_name,width,height -of default=nw=1 video.mp4` → tamanho e duração certos (=áudio).
3. Extraia 3 frames (`ffmpeg -ss 1 -i video.mp4 -frames:v 1 f1.png`) e OLHE: nada cortado, legenda legível, braços sem cruzar o corpo, sem sobreposição.
4. Há movimento contínuo em todas as cenas? Cortes limpos?
5. Arquivo < 30 MB se for enviar por chat (`--crf 26`).
## Erros comuns
- `CONFIG` não definido → declare `const CONFIG` no `cena.js`.
- Tela preta → `window.READY` não setado/erro de JS; veja o log.
- Legenda colada → aumente `size` do gap ou diminua `group`.
- Texto cortado → reduza `size` ou quebre linha.
- Boca parada → `words.js` sem `ENV` (rode `prep_audio.py`).
