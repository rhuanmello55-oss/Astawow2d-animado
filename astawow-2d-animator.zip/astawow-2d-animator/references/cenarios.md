# Cenários prontos (copie de `exemplo/cena.js`)
- **Fundo bolinhas**: `g.fillRect` cor + `L.dots(g,W,H,'rgba(255,255,255,.14)',90,12,t)`.
- **Mercadinho**: `P=L.iso(540,900,108)`; calçada `box(-3.4,-2.4,0,6.8,5.2,.12)`; loja `box(-2.6,-1.6,0,5.2,3.2,2.2*rise)`; telhado `roof`; placa na face frontal `P(0,1.6,1.55)`; use `rise=L.spring(t-.1)` para "construir".
- **Pista/rua**: `L.roadH(g,0,W,y,230,t,420)` + faixas rolando; carros = `rr`+rodas; câmera lateral.
- **Campo**: `L.sky` + `g.fillRect` verde + `L.grass(...)` 2 camadas + árvore.
- **Cidade/interior**: caixas isométricas lado a lado; janelas = `rr` amarelo.
Dica: variar o `iso` com `rot` dá "giro" de câmera.
