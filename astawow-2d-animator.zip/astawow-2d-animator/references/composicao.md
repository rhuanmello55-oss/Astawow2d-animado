# Composição e acabamento dos quadros (lições dos demos)
Problemas reais vistos nos nossos próprios demos — evite:
1. **Metade do quadro vazia** (rua escura embaixo, céu vazio em cima). Enquadre mais perto: o foco ocupa ≥ 55% da altura útil. Use `camKeys` para aproximar.
2. **Personagem minúsculo**. Pessoa menor que a casa SIM, mas ainda legível no celular: altura ≥ 14% do quadro em 9:16 na cena de ação; use close-ups intercalados (cabeça + mãos) a cada 2–3 planos.
3. **Elemento de UI sobre o personagem** (etiqueta de preço cobrindo a pessoa). Etiquetas ficam acima da cabeça (≥ 0,4 m) ou no objeto, nunca sobre o rosto/mãos.
4. **Corte sem querer na borda**: entrada/saída só quando proposital; senão deixe 5% de margem.
5. **Sinal/placa fora do lugar** (letreiro flutuando sobre o telhado): letreiro encosta na fachada ou em suporte desenhado.
6. **Regra dos terços**: ação principal em 1/3 horizontal; legenda em y≈70% sem cobrir rostos.
7. **Camadas e profundidade**: 3 planos (fundo desfocado/mais claro, meio com ação, frente com folhas/grama). Sombras de contato embaixo de tudo.
8. **Paleta**: 1 cor dominante + 1 de destaque (#ff8a3d). Sem mais de 5 matizes por cena.
9. **Acabamento** já vem ligado (`L.finish`): bloom suave, grade quente/fria, vinheta, grão. Se o grão sujar rostos claros, `CONFIG.finish={grain:.01}`.
10. **Rosto**: olhos com brilho, bochechas leves, boca que acompanha a fala; mãos com 3–4 dedos simplificados, nunca "toco".
Teste final: folha `--phone` — se não dá para entender a cena em 1 segundo, simplifique.
