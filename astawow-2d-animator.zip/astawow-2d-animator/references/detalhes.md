# Checklist de pequenos detalhes (aplique em TODA animação)
**Movimento do personagem**: antecipação (agacha antes de pular), squash & stretch (`g.scale(1/s, s)`), follow-through (algo continua mexendo depois que ele para: mão, boné, folha), respiração, piscar a cada ~3 s, olhar seguindo o objeto (`look`/`up`), cabeça inclinando (`tilt`).
**Contato com o chão**: sombra que encolhe no pulo, poeirinha (`L.puff`) ao pisar/pousar, grama/flores balançando.
**Vida ao redor**: borboleta (`L.butterfly`), passarinho que voa quando algo acontece (`L.bird`), flores (`L.flower`), folhas e poeira caindo (`L.drift`), raios de sol (`L.rays`), nuvens com parallax.
**Reações**: faísca (`L.sparkle`) quando algo acontece, "+1"/BIP/etiqueta de preço com mola (`L.priceTag`), zoom "punch" (+4% e volta) no momento-chave.
**Câmera**: `L.camKeys` com keyframes (visão geral → zoom no detalhe → volta); sempre algum push-in lento.
**Escala**: pessoa ≈ 55% da altura do cômodo/loja (em iso: `s≈.38–.42` com `u≈84`). Nunca maior que o prédio.
**Legendas e títulos**: título some depois de 2 s (não cobrir a ação); CTA no fim; nada importante nas margens do Shorts.
**Antes de entregar**: contact sheet com 8–12 frames, procurar: sobreposição de texto, personagem cortado, item "pulando" sem origem, elemento parado.
