# Escala e construção do cenário (leia ANTES de desenhar)
Regra de ouro: **1 unidade do grid = 1 metro**. Tudo no mesmo cenário usa as mesmas medidas. Pessoa nunca maior que casa, porta, carro ou prateleira.

| objeto | medida (m) | nota |
|---|---|---|
| pessoa adulta | 1,7 de altura | em iso: `s = 1.7·u/400` (u=84 → .36; u=98 → .42) |
| criança | 1,1–1,3 | `s ≈ 0.7× do adulto` |
| porta | 2,1 × 1,0 | altura da pessoa + 20% |
| janela | peitoril 0,95, altura 1,2 | |
| pé-direito (parede) | 3,0 | loja 2,8–3,2 |
| loja/casa | 5–6 largura, 3,5–4 profundidade | |
| carro | 4,2 × 1,8 × 1,4 | NUNCA menor que 4 de comprimento |
| poste de luz | 4,0–4,5 | |
| árvore | 4–6 | |
| rua (2 faixas) | 6–7 de largura; faixa 3,0–3,3 | calçada 1,8–2,5 colada na rua |
| prateleira | 1,8–2,0 × 0,7 | carrinho 0,9 × 0,55 × 0,75 |
| mesa | 0,75 de altura | sofá 0,85 |

## Construção sem erro (cenário "bem construído")
1. Defina uma única projeção por cena (iso, perspectiva de 1 ponto, ou lateral plana) e **não misture**.
2. Monte do chão pra cima: terreno → rua/calçada (coladas, sem vão) → prédio → detalhes na fachada (use `L.faceY/faceX`, nunca em coordenadas soltas) → adereços → pessoas.
3. Ordem de profundidade: tudo que está "mais atrás" (x+y menor) é desenhado antes. Pessoa atrás de um objeto é desenhada antes dele.
4. Fachada: porta encosta no chão, janela alinhada, toldo acima da porta, placa acima do toldo, nada atravessando o telhado.
5. Rua: calçada com meio-fio, faixa tracejada no meio da pista, carro dentro da faixa (não em cima da calçada), rodas no chão.
6. Pessoas pisam no chão (sombra) e andam na calçada/piso, nunca flutuam nem cruzam paredes.
7. Se mexer no cenário, **reveja os personagens** (escala, posição, camada) e vice-versa: nunca deixe o cenário novo com personagem do cenário antigo.
8. Rode `node scripts/lint.mjs <projeto>` e depois o contact sheet; confira com a tabela acima.
