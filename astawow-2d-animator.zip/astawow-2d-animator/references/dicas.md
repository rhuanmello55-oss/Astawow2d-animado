# Dicas para a skill ficar ainda melhor (roadmap)
1. **Som é metade do vídeo**: efeitos nos tempos certos (`window.HITS` → `audio.sh`) + trilha própria (`music.style`) + ambiente. Já está implementado em `audio/`. Voz sempre acima.
2. **Ritmo**: ação nova a cada 2–3 s; corte seco ou flash; um "gancho" nos primeiros 2 s.
3. **Silhueta clara**: personagem legível em preto chapado; cores do personagem ≠ cor do fundo.
4. **Paleta por cena**: 1 cor dominante + 1 acento quente (o mercadinho azul com carro amarelo).
5. **Leitura em tela pequena**: título ≥ 60 px, legenda ≥ 84 px (9:16), contorno grosso.
6. **Biblioteca de poses**: criar mais poses por personagem (correr, pular, apontar, rir, cair) e reutilizar entre vídeos.
7. **Loop e consistência**: mesmo personagem = mesma cor/proporção em todos os vídeos da série (guarde um `personagens.json`).
8. **Agente revisor** (`agents/animation-qa.md`): sempre peça uma segunda opinião antes de entregar.
9. **Testar em outras IAs**: dê o `PROMPT_MESTRE.md` + a skill e compare os MP4; o que uma IA errar vira nova regra em `references/qa.md`.
10. **Próximos passos**: poses extras do toon (gato correndo de lado, rato com martelo), mais cenários (cozinha, rua noturna, praia), trilha musical sintetizada, exportar GIF/WebM, versão horizontal automática de cada vídeo vertical.
