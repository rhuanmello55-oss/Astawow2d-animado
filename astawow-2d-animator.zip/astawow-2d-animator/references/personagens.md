# Personagens
- Crie variações mudando `skin/hair/hairStyle/shirt/pants/mustache/blush/buttons`. Mantenha o mesmo personagem do vídeo todo.
- **Expressões**: `brow` -1 (bravo) … 0 … +1 (surpreso); `mouth` 'smile'|'sad'|'A'|'O'|'E'|'M'; `look:[dx,dy]` direciona o olhar (-1..1).
- **Fala**: `env=L.envAt(ENV,fps,t)`; `mouth:L.visemeFrom(env,t), mouthOpen:env`. Sem áudio: `env=Math.abs(Math.sin(t*11))` só enquanto fala.
- **Gestos**: `armR:1.45` aponta; `armL/armR` oscilando com `Math.sin(t*3)*.3` ao explicar; entrada: `y` descendo com `(1-L.spring(t-t0))*400`.
- **Andar**: `pose:'walk'` e mova `x` linearmente com `t`. `flip:true` espelha.
- Personagem "bolinha": desenhe você mesmo (círculo branco, olhos pretos, boné) — original.
- Robô/objetos: monte com `rr` + `fillStroke` (ver `exemplo/cena.js`, cena1). NÃO desenhe logos de marcas.
