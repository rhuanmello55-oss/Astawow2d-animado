# Áudio do Astawow — como usar o motor `audio/`

Tudo é sintetizado por código (numpy + scipy). Nada é baixado, nada tem direito autoral. Mesma entrada = mesmo som.

## Fluxo
1. `audio.json` no projeto (modelo: `templates/audio.json`).
2. (opcional, recomendado) `window.HITS=[[t,'pop'],[t,'bonk',{"pan":.3,"gain_db":-2}]]` no `cena.js` → `node scripts/render.mjs pasta --hits pasta/hits.json`.
3. `bash scripts/audio.sh pasta` → `pasta/mix.wav`, `pasta/stems/*.wav`, `pasta/relatorio_audio.md`.
4. `node scripts/render.mjs pasta --audio pasta/mix.wav --out video.mp4`.

## audio.json
| campo | o que faz |
|---|---|
| `dur` | duração em s (igual ao `CONFIG.dur`) |
| `music` | `{style, key, bpm, seed, level, duck, intensity}` — estilos: alegre, aventura, lofi, suspense, toon, mercado, none. `level` = dB do fundo vs voz (padrão -10); `duck` = quanto a música abaixa quando alguém fala (padrão -6) |
| `ambience` | rua, campo, loja, escritorio, noite, none (+ `ambience_level`, padrão -26 vs voz) |
| `voice_file` | narração real do usuário (mp3/wav). É normalizada para -16 LUFS e fica sempre por cima |
| `voices` | `[{t, text, who, dur?, pan?, pitch?, speed?}]` — fala de personagem sintetizada |
| `sfx` | `[{t, sfx, gain_db?, pan?, seed?, repeat:{n,every}}]` — `repeat` para passos/teclas |
| `sfx_from` | arquivo JSON de cues (saída do `--hits` ou `cues.json` antigo) |
| `sfx_level` | nível dos efeitos vs voz (padrão -4 LU no pico momentâneo) |

## Efeitos (`audio/sfx_lib.py`)
pop boing bonk bam soco whoosh whoosh_up whoosh_down swipe ding sino tada sparkle power bip erro click tick digitar step step_soft door creak derrapa caixa moedas splash apito_cai apito_sobe queda zap buzina risada passaro.
Dica: um efeito por ação visível, no MESMO quadro do contato (pancada = `bonk` no quadro em que toca). Efeito longo (whoosh) começa ANTES do movimento, o pico cai no meio.

## Narração e vozes
- **Narração = a sua voz**: grave e use `"voice_file":"voz.mp3"`. O mixer normaliza, deixa a voz sempre por cima e faz a música abaixar quando você fala.
- **Legenda = fala**: `"captions":[{"t":0.5,"text":"frase narrada","dur":3.0}]` gera `words.js` (palavra por palavra) nos tempos que você narra. Para sincronia exata com a gravação use `scripts/prep_audio.py` (faster-whisper).
- **Reações de personagem** (`voices`, balbucio de desenho em estilo "desenho animado"): "hehe!", "grrr!", "ai ai ai!". `who`: narrador, menino, crianca, mulher, caixa, rato, gato, chefe, vovo, robo. Não é fala inteligível — não use como narração.
- **Voz neural (experimental, desligada)**: existe `audio/tts.py` (Kokoro) com `"tts":true`, mas soou como português de Portugal e com chiado nos testes. Só ative se você mesmo achar boa.

## Música (`audio/music.py`)
**Instrumentos reais** (SoundFont GeneralUser GS via `tinysoundfont`, baixado por `audio/models.py`): violão, marimba, flauta, trompa, tuba, piano elétrico, vibrafone, pizzicato, xilofone, baixo acústico, cordas, bateria de verdade, com timing/velocidade humanizados e reverb de sala. Sem o SoundFont cai no sintetizador próprio (`music.engine: "synth"` força). Intro leve (2 compassos) → corpo cheio → final com fade. Motivo de 4 notas que repete com variações. `bpm` e `key` livres; `seed` muda a melodia.
Para um vídeo de 10 s: `alegre`/`mercado` (lojas), `lofi` (campo/calmo), `toon` (perseguição, palito), `suspense` (mistério), `aventura` (marcha).

## Mixagem (regras)
- Voz normalizada a -16 LUFS; fundo (música+ambiente+SFX) abaixo dela; **margem voz−fundo ≥ 8 LU** nas falas (o relatório mostra).
- Música com ducking suave (ataque 60 ms, soltura 400 ms) guiado pela energia da voz.
- Master -14 LUFS integrado; limiter com detecção 4× e teto -1,2 dBTP.
- Sem voz: a música sobe +3 dB.

## Ajustes comuns
- Voz some no fundo → `music.level: -13`, `sfx_level: -6`.
- Música "dominando" → `music.intensity: .7`.
- Efeitos repetitivos (passos) → `sfx_level` menor ou `gain_db: -4` no cue; ou `step_soft`.
- Quer outra melodia → `music.seed: 2, 3…`.

## Limites honestos
Verificado por medição (loudness, pico, espectro, tempos); o timbre quem julga é o ouvido — **ouça e ajuste**. A voz neural lê bem frases comuns mas pode errar acento/nome próprio (reescreva foneticamente). Os efeitos (`sfx_lib`) ainda são sintetizados (não amostras).

## Padrão do canal (pedido do dono): SEM trilha, efeitos baixos
- Default dos templates: `"music": {"style": "none"}` e `"sfx_level": -14` (efeitos discretos, bem abaixo da voz). Só ligue música se o usuário pedir, e nunca alta.
- Tutorial em tela (16:9): `templates/tutorial/` = capítulos + quadro da tela + bonequinho narrando + legenda + logo AstaWoww (logo.js/logo.png). Narração = voz gravada (`voice_file`).
