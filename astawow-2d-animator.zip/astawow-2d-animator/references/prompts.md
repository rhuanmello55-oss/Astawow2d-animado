# Como instalar e usar
**Instalar**: descompacte `astawow-2d-animator.zip` em `~/.claude/skills/` (global) ou `.claude/skills/` na pasta do projeto. Reinicie o Claude Code. Rode `bash ~/.claude/skills/astawow-2d-animator/scripts/check.sh`.

**Usar**: peça "use a skill astawow-2d-animator para…". Ele segue o fluxo do SKILL.md.

## Prompt de teste 1 (sem áudio, rápido)
```
Use a skill astawow-2d-animator. Crie um Short 9:16 de 9 segundos em animação 2D com 3 cenas:
(1) fundo teal de bolinhas, um personagem original de bigode apontando para um robô, título "SIMULAÇÃO";
(2) um mercadinho isométrico low-poly com a placa "MERCADINHO" e uma rua com um personagem andando;
(3) um campo de grama ondulando com uma árvore e um personagem bolinha de boné sentado.
Legendas palavra-por-palavra: "Esse vídeo foi feito inteiro com inteligência artificial". Mostre o contact sheet, corrija o que estiver ruim e entregue o MP4.
```
## Prompt de teste 2 (com narração)
```
Use a skill astawow-2d-animator. Tenho a narração em voz.mp3 e o roteiro em roteiro.txt. Faça um vídeo 16:9 explicativo em 2D, personagem com boca sincronizada, cenários variados a cada 3 s e legendas iguais ao áudio. Rode prep_audio.py, revise por contact sheet e entregue o MP4.
```
## Prompt para o Claude CRIAR uma skill como essa
```
Crie uma skill do Claude Code chamada <nome> em pasta própria com: SKILL.md (frontmatter name + description que dispara no pedido certo; fluxo numerado; regras duras), references/ (api, estilos, qa, prompts), scripts/ testados (check.sh), templates/ e exemplo/ que rodem de ponta a ponta. Teste tudo, mostre a saída real, gere o .zip e escreva o README de instalação.
```
