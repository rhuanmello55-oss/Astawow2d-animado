# Legendas
- `L.captions(g,W,H,WORDS,t,{y:H*.72,size:96,group:3})`; palavra atual em amarelo; contorno preto grosso; pop curto.
- Texto = exatamente o falado. Gere `words.js` com `prep_audio.py --text roteiro.txt`.
- 9:16: y≈0.70–0.74·H, nunca sobre rosto/objeto principal. 16:9: y≈0.84·H, size≈64.
- Sem áudio: `L.wordsFromText('texto',0,dur)`.
- Fonte ausente → fallback automático (Impact/DejaVu); funciona, só muda o visual.
