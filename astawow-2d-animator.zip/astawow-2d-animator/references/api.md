# API da `lib2d.js` (global `L`)
Tudo é função pura de `t` (segundos). Coordenadas em pixels do canvas (`W×H`).

**Matemática**: `clamp(x,a,b)`, `lerp(a,b,t)`, `mixc('#hex','#hex',t)`, `ease.out/inOut/smooth(t)`, `spring(t,k=190,d=15)` (0→1 com overshoot; `spring(t-t0)`), `hash(i,seed)` 0..1 determinístico, `tri(t)` onda triangular.
**Primitivas**: `rr(g,x,y,w,h,r)` (só caminho), `fillStroke(g,fill,stroke,lw)`, `poly(g,[[x,y],…],fill,stroke,lw)`, `shadow(g,x,y,w,h,alpha)`.
**Câmera**: `g.save(); L.cam(g,W,H,t,{zoom,drift,px,py}); …desenha…; g.restore();`
**Personagem**: `L.person(g,{x,y,s,t,flip,skin,hair,hairStyle,shirt,pants,shoes,mustache,blush,buttons,belt,brow,mouth,mouthOpen,look:[dx,dy],armL,armR,pose,prop})`. (x,y)=PÉS; altura≈400·s. Braço: 0 pendurado, positivo abre para fora (1.5≈horizontal). `pose`: idle|walk|run|sit. `prop:(g)=>{}` desenha algo na mão.
**Boca**: `L.visemeFrom(env,t)` → 'M'|'E'|'O'|'A'; `L.envAt(ENV,fps,t)` lê o envelope de volume do áudio.
**Isométrico**: `P=L.iso(cx,cy,u)`; `L.box(g,P,x,y,z,w,d,h,cor)`, `L.roof(g,P,x,y,z,w,d,h,cor)`, `L.treeLP(g,P,x,y,sway)`, `L.cloudLP(g,x,y,s)`, `L.roadH(g,x0,x1,y,w,t,speed)` (estrada rolando).
**Cenário**: `L.sky(g,W,H,topo,base)`, `L.grass(g,x0,x1,y0,y1,n,t,paleta,vento,seed)`, `L.dots(g,W,H,cor,step,r,t)` (fundo de bolinhas).
**Texto**: `L.captions(g,W,H,WORDS,t,{y,size,group,hi,fill,stroke,hold,font})` legenda palavra-a-palavra; `L.title(g,W,'TEXTO',y,t,{t0,size})` título que "pula" com mola.
**Tempo**: `L.wordsFromText(texto,t0,t1)`; `window.WORDS`, `window.ENV` vêm do `words.js`.
**Ordem de desenho**: fundo → sombras → cenário → personagens (de trás pra frente por `y`) → primeiro plano → título/legendas por último.

## Natureza e cena (novas)
`L.hill(g,W,H,y,amp,freq,ph,topo,base)` morro ondulado em camadas • `L.field(g,W,y0,y1,fileiras,porFileira,t,seed,tint)` grama em perspectiva (de trás pra frente; chame de novo por cima do personagem para cobrir os pés) • `L.tuft` tufo • `L.bigTree(g,x,y,s,t,{dark,mid,lite})` árvore com sombra e copa em 3 tons • `L.ballGuy(g,{x,y,s,t,cap,look,up,wave})` bolinha de boné sentada (pés em x,y) • `L.drift(g,W,H,t,n,cores,tam)` folhas caindo • `L.rays(g,W,H,sx,sy,t,alpha)` raios de sol • `L.faceY(g,P,x,y)` desenha NA parede da caixa iso (100 unidades por grid, y negativo = cima) — use para portas, janelas, placas • `L.priceTag(g,x,y,'R$ 5,99',t,cor,{t0,size,rot})` etiqueta de preço com mola.

## Personagem bolinha completo (v3)
`L.ballGuy(g,{x,y,s,t,cap,shirt,shorts,shoe,look,up,wave,flip})` — sentado: cabeça-bola com boné (gomos, botão, aba), camiseta, shorts, braços com mãos (palma, polegar e dedos), pernas com tênis (sola), olhos que piscam, bochechas. `wave:1` acena. Para criar outros poses use `L.blobs2(g,[{p:[[x,y],…],w,c}],ink,lw)` (esqueleto de blobs: silhueta unida sem linhas internas), `L.handSegs(x,y,ang,s,cor,curl)` e `L.footSegs(x,y,cor)`.
## Cena isométrica com rua
Rua paralela à fachada: `L.box(g,P,-12,3.2,0,24,2.8,.06,'#3b3f48')` colada à calçada (y até 3.2), faixas tracejadas com `P(x,4.55)` rolando por `t`, carro = 2 caixas + rodas. IMPORTANTE: as funções de cena recebem tempo LOCAL (`lt`), então `spring(t-t0)` e animações começam em 0 em cada cena.

## v4 — personagem P&B animado e cena azul
`L.ballGuy(g,{pose:'sit'|'walk', walk:0..1, ph, wave, talk, mouth:'smile'|'o', tilt, look, up, cap, shirt, shorts, shoe, flip})` — preto e branco por padrão. **Anime o personagem**: entra andando (`pose:'walk'`, x muda com t), pula (`y` com seno) e senta (`pose:'sit'`, squash curto), olha pra cima e acena (`wave:1`, `talk`). `L.ballHead` desenha só a cabeça. `L.lampLP(g,P,x,y,t)` poste com brilho. `L.treeLP(...,pal)` aceita paleta (ex.: árvores azul-petróleo). Cena iso temática de uma cor: troque céu/chão/telhado/toldo/rua pela mesma família de cor e deixe só um acento quente (carro amarelo, frutas, etiqueta).
**Regra de animação**: TODA cena precisa ter personagem fazendo uma ação em sequência (chega → age → reage), não pose parada. Câmera: `L.cam` com zoom crescente (push-in) e parallax nas camadas de fundo.

## v5 — câmera, micro-detalhes e cenas prontas
`L.camKeys(g,W,H,t,[{t,x,y,z},…])` câmera por keyframes (foco + zoom, interpola suave) • `L.faceX(g,P,x,y)` plano da parede/face direita (como `faceY`) • `L.path([{t,x,y}],t)` caminho com `moving/dx/dy` (use `flip=(dx-dy)<0` em iso) • `L.puff` poeira • `L.flower` • `L.butterfly` • `L.bird(…,fly)` • `L.sparkle` • `ballGuy({shadow:false})` para sombra própria.
**Cenas prontas** (copie `templates/*.js` p/ o projeto e inclua no index.html): `shop.js` → `shopScene(g,t,W,H,SHOP_BLUE|SHOP_BAKERY|SHOP_PHARMA)` fachada+rua; `mercado.js` → `marketScene(g,t,W,H,MARKET_BLUE)` interior em corte com prateleiras, carrinho, itens voando, esteira, BIP e total (use `MARKET_P` p/ mirar a câmera). Veja `demos/`.

## v6 — stick figure (templates/stick.js)
`stickGuy(g,{x,y,s,t,flip,pose:'stand'|'walk'|'sit',hair:'gray'|'black'|'bald',suit,shirt,tie,badge,pants,eyes,mouth,talk,brow,tilt,lean,armL,armR,sweat,look,walk,headOnly})` (tracinho preto nos membros, corpo fininho com volume; pés em x,y; ~380 px de altura em s=1; armas: ângulo, 0=pendurado, ~1.5=horizontal) • `officeRoom(g,W,H,t)` • `japanRoom(g,W,H,t)` • `ceilingHole(g,W,H)` • Demo completa em `demos/palito/` (escritório → corte → quarto com telha caindo e chefe espiando). Inclua `<script src="stick.js">` no index.html.

## v8 — toon (templates/toon.js)
`toonCat`, `toonMouse` (pose idle|run|sleep|tiptoe|peek, eyes, mouth, sx/sy p/ squash & stretch), `livingRoom(g,W,H,t,k)`, `cheese`, `stars`, `bonk`, `speedLines`, `irisOut`. Demo: `demos/toon/`. Regras do estilo: antecipação, squash no impacto, borrão de velocidade, poeira, 'BAM!/BONK!', tremor de câmera, iris-out no fim. Funciona em 16:9 e 9:16 (a cena usa K = escala pela tela).

## v9 — ferramentas
`scripts/new_project.sh <estilo> <pasta>` • `scripts/audio.sh <pasta>` (audio.json → mix.wav) • `scripts/sfx.py` (atalho antigo) • `render.mjs --blur N | --hits f.json | --strip a,b,n | --phone` • `L.springU/wobble/shake/zoomLog/kf` • `window.HITS=[[t,'sfx',{pan,gain_db}]]` • `scripts/qa_video.sh video.mp4` • `scripts/lint.mjs <pasta>` • `agents/animation-qa.md` • `commands/animar.md` • `references/dicas.md`.
