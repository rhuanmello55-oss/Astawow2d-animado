# Regras de estúdio (aprendidas com o estudo do motion-reel)

1. **Shotlist antes de animar** — tabela: cena | início–fim | asset/cenário | ação | transição | som. Vídeos > 20 s ou pedido do usuário: mostre e espere o OK. Personagem novo: mostre a folha de poses/expressões antes de animar.
2. **Tudo é função pura de t** — mola fechada (`L.spring`), `L.wobble`, `L.shake`, `L.kf(t,[[0,0],[1,1]])`, `L.zoomLog`. Aleatório só com `L.hash`.
3. **Som nasce da imagem** — `window.HITS` + `--hits`. O mixer nunca recebe tempo "de cabeça".
4. **Motion blur** no render final: `--blur 3` (3 subquadros por quadro, obturador 0,5; `--shutter` ajusta). Vê-se em movimento rápido (swipe, impacto).
5. **Crítica em rodadas** — folha normal + `--phone` + `--strip a,b,8` por transição. Notas 1–10 (gancho, leitura no celular, movimento, variedade, escala/personagem, som). Corrija os 3 piores; repita até tudo ≥ 8 (mínimo 2 rodadas; 3 se > 20 s). Anote em `critique.md`:
```
## Rodada N
gancho 7 | leitura 9 | movimento 6 | variedade 8 | consistência 9 | som 8
3 piores: (1) … (2) … (3) …  → o que mudei: …
```
6. **Banido (cara de template)**: título centralizado em gradiente, tudo com fade, cantos/bordas decorativos, glow em tudo, partículas genéricas. Algo novo a cada 2–4 s.
7. **Cortes**: o quadro do corte já mostra a imagem nova; flash só em 1–2 momentos estruturais; whip = pan com as duas cenas visíveis.
8. **Zoom em log** (`L.zoomLog`), nunca lerp linear de escala.
9. **Texto**: duas fontes, uma cor de destaque, legível na folha `--phone`. Antes de usar caractere fora do latim básico, confirme que a fonte tem o glifo.
10. **Real, não inventado**: tela de produto/marca só com arquivo real do usuário; sem logos de terceiros.
