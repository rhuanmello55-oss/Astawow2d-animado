---
description: Cria uma animação 2D completa com a skill astawow-2d-animator (pergunta história, duração, formato e estilo)
argument-hint: [história ou ideia]
---
Use a skill astawow-2d-animator. Pedido do usuário: $ARGUMENTS

Siga o "MODO PEDIDO" do SKILL.md: se faltar HISTÓRIA, DURAÇÃO, FORMATO ou ESTILO, faça UMA única pergunta com o formulário (AskUserQuestion se existir); o resto decida sozinho e avise. Depois execute o fluxo completo até o MP4, com lint, contact sheet, QA (subagente `animation-qa` se instalado) e áudio completo (música + ambiente + efeitos + vozes de personagem via `audio.json` → `bash scripts/audio.sh pasta`, master -14 LUFS), ciclo de crítica com notas ≥ 8 e render final com `--blur 3`.
