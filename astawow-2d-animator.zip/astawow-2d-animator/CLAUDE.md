# astawow-2d-animator — instruções para o Claude Code

Esta pasta é uma **skill** que cria animações 2D por código (canvas) e exporta MP4 (Shorts 9:16, YouTube 16:9). Leia `SKILL.md` — ele é a fonte da verdade (modo pedido, fluxo, regras). Este arquivo só diz como usar em qualquer agente.

## Em 30 segundos
1. Requisitos: `node` 18+, `ffmpeg`, `python3` com `numpy scipy`, e `playwright` + Chromium (`npm i playwright && npx playwright install chromium`).
2. Crie o projeto: `bash scripts/new_project.sh <flat|iso-loja|padaria|mercado|campo|palito|toon> meu_video`.
3. Edite `meu_video/cena.js` (use só a API de `references/api.md`), `meu_video/audio.json` (música, ambiente, vozes, efeitos).
4. Valide: `node scripts/lint.mjs meu_video` → contact sheet `node scripts/render.mjs meu_video --snap 0.5,2,4,6 --out contact.png` → OLHE a imagem.
5. Áudio (1ª vez: `pip install -r requirements.txt && pip install --no-deps tinysoundfont && python3 audio/models.py` → instrumentos reais da música; narração = voz.mp3 do usuário): `bash scripts/audio.sh meu_video` → `mix.wav` + `words.js` (legenda = fala via `captions`).
5b. Enquadramento: `python3 scripts/composicao.py meu_video --n 12` — corrija todo ⚠/✗.
6. Render: `node scripts/render.mjs meu_video --audio meu_video/mix.wav --out video.mp4 --blur 3`.
7. Revise com os agentes **detalhista** e **audio-qa** (`agents/universal/`) até aprovar. Só então entregue.

## Regras que NUNCA se quebram
- Cena é função pura de `t` (sem `Math.random`, `Date`, `setTimeout`, estado entre quadros). Aleatório = `L.hash`.
- Escala real: pessoa 1,7 m < porta 2,1 m < carro 4,2 m; rua e calçada coladas.
- Personagens ORIGINAIS; nada de logos/mascotes/marcas d'água de terceiros.
- Legenda = fala. Voz acima de música/efeitos (margem ≥ 8 LU). Vozes sintéticas NÃO são narração.
- Nunca declare "pronto" sem ter visto quadros reais do vídeo.

## Onde está cada coisa
`SKILL.md` regras e fluxo • `PROMPT_MESTRE.md` formulário para colar • `references/` (api, escala, estilos, personagens, cenários, legendas, qa, áudio, estúdio, composição, 3D, dicas) • `templates/` bibliotecas e modelos • `demos/` 6 projetos prontos • `audio/` motor de áudio • `agents/` revisores • `chatgpt/` instruções para GPT/Projeto.
